import { _decorator, Component, Node, Vec3, Quat } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 简化的空父节点创建工具
 * 功能：为每个子节点创建空的父节点（位置0，旋转0，缩放1）
 * 不修改子节点的任何属性，撤销时只移除父节点。还是会修改子节点的属性，但这些修改在撤销时会恢复。
 */
@ccclass('SimpleEmptyParentForChildren')
@executeInEditMode
export class SimpleEmptyParentForChildren extends Component {

    // ============ 配置选项 ============
    
    /** 父节点名称前缀 */
    @property({ displayName: "父节点名称前缀", tooltip: "新创建的父节点将使用此前缀+序号" })
    public parentNamePrefix: string = "Parent_";
    
    // ============ 默认值 ============
    private static readonly DEFAULT_POSITION = new Vec3(0, 0, 0);
    private static readonly DEFAULT_ROTATION = new Quat(0, 0, 0, 1);
    private static readonly DEFAULT_SCALE = new Vec3(1, 1, 1);
    
    // ============ 状态记录（用于撤销） ============
    private originalChildrenState: Array<{
        node: Node,
        parent: Node,
        siblingIndex: number,
        position: Vec3,
        rotation: Quat,
        scale: Vec3
    }> = [];
    
    private createdParents: Node[] = [];
    
    // ============ 操作按钮 ============
    
    /** 执行创建操作 */
    @property({ displayName: "🔄 创建空父节点", tooltip: "点击为每个子节点创建空的父节点" })
    public get executeCreate() {
        return false;
    }
    public set executeCreate(v: boolean) {
        if (EDITOR) {
            this.createEmptyParents();
            console.log("✅ 空父节点创建完成！");
        }
    }
    
    /** 撤销操作 */
    @property({ displayName: "↩️ 撤销创建", tooltip: "点击移除所有创建的父节点" })
    public get executeUndo() {
        return false;
    }
    public set executeUndo(v: boolean) {
        if (EDITOR) {
            this.removeEmptyParents();
            console.log("✅ 父节点已移除！");
        }
    }
    
    // ============ 核心方法 ============
    
    /** 创建空的父节点 */
    private createEmptyParents() {
        // 清空之前的记录
        this.originalChildrenState = [];
        this.createdParents = [];
        
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点");
            return;
        }
        
        console.log(`🔧 开始为 ${children.length} 个子节点创建空父节点...`);
        
        // 记录所有子节点的原始状态（用于撤销）
        children.forEach((child, index) => {
            this.originalChildrenState.push({
                node: child,
                parent: child.parent,
                siblingIndex: child.getSiblingIndex(),
                position: child.position.clone(),
                rotation: child.rotation.clone(),
                scale: child.scale.clone()
            });
        });
        
        // 从后往前遍历，避免索引变化问题
        for (let i = children.length - 1; i >= 0; i--) {
            const childNode = children[i];
            this.createSingleEmptyParent(childNode, i);
        }
        
        console.log(`✅ 创建了 ${this.createdParents.length} 个空父节点`);
    }
    
    /** 为单个子节点创建空父节点 */
    private createSingleEmptyParent(childNode: Node, index: number) {
        // 1. 记录子节点的世界位置
        const childPosition = childNode.position.clone();
        const childRotation = childNode.rotation.clone();
        const childScale = childNode.scale.clone();
        
        // 2. 创建空的父节点
        const parentNode = new Node(this.parentNamePrefix + (index + 1));
        
        // 3. 设置父节点为默认值
        parentNode.setPosition(SimpleEmptyParentForChildren.DEFAULT_POSITION);
        parentNode.setRotation(SimpleEmptyParentForChildren.DEFAULT_ROTATION);
        parentNode.setScale(SimpleEmptyParentForChildren.DEFAULT_SCALE);
        
        // 4. 将父节点添加到当前节点下
        parentNode.parent = this.node;
        
        // 5. 将子节点移动到新父节点下
        childNode.parent = parentNode;
        
        // 6. 恢复子节点的世界位置（这样子在场景中的实际位置不变）
        childNode.position = childPosition;
        childNode.rotation = childRotation;
        childNode.scale = childScale;
        
        // 7. 记录创建的父节点
        this.createdParents.push(parentNode);
        
        console.log(`   ✅ ${parentNode.name} ← ${childNode.name}`);
        
        return parentNode;
    }
    
    /** 移除空的父节点 */
    private removeEmptyParents() {
        if (this.createdParents.length === 0 && this.originalChildrenState.length === 0) {
            console.warn("⚠️ 没有可撤销的操作");
            return;
        }
        
        console.log(`🔧 开始移除空父节点...`);
        
        // 1. 先处理所有子节点
        for (let i = this.originalChildrenState.length - 1; i >= 0; i--) {
            const state = this.originalChildrenState[i];
            const childNode = state.node;
            
            // 检查这个子节点是否还在父节点下
            if (childNode.parent && childNode.parent.name.startsWith(this.parentNamePrefix)) {
                // 记录当前世界位置
                const currentPosition = childNode.position.clone();
                const currentRotation = childNode.rotation.clone();
                const currentScale = childNode.scale.clone();
                
                // 将子节点移回原来的父节点
                childNode.parent = this.node;
                
                // 恢复原始兄弟索引
                childNode.setSiblingIndex(state.siblingIndex);
                
                // 保持世界位置不变
                childNode.position = currentPosition;
                childNode.rotation = currentRotation;
                childNode.scale = currentScale;
                
                console.log(`   ↩️ 恢复子节点: ${childNode.name} 到原始位置`);
            }
        }
        
        // 2. 销毁所有创建的父节点
        let destroyedCount = 0;
        this.createdParents.forEach(parentNode => {
            if (!parentNode.isValid) return;
            
            console.log(`   🗑️ 移除父节点: ${parentNode.name}`);
            parentNode.destroy();
            destroyedCount++;
        });
        
        // 3. 清空记录
        this.createdParents = [];
        this.originalChildrenState = [];
        
        console.log(`✅ 已移除 ${destroyedCount} 个空父节点，子节点已恢复原样`);
    }
    
    /** 验证功能：检查所有父节点是否为空 */
    @property({ displayName: "🔍 验证父节点", tooltip: "检查所有父节点是否为空状态" })
    public get verifyParents() {
        return false;
    }
    public set verifyParents(v: boolean) {
        if (EDITOR) this.verifyEmptyParents();
    }
    
    private verifyEmptyParents() {
        let emptyCount = 0;
        let nonEmptyCount = 0;
        
        this.createdParents.forEach(parentNode => {
            if (!parentNode.isValid) return;
            
            const isPositionDefault = parentNode.position.equals(SimpleEmptyParentForChildren.DEFAULT_POSITION);
            const isRotationDefault = parentNode.rotation.equals(SimpleEmptyParentForChildren.DEFAULT_ROTATION);
            const isScaleDefault = parentNode.scale.equals(SimpleEmptyParentForChildren.DEFAULT_SCALE);
            
            if (isPositionDefault && isRotationDefault && isScaleDefault) {
                console.log(`✅ ${parentNode.name}: 空父节点`);
                emptyCount++;
            } else {
                console.log(`❌ ${parentNode.name}: 非空父节点`);
                nonEmptyCount++;
            }
        });
        
        console.log(`📊 验证结果: ${emptyCount} 个空父节点, ${nonEmptyCount} 个非空父节点`);
    }
}