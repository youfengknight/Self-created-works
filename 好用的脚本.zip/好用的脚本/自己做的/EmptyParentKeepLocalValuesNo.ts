import { _decorator, Component, Node, Vec3, Quat } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 空父节点创建工具（保持子节点本地值）
 * 功能：为每个子节点创建空的父节点（位置0，旋转0，缩放1）
 * 创建后，在编辑器面板显示的子节点本地坐标值保持不变，但实际值已改变，不过撤销会改回来
 */
@ccclass('EmptyParentKeepLocalValues')
@executeInEditMode
export class EmptyParentKeepLocalValues extends Component {

    // ============ 配置选项 ============
    
    /** 父节点名称前缀 */
    @property({ displayName: "父节点名称前缀", tooltip: "新创建的父节点将使用此前缀+序号" })
    public parentNamePrefix: string = "Parent_";
    
    // ============ 默认值 ============
    private static readonly DEFAULT_POSITION = new Vec3(0, 0, 0);
    private static readonly DEFAULT_ROTATION = new Quat(0, 0, 0, 1);
    private static readonly DEFAULT_SCALE = new Vec3(1, 1, 1);
    
    // ============ 状态记录（用于撤销） ============
    private originalState: Array<{
        child: Node,
        parent: Node,
        siblingIndex: number,
        localPosition: Vec3,
        localRotation: Quat,
        localScale: Vec3
    }> = [];
    
    private createdParents: Node[] = [];
    
    // ============ 操作按钮 ============
    
    /** 执行创建操作 */
    @property({ displayName: "🔄 创建空父节点", tooltip: "点击为每个子节点创建空的父节点，保持子节点本地值不变" })
    public get executeCreate() {
        return false;
    }
    public set executeCreate(v: boolean) {
        if (EDITOR) {
            this.createEmptyParentsWithLocalValues();
            console.log("✅ 空父节点创建完成！子节点本地值已保持");
        }
    }
    
    /** 撤销操作 */
    @property({ displayName: "↩️ 撤销创建", tooltip: "点击移除所有创建的父节点，恢复原始结构" })
    public get executeUndo() {
        return false;
    }
    public set executeUndo(v: boolean) {
        if (EDITOR) {
            this.removeEmptyParents();
            console.log("✅ 父节点已移除！");
        }
    }
    
    // ============ 核心方法 ============
    
    /** 创建空的父节点，保持子节点本地值 */
    private createEmptyParentsWithLocalValues() {
        // 清空之前的记录
        this.originalState = [];
        this.createdParents = [];
        
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点");
            return;
        }
        
        console.log(`🔧 开始为 ${children.length} 个子节点创建空父节点...`);
        
        // 记录所有子节点的原始本地值
        children.forEach((child, index) => {
            this.originalState.push({
                child: child,
                parent: child.parent,
                siblingIndex: child.getSiblingIndex(),
                localPosition: child.position.clone(),      // 本地位置
                localRotation: child.rotation.clone(),      // 本地旋转
                localScale: child.scale.clone()            // 本地缩放
            });
        });
        
        // 从后往前遍历，避免索引变化问题
        for (let i = children.length - 1; i >= 0; i--) {
            const childNode = children[i];
            this.createParentKeepLocalValues(childNode, i);
        }
        
        console.log(`✅ 创建了 ${this.createdParents.length} 个空父节点`);
        console.log(`📝 所有子节点的本地位置、旋转、缩放值已保持为原始值`);
    }
    
    /** 为单个子节点创建空父节点，保持本地值 */
    private createParentKeepLocalValues(childNode: Node, index: number) {
        // 1. 保存子节点的原始本地值
        const originalLocalPosition = childNode.position.clone();
        const originalLocalRotation = childNode.rotation.clone();
        const originalLocalScale = childNode.scale.clone();
        
        // 2. 创建空的父节点
        const parentNode = new Node(this.parentNamePrefix + (index + 1));
        
        // 3. 设置父节点为默认值（位置0，旋转0，缩放1）
        parentNode.setPosition(EmptyParentKeepLocalValues.DEFAULT_POSITION);
        parentNode.setRotation(EmptyParentKeepLocalValues.DEFAULT_ROTATION);
        parentNode.setScale(EmptyParentKeepLocalValues.DEFAULT_SCALE);
        
        // 4. 将父节点添加到当前节点下
        parentNode.parent = this.node;
        
        // 5. 将子节点移动到新父节点下
        childNode.parent = parentNode;
        
        // 6. 关键步骤：恢复子节点的本地值！
        // 这样在编辑器面板上看到的子节点位置、旋转、缩放值就是原来的值
        childNode.setPosition(originalLocalPosition);
        childNode.setRotation(originalLocalRotation);
        childNode.setScale(originalLocalScale);
        
        // 7. 记录创建的父节点
        this.createdParents.push(parentNode);
        
        console.log(`   ✅ ${parentNode.name} ← ${childNode.name}`);
        console.log(`      📍 本地位置: (${originalLocalPosition.x.toFixed(2)}, ${originalLocalPosition.y.toFixed(2)}, ${originalLocalPosition.z.toFixed(2)})`);
        console.log(`      🎯 本地缩放: (${originalLocalScale.x.toFixed(2)}, ${originalLocalScale.y.toFixed(2)}, ${originalLocalScale.z.toFixed(2)})`);
        
        return parentNode;
    }
    
    /** 移除空的父节点 */
    private removeEmptyParents() {
        if (this.createdParents.length === 0 && this.originalState.length === 0) {
            console.warn("⚠️ 没有可撤销的操作");
            return;
        }
        
        console.log(`🔧 开始移除空父节点，恢复子节点原始状态...`);
        
        let restoredCount = 0;
        
        // 恢复每个子节点到原始状态
        this.originalState.forEach(state => {
            const childNode = state.child;
            
            // 检查这个子节点是否还在父节点下
            if (childNode.parent && childNode.parent.name.startsWith(this.parentNamePrefix)) {
                // 保存当前的本地值（虽然应该和原始值一样，但为了安全还是保存）
                const currentLocalPosition = childNode.position.clone();
                const currentLocalRotation = childNode.rotation.clone();
                const currentLocalScale = childNode.scale.clone();
                
                // 将子节点移回原来的父节点（this.node）
                childNode.parent = this.node;
                
                // 恢复原始兄弟索引
                childNode.setSiblingIndex(state.siblingIndex);
                
                // 恢复原始的本地值
                childNode.setPosition(state.localPosition);
                childNode.setRotation(state.localRotation);
                childNode.setScale(state.localScale);
                
                console.log(`   ↩️ 恢复子节点: ${childNode.name}`);
                console.log(`      📍 本地位置: (${state.localPosition.x.toFixed(2)}, ${state.localPosition.y.toFixed(2)}, ${state.localPosition.z.toFixed(2)})`);
                
                restoredCount++;
            }
        });
        
        // 销毁所有创建的父节点
        let destroyedCount = 0;
        this.createdParents.forEach(parentNode => {
            if (!parentNode.isValid) return;
            
            console.log(`   🗑️ 移除父节点: ${parentNode.name}`);
            parentNode.destroy();
            destroyedCount++;
        });
        
        // 清空记录
        this.createdParents = [];
        this.originalState = [];
        
        console.log(`✅ 已移除 ${destroyedCount} 个空父节点，恢复了 ${restoredCount} 个子节点的原始状态`);
    }
    
    /** 查看当前状态 */
    @property({ displayName: "🔍 查看状态", tooltip: "查看当前父节点和子节点的状态" })
    public get checkStatus() {
        return false;
    }
    public set checkStatus(v: boolean) {
        if (EDITOR) this.printCurrentStatus();
    }
    
    private printCurrentStatus() {
        const children = this.node.children;
        
        console.log(`📊 当前节点 ${this.node.name} 的状态：`);
        console.log(`子节点数量: ${children.length}`);
        
        children.forEach((node, index) => {
            if (node.name.startsWith(this.parentNamePrefix)) {
                // 这是创建的父节点
                console.log(`\n父节点 ${index + 1}: ${node.name}`);
                console.log(`   本地位置: (${node.position.x.toFixed(2)}, ${node.position.y.toFixed(2)}, ${node.position.z.toFixed(2)})`);
                console.log(`   本地缩放: (${node.scale.x.toFixed(2)}, ${node.scale.y.toFixed(2)}, ${node.scale.z.toFixed(2)})`);
                
                // 检查子节点
                if (node.children.length > 0) {
                    node.children.forEach(child => {
                        console.log(`   └─ 子节点: ${child.name}`);
                        console.log(`       本地位置: (${child.position.x.toFixed(2)}, ${child.position.y.toFixed(2)}, ${child.position.z.toFixed(2)})`);
                        console.log(`       本地缩放: (${child.scale.x.toFixed(2)}, ${child.scale.y.toFixed(2)}, ${child.scale.z.toFixed(2)})`);
                    });
                }
            } else {
                // 这是普通子节点
                console.log(`\n子节点 ${index + 1}: ${node.name}`);
                console.log(`   本地位置: (${node.position.x.toFixed(2)}, ${node.position.y.toFixed(2)}, ${node.position.z.toFixed(2)})`);
                console.log(`   本地缩放: (${node.scale.x.toFixed(2)}, ${node.scale.y.toFixed(2)}, ${node.scale.z.toFixed(2)})`);
            }
        });
    }
    
    /** 验证子节点本地值是否保持 */
    @property({ displayName: "✅ 验证本地值", tooltip: "验证子节点的本地值是否保持为原始值" })
    public get verifyLocalValues() {
        return false;
    }
    public set verifyLocalValues(v: boolean) {
        if (EDITOR) this.verifyChildLocalValues();
    }
    
    private verifyChildLocalValues() {
        if (this.originalState.length === 0) {
            console.log("⚠️ 没有原始状态记录");
            return;
        }
        
        console.log("🔍 验证子节点本地值保持情况：");
        
        let matchedCount = 0;
        let mismatchedCount = 0;
        
        this.originalState.forEach(state => {
            const childNode = state.child;
            
            // 检查子节点是否在父节点下
            if (childNode.parent && childNode.parent.name.startsWith(this.parentNamePrefix)) {
                // 获取当前本地值
                const currentPos = childNode.position;
                const currentScale = childNode.scale;
                
                // 比较本地值（使用容差比较）
                const posTolerance = 0.001;
                const scaleTolerance = 0.001;
                
                const posMatch = 
                    Math.abs(currentPos.x - state.localPosition.x) < posTolerance &&
                    Math.abs(currentPos.y - state.localPosition.y) < posTolerance &&
                    Math.abs(currentPos.z - state.localPosition.z) < posTolerance;
                    
                const scaleMatch = 
                    Math.abs(currentScale.x - state.localScale.x) < scaleTolerance &&
                    Math.abs(currentScale.y - state.localScale.y) < scaleTolerance &&
                    Math.abs(currentScale.z - state.localScale.z) < scaleTolerance;
                
                if (posMatch && scaleMatch) {
                    console.log(`✅ ${childNode.name}: 本地值保持正确`);
                    matchedCount++;
                } else {
                    console.log(`❌ ${childNode.name}: 本地值不匹配`);
                    console.log(`   期望位置: (${state.localPosition.x.toFixed(3)}, ${state.localPosition.y.toFixed(3)}, ${state.localPosition.z.toFixed(3)})`);
                    console.log(`   实际位置: (${currentPos.x.toFixed(3)}, ${currentPos.y.toFixed(3)}, ${currentPos.z.toFixed(3)})`);
                    console.log(`   期望缩放: (${state.localScale.x.toFixed(3)}, ${state.localScale.y.toFixed(3)}, ${state.localScale.z.toFixed(3)})`);
                    console.log(`   实际缩放: (${currentScale.x.toFixed(3)}, ${currentScale.y.toFixed(3)}, ${currentScale.z.toFixed(3)})`);
                    mismatchedCount++;
                }
            }
        });
        
        console.log(`📊 验证结果: ${matchedCount} 个匹配, ${mismatchedCount} 个不匹配`);
    }
}