import { _decorator, Component, error, Node } from 'cc';
import { EDITOR } from 'cc/env'; // 编辑器环境判断常量

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 组件复制迁移工具：总节点 → 子节点 → 子物体 组件迁移
 * 功能：把【子物体】身上的指定组件 复制给【父节点】，然后删除子物体身上的该组件
 */
@ccclass('ComponentCopyToParent')
@executeInEditMode // 编辑器模式下运行，无需启动游戏
export class ComponentCopyToParent extends Component {

    /** 
     * 【必填】选择你要复制的目标组件的类名
     * 直接在属性面板 拖拽 任意节点上的该组件 即可自动识别
     */
    @property({ type: Component, displayName: "要复制的目标组件", tooltip: "拖拽任意节点上的目标组件到这里即可" })
    public targetComponent: Component | null = null;

    /** 执行一次 - 编辑器触发按钮 */
    @property({ displayName: "执行迁移操作", tooltip: "点击即执行，自动复位可重复点击" })
    public get runOnce() {
        return false;
    }
    public set runOnce(v: boolean) {
        if (EDITOR && this.targetComponent) {
            this.executeComponentCopy();
            console.log("✅ 组件迁移操作执行完成！");
        } else if(EDITOR && !this.targetComponent) {
            console.error("❌ 请先在属性面板选择【要复制的目标组件】！");
        }
    }

    /** 核心执行逻辑 - 组件复制迁移 */
    private executeComponentCopy() {
        // 1. 获取当前脚本挂载的【总节点】的所有直接子节点（总节点 → 节点）
        const allParentNodes = this.node.children;
        if (allParentNodes.length === 0) {
            console.warn("⚠️ 总节点下暂无任何子节点，无需执行操作");
            return;
        }

        // 2. 遍历总节点下的每一个【节点】
        allParentNodes.forEach(parentNode => {
            // 3. 获取当前【节点】下的所有子物体（节点 → 子物体）
            const allChildNodes = parentNode.children;
            if (allChildNodes.length === 0) {
                console.warn(`⚠️ 节点【${parentNode.name}】下暂无子物体，跳过`);
                return;
            }

            // 4. 遍历当前节点下的每一个【子物体】
            allChildNodes.forEach(childNode => {
                // 获取组件类型
                const componentType = this.targetComponent?.constructor;
                if (!componentType) {
                    console.error("❌ 无法获取组件类型");
                    return;
                }

                // 核心：获取子物体身上的 目标组件
                const sourceComponent = childNode.getComponent(componentType as any);
                if (!sourceComponent) {
                    console.warn(`⚠️ 子物体【${childNode.name}】上没有找到目标组件，跳过`);
                    return;
                }

                // ✅ 关键步骤1：把【子物体】的组件 完整复制到 它的【父节点】上
                this.copyComponentToNode(sourceComponent, parentNode);

                // ✅ 关键步骤2：删除【子物体】身上的这个目标组件
                childNode.removeComponent(sourceComponent);
                
                console.log(`✅ 成功：子物体【${childNode.name}】→ 父节点【${parentNode.name}】，组件迁移完成`);
            });
        });
    }

    /**
     * 复制组件到目标节点
     * @param sourceComponent 源组件
     * @param targetNode 目标节点
     */
    private copyComponentToNode(sourceComponent: Component, targetNode: Node) {
        if (!sourceComponent || !targetNode) {
            console.error("❌ 复制组件失败：源组件或目标节点为空");
            return;
        }

        // 获取组件的构造函数类型
        const componentType = sourceComponent.constructor as any;
        
        // 在目标节点上添加相同类型的组件
        const newComponent = targetNode.addComponent(componentType);
        
        if (!newComponent) {
            console.error("❌ 无法在目标节点上添加组件");
            return;
        }

        // 复制所有可枚举的属性
        const keys = Object.keys(sourceComponent);
        for (const key of keys) {
            // 跳过内部属性和方法
            if (key.startsWith('_') || key === 'node' || typeof sourceComponent[key] === 'function') {
                continue;
            }
            
            try {
                // 尝试复制属性值
                const value = sourceComponent[key];
                if (value !== undefined && value !== null) {
                    newComponent[key] = value;
                }
            } catch (e) {
                // 某些只读属性可能无法设置，忽略这些错误
                console.warn(`⚠️ 无法复制属性 ${key}:`, e);
            }
        }

        console.log(`✅ 组件复制成功：${componentType.name}`);
        console.warn("要复制的目标组件已清空，请勿重复执行");
    }
}