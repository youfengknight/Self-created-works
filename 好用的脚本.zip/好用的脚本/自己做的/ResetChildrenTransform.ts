import { _decorator, Component, Node, Vec3, Quat } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 子节点变换重置工具
 * 功能：将当前节点下所有子节点的位置、旋转归零，缩放设为1
 * 可以批量处理子节点的变换属性，便于标准化管理
 */
@ccclass('ResetChildrenTransform')
@executeInEditMode
export class ResetChildrenTransform extends Component {

    // ============ 配置选项 ============
    
    /** 重置位置 (0,0,0) */
    @property({ displayName: "重置位置", tooltip: "将所有子节点的位置设为 (0,0,0)" })
    public resetPosition: boolean = true;
    
    /** 重置旋转 (0,0,0,1) */
    @property({ displayName: "重置旋转", tooltip: "将所有子节点的旋转设为初始状态" })
    public resetRotation: boolean = true;
    
    /** 重置缩放 (1,1,1) */
    @property({ displayName: "重置缩放", tooltip: "将所有子节点的缩放设为 (1,1,1)" })
    public resetScale: boolean = true;
    
    /** 仅重置直接子节点 */
    @property({ displayName: "仅直接子节点", tooltip: "只处理直接子节点，不处理孙节点" })
    public directChildrenOnly: boolean = true;
    
    /** 排除列表：不重置这些节点的属性 */
    @property({ displayName: "排除节点", tooltip: "这些节点的属性不会被重置" })
    public excludeNodes: Node[] = [];
    
    /** 排除名称包含的关键词 */
    @property({ displayName: "排除关键词", tooltip: "节点名称包含这些关键词的不被处理，用逗号分隔" })
    public excludeKeywords: string = "";
    
    // ============ 操作按钮 ============
    
    /** 执行重置操作 - 编辑器按钮 */
    @property({ displayName: "🔄 执行重置变换", tooltip: "点击重置所有子节点的变换属性" })
    public get executeReset() {
        return false;
    }
    public set executeReset(v: boolean) {
        if (EDITOR) {
            this.executeTransformReset();
            console.log("✅ 变换重置操作执行完成！");
        }
    }
    
    /** 预览效果 - 不实际修改，只输出信息 */
    @property({ displayName: "👁️ 预览重置效果", tooltip: "预览重置效果，不实际修改属性" })
    public get previewReset() {
        return false;
    }
    public set previewReset(v: boolean) {
        if (EDITOR) {
            this.previewTransformReset();
        }
    }
    
    /** 恢复默认变换（默认值） */
    private static readonly DEFAULT_POSITION = new Vec3(0, 0, 0);
    private static readonly DEFAULT_ROTATION = new Quat(0, 0, 0, 1);
    private static readonly DEFAULT_SCALE = new Vec3(1, 1, 1);
    
    // ============ 核心方法 ============
    
    /** 执行变换重置操作 */
    private executeTransformReset() {
        const nodesToProcess = this.collectNodesToProcess();
        
        if (nodesToProcess.length === 0) {
            console.warn("⚠️ 没有找到需要处理的节点");
            return;
        }
        
        console.log(`🔧 开始处理 ${nodesToProcess.length} 个节点...`);
        
        let processedCount = 0;
        nodesToProcess.forEach(node => {
            if (this.resetNodeTransform(node)) {
                processedCount++;
            }
        });
        
        console.log(`✅ 成功重置 ${processedCount} 个节点的变换属性`);
    }
    
    /** 预览重置效果 */
    private previewTransformReset() {
        const nodesToProcess = this.collectNodesToProcess();
        
        if (nodesToProcess.length === 0) {
            console.warn("⚠️ 没有找到需要处理的节点");
            return;
        }
        
        console.log(`👁️ 预览 ${nodesToProcess.length} 个节点的重置效果：\n`);
        
        nodesToProcess.forEach(node => {
            const changes = this.getTransformChanges(node);
            if (changes.length > 0) {
                console.log(`📌 ${node.name}:`);
                changes.forEach(change => console.log(`   ${change}`));
            }
        });
        
        console.log("\n📊 总计:", 
            `${nodesToProcess.length} 个节点将被处理，`,
            `点击"执行重置变换"应用更改`
        );
    }
    
    /** 收集需要处理的节点 */
    private collectNodesToProcess(): Node[] {
        const nodes: Node[] = [];
        
        if (this.directChildrenOnly) {
            // 只处理直接子节点
            this.node.children.forEach(child => {
                if (this.shouldProcessNode(child)) {
                    nodes.push(child);
                }
            });
        } else {
            // 处理所有后代节点
            this.collectAllDescendants(this.node, nodes);
        }
        
        return nodes;
    }
    
    /** 收集所有后代节点 */
    private collectAllDescendants(parent: Node, result: Node[]) {
        parent.children.forEach(child => {
            if (this.shouldProcessNode(child)) {
                result.push(child);
            }
            // 递归处理子节点的子节点
            this.collectAllDescendants(child, result);
        });
    }
    
    /** 检查节点是否需要处理 */
    private shouldProcessNode(node: Node): boolean {
        // 检查排除列表
        if (this.excludeNodes.indexOf(node) !== -1) {
            return false;
        }
        
        // 检查排除关键词
        if (this.excludeKeywords) {
            const keywords = this.excludeKeywords.split(',').map(k => k.trim());
            for (const keyword of keywords) {
                if (keyword && node.name.includes(keyword)) {
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /** 重置单个节点的变换属性 */
    private resetNodeTransform(node: Node): boolean {
        let hasChanges = false;
        
        try {
            // 重置位置
            if (this.resetPosition) {
                node.setPosition(ResetChildrenTransform.DEFAULT_POSITION);
                hasChanges = true;
            }
            
            // 重置旋转
            if (this.resetRotation) {
                node.setRotation(ResetChildrenTransform.DEFAULT_ROTATION);
                hasChanges = true;
            }
            
            // 重置缩放
            if (this.resetScale) {
                node.setScale(ResetChildrenTransform.DEFAULT_SCALE);
                hasChanges = true;
            }
            
            if (hasChanges) {
                console.log(`✅ 已重置: ${node.name}`);
                return true;
            }
        } catch (error) {
            console.error(`❌ 重置节点 ${node.name} 时出错:`, error);
        }
        
        return false;
    }
    
    /** 获取节点的变换更改信息 */
    private getTransformChanges(node: Node): string[] {
        const changes: string[] = [];
        
        // 检查位置变化
        if (this.resetPosition && !node.position.equals(ResetChildrenTransform.DEFAULT_POSITION)) {
            const current = node.position;
            changes.push(`位置: (${current.x.toFixed(2)}, ${current.y.toFixed(2)}, ${current.z.toFixed(2)}) → (0, 0, 0)`);
        }
        
        // 检查旋转变化
        if (this.resetRotation && !node.rotation.equals(ResetChildrenTransform.DEFAULT_ROTATION)) {
            const current = node.rotation;
            changes.push(`旋转: 将被重置`);
        }
        
        // 检查缩放变化
        if (this.resetScale && !node.scale.equals(ResetChildrenTransform.DEFAULT_SCALE)) {
            const current = node.scale;
            changes.push(`缩放: (${current.x.toFixed(2)}, ${current.y.toFixed(2)}, ${current.z.toFixed(2)}) → (1, 1, 1)`);
        }
        
        return changes;
    }
    
    // ============ 扩展功能 ============
    
    /** 重置所有子节点到父节点中心 */
    public resetToParentCenter() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        if (children.length === 0) return;
        
        console.log("🔄 将子节点重置到父节点中心...");
        
        children.forEach((child, index) => {
            if (this.shouldProcessNode(child)) {
                // 设置位置为父节点中心（相对位置为0）
                child.position = ResetChildrenTransform.DEFAULT_POSITION;
                
                // 可选：排列成圆形或网格
                // this.arrangeInCircle(child, index, children.length);
                
                console.log(`✅ ${child.name} 已移动到父节点中心`);
            }
        });
    }
    
    /** 按网格排列子节点 */
    public arrangeInGrid(columns: number = 3, spacing: number = 100) {
        if (!EDITOR) return;
        
        const children = this.node.children;
        if (children.length === 0) return;
        
        console.log(`📐 按网格排列 ${children.length} 个子节点...`);
        
        children.forEach((child, index) => {
            if (this.shouldProcessNode(child)) {
                const row = Math.floor(index / columns);
                const col = index % columns;
                
                const x = (col - (columns - 1) / 2) * spacing;
                const y = -row * spacing;  // 向下排列
                
                child.position = new Vec3(x, y, 0);
                child.rotation = ResetChildrenTransform.DEFAULT_ROTATION;
                child.scale = ResetChildrenTransform.DEFAULT_SCALE;
                
                console.log(`📍 ${child.name}: (${x.toFixed(1)}, ${y.toFixed(1)})`);
            }
        });
    }
    
    /** 批量重命名子节点 */
    public renameChildren(prefix: string = "Child_") {
        if (!EDITOR) return;
        
        const children = this.node.children;
        if (children.length === 0) return;
        
        console.log("🏷️ 批量重命名子节点...");
        
        children.forEach((child, index) => {
            if (this.shouldProcessNode(child)) {
                const oldName = child.name;
                child.name = `${prefix}${index + 1}`;
                console.log(`🏷️ ${oldName} → ${child.name}`);
            }
        });
    }
    
    /** 导出当前变换状态 */
    public exportTransformData() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        if (children.length === 0) return;
        
        const data = {
            parent: this.node.name,
            timestamp: new Date().toISOString(),
            children: [] as any[]
        };
        
        children.forEach(child => {
            data.children.push({
                name: child.name,
                position: { x: child.position.x, y: child.position.y, z: child.position.z },
                rotation: { 
                    x: child.rotation.x, 
                    y: child.rotation.y, 
                    z: child.rotation.z, 
                    w: child.rotation.w 
                },
                scale: { x: child.scale.x, y: child.scale.y, z: child.scale.z }
            });
        });
        
        console.log("📋 变换数据导出:", JSON.stringify(data, null, 2));
        return data;
    }
    
    // ============ 快捷操作按钮 ============
    
    @property({ displayName: "📐 网格排列(3列)", tooltip: "按3列网格排列子节点" })
    public get arrangeGrid3() {
        return false;
    }
    public set arrangeGrid3(v: boolean) {
        if (EDITOR) this.arrangeInGrid(3, 100);
    }
    
    @property({ displayName: "🌀 重置到中心", tooltip: "将所有子节点重置到父节点中心" })
    public get resetToCenter() {
        return false;
    }
    public set resetToCenter(v: boolean) {
        if (EDITOR) this.resetToParentCenter();
    }
    
    @property({ displayName: "🏷️ 批量重命名", tooltip: "批量重命名子节点为Child_1, Child_2..." })
    public get batchRename() {
        return false;
    }
    public set batchRename(v: boolean) {
        if (EDITOR) this.renameChildren();
    }
}