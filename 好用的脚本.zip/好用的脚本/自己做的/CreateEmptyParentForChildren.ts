import { _decorator, Component, Node, Vec3, Quat } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

//这个写的不好，会把子节点的属性给变化，然后撤销还不能把子节点的属性给撤销回来
/**
 * 给每个子节点创建独立的空父节点
 * 功能：为当前节点的每个直接子节点创建一个空父节点Node（位置0，旋转0，缩放1），并将子节点移动到新父节点下
 * 父节点不复制子节点的任何属性，保持默认状态
 */
@ccclass('CreateEmptyParentForChildren')
@executeInEditMode
export class CreateEmptyParentForChildren extends Component {

    // ============ 配置选项 ============
    
    /** 父节点名称前缀 */
    @property({ displayName: "父节点名称前缀", tooltip: "新创建的父节点将使用此前缀+序号" })
    public parentNamePrefix: string = "Parent_";
    
    /** 保持子节点原始名称 */
    @property({ displayName: "保持子节点名称", tooltip: "是否保持子节点原有的名称不变" })
    public keepChildName: boolean = true;
    
    /** 添加后缀到子节点 */
    @property({ displayName: "子节点后缀", tooltip: "添加到子节点名称后的后缀，为空则不添加" })
    public childSuffix: string = "";
    
    /** 保持子节点世界位置不变 */
    @property({ displayName: "保持世界位置", tooltip: "创建父节点后保持子节点在世界坐标系中的位置不变" })
    public preserveWorldPosition: boolean = true;
    
    /** 重置子节点本地变换 */
    @property({ displayName: "重置子节点本地变换", tooltip: "将子节点在其父节点下的本地变换重置为默认值" }) //就是子节点的位置为0，旋转为0，缩放为1(属性都成了默认)
    public resetChildLocalTransform: boolean = true;
    
    // ============ 默认值 ============
    private static readonly DEFAULT_POSITION = new Vec3(0, 0, 0);
    private static readonly DEFAULT_ROTATION = new Quat(0, 0, 0, 1);
    private static readonly DEFAULT_SCALE = new Vec3(1, 1, 1);
    
    // ============ 操作按钮 ============
    
    /** 执行创建操作 - 编辑器按钮 */
    @property({ displayName: "🔄 执行创建空父节点", tooltip: "点击为每个子节点创建独立的空父节点" })
    public get executeCreate() {
        return false;
    }
    public set executeCreate(v: boolean) {
        if (EDITOR) {
            this.executeParentCreation();
            console.log("✅ 空父节点创建操作执行完成！");
        }
    }
    
    /** 撤销操作 - 移除所有创建的父节点 */
    @property({ displayName: "↩️ 撤销父节点创建", tooltip: "点击移除所有创建的父节点，恢复原始结构" })//撤销不会把子节点的属性也给撤销回来！
    public get executeUndo() {
        return false;
    }
    public set executeUndo(v: boolean) {
        if (EDITOR) {
            this.undoParentCreation();
            console.log("✅ 父节点创建操作已撤销！");
        }
    }
    
    // ============ 核心方法 ============
    
    /** 执行创建空父节点操作 */
    private executeParentCreation() {
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点，无需创建父节点");
            return;
        }
        
        console.log(`🔧 开始为 ${children.length} 个子节点创建空父节点...`);
        
        // 从后往前遍历，避免索引变化问题
        for (let i = children.length - 1; i >= 0; i--) {
            const childNode = children[i];
            this.createEmptyParentForChild(childNode, i);
        }
        
        console.log("✅ 所有空父节点创建完成！");
    }
    
    /** 为单个子节点创建空父节点 */
    private createEmptyParentForChild(childNode: Node, index: number) {
        // 1. 创建空父节点（所有属性都是默认值）
        const parentNode = new Node(this.parentNamePrefix + (index + 1));
        
        // 2. 设置父节点为默认变换（位置0，旋转0，缩放1）
        parentNode.setPosition(CreateEmptyParentForChildren.DEFAULT_POSITION);
        parentNode.setRotation(CreateEmptyParentForChildren.DEFAULT_ROTATION);
        parentNode.setScale(CreateEmptyParentForChildren.DEFAULT_SCALE);
        
        // 3. 将父节点添加到当前节点下
        parentNode.parent = this.node;
        
        if (this.preserveWorldPosition) {
            // 4. 记录子节点的世界变换
            const childWorldPosition = childNode.worldPosition.clone();
            const childWorldRotation = childNode.worldRotation.clone();
            const childWorldScale = childNode.worldScale.clone();
            
            // 5. 将子节点移动到新父节点下
            childNode.parent = parentNode;
            
            // 6. 保持子节点在世界坐标系中的位置不变
            childNode.worldPosition = childWorldPosition;
            childNode.worldRotation = childWorldRotation;
            childNode.worldScale = childWorldScale;
            
            console.log(`✅ 创建空父节点: ${parentNode.name} ← ${childNode.name} (保持世界位置)`);
        } else {
            // 4. 记录子节点的本地变换
            const childLocalPosition = childNode.position.clone();
            const childLocalRotation = childNode.rotation.clone();
            const childLocalScale = childNode.scale.clone();
            
            // 5. 将子节点移动到新父节点下
            childNode.parent = parentNode;
            
            // 6. 恢复子节点在父节点下的本地变换
            childNode.position = childLocalPosition;
            childNode.rotation = childLocalRotation;
            childNode.scale = childLocalScale;
            
            console.log(`✅ 创建空父节点: ${parentNode.name} ← ${childNode.name} (保持本地位置)`);
        }
        
        // 7. 如果需要，重置子节点的本地变换
        if (this.resetChildLocalTransform) {
            childNode.position = CreateEmptyParentForChildren.DEFAULT_POSITION;
            childNode.rotation = CreateEmptyParentForChildren.DEFAULT_ROTATION;
            childNode.scale = CreateEmptyParentForChildren.DEFAULT_SCALE;
            console.log(`   ↪️ 子节点本地变换已重置为默认值`);
        }
        
        // 8. 处理子节点名称
        this.processChildName(childNode, index);
        
        return parentNode;
    }
    
    /** 处理子节点名称 */
    private processChildName(childNode: Node, index: number) {
        if (!this.keepChildName) {
            childNode.name = `Child_${index + 1}`;
        }
        
        if (this.childSuffix) {
            childNode.name += this.childSuffix;
        }
    }
    
    /** 撤销操作：移除所有创建的父节点 */
    private undoParentCreation() {
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点");
            return;
        }
        
        console.log("🔧 开始撤销父节点创建操作...");
        
        // 查找所有前缀匹配的父节点
        const parentNodes: Node[] = [];
        const grandchildren: { node: Node, parentIndex: number, worldPos: Vec3, worldRot: Quat, worldScale: Vec3 }[] = [];
        
        // 收集父节点和它们的子节点
        children.forEach((parentNode, parentIndex) => {
            if (parentNode.name.startsWith(this.parentNamePrefix)) {
                parentNodes.push(parentNode);
                
                // 收集父节点下的所有子节点
                parentNode.children.forEach(childNode => {
                    grandchildren.push({
                        node: childNode,
                        parentIndex: parentIndex,
                        worldPos: childNode.worldPosition.clone(),
                        worldRot: childNode.worldRotation.clone(),
                        worldScale: childNode.worldScale.clone()
                    });
                });
            }
        });
        
        if (parentNodes.length === 0) {
            console.warn("⚠️ 未找到需要移除的父节点");
            return;
        }
        
        // 先将孙子节点移到顶层，保持世界位置不变
        grandchildren.forEach(({ node, parentIndex, worldPos, worldRot, worldScale }) => {
            // 计算原始索引（考虑插入顺序）
            const insertIndex = Math.min(parentIndex, this.node.children.length);
            
            // 移动到顶层
            node.parent = this.node;
            
            // 设置兄弟索引
            node.setSiblingIndex(insertIndex);
            
            // 保持世界位置不变
            node.worldPosition = worldPos;
            node.worldRotation = worldRot;
            node.worldScale = worldScale;
            
            console.log(`   ↪️ 恢复子节点: ${node.name} 到索引 ${insertIndex}`);
        });
        
        // 销毁所有父节点
        parentNodes.forEach(parentNode => {
            console.log(`🗑️ 移除空父节点: ${parentNode.name}`);
            parentNode.destroy();
        });
        
        console.log(`✅ 已移除 ${parentNodes.length} 个空父节点，恢复了 ${grandchildren.length} 个子节点`);
    }
    
    // ============ 高级功能 ============
    
    /** 检查父节点是否为空（所有属性都是默认值） */
    public verifyEmptyParents() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        let emptyCount = 0;
        let nonEmptyCount = 0;
        
        children.forEach(parentNode => {
            if (parentNode.name.startsWith(this.parentNamePrefix)) {
                const isPositionDefault = parentNode.position.equals(CreateEmptyParentForChildren.DEFAULT_POSITION);
                const isRotationDefault = parentNode.rotation.equals(CreateEmptyParentForChildren.DEFAULT_ROTATION);
                const isScaleDefault = parentNode.scale.equals(CreateEmptyParentForChildren.DEFAULT_SCALE);
                
                if (isPositionDefault && isRotationDefault && isScaleDefault) {
                    console.log(`✅ ${parentNode.name}: 空父节点（所有属性为默认值）`);
                    emptyCount++;
                } else {
                    console.log(`❌ ${parentNode.name}: 非空父节点`);
                    console.log(`   位置: ${parentNode.position} 期望: (0,0,0)`);
                    console.log(`   缩放: ${parentNode.scale} 期望: (1,1,1)`);
                    nonEmptyCount++;
                }
            }
        });
        
        console.log(`📊 检查完成: ${emptyCount} 个空父节点, ${nonEmptyCount} 个非空父节点`);
    }
    
    /** 修正非空父节点 */
    public fixNonEmptyParents() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        let fixedCount = 0;
        
        children.forEach(parentNode => {
            if (parentNode.name.startsWith(this.parentNamePrefix)) {
                const isPositionDefault = parentNode.position.equals(CreateEmptyParentForChildren.DEFAULT_POSITION);
                const isRotationDefault = parentNode.rotation.equals(CreateEmptyParentForChildren.DEFAULT_ROTATION);
                const isScaleDefault = parentNode.scale.equals(CreateEmptyParentForChildren.DEFAULT_SCALE);
                
                if (!isPositionDefault || !isRotationDefault || !isScaleDefault) {
                    // 修正为默认值
                    parentNode.position = CreateEmptyParentForChildren.DEFAULT_POSITION;
                    parentNode.rotation = CreateEmptyParentForChildren.DEFAULT_ROTATION;
                    parentNode.scale = CreateEmptyParentForChildren.DEFAULT_SCALE;
                    
                    console.log(`🔧 修正父节点: ${parentNode.name}`);
                    fixedCount++;
                }
            }
        });
        
        console.log(`✅ 已修正 ${fixedCount} 个非空父节点`);
    }
    
    /** 批量设置父节点属性（保持为空） */
    public batchSetParentProperties() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        
        children.forEach((parentNode, index) => {
            // 确保父节点保持为空
            parentNode.position = CreateEmptyParentForChildren.DEFAULT_POSITION;
            parentNode.rotation = CreateEmptyParentForChildren.DEFAULT_ROTATION;
            parentNode.scale = CreateEmptyParentForChildren.DEFAULT_SCALE;
            
            // 可以在这里添加其他属性设置，但不影响变换
            console.log(`⚙️ 确保父节点为空: ${parentNode.name}`);
        });
    }
    
    // ============ 快捷操作按钮 ============
    
    @property({ displayName: "🔍 检查父节点状态", tooltip: "检查所有父节点是否为空" })
    public get checkParentStatus() {
        return false;
    }
    public set checkParentStatus(v: boolean) {
        if (EDITOR) this.verifyEmptyParents();
    }
    
    @property({ displayName: "🔧 修正非空父节点", tooltip: "将所有非空父节点修正为空状态" })
    public get fixParents() {
        return false;
    }
    public set fixParents(v: boolean) {
        if (EDITOR) this.fixNonEmptyParents();
    }
    
    // ============ 扩展：批量操作 ============
    
    /** 批量添加组件到父节点 */
    public addComponentToParents(componentName: string) {
        if (!EDITOR) return;
        
        const children = this.node.children;
        let addedCount = 0;
        
        children.forEach(parentNode => {
            if (parentNode.name.startsWith(this.parentNamePrefix)) {
                if (!parentNode.getComponent(componentName as any)) {
                    parentNode.addComponent(componentName);
                    addedCount++;
                    console.log(`➕ 添加组件 ${componentName} 到 ${parentNode.name}`);
                }
            }
        });
        
        console.log(`✅ 已添加组件到 ${addedCount} 个父节点`);
    }
    
    /** 设置父节点层级 */
    public setParentLayer(layer: number) {
        if (!EDITOR) return;
        
        const children = this.node.children;
        
        children.forEach(parentNode => {
            if (parentNode.name.startsWith(this.parentNamePrefix)) {
                parentNode.layer = layer;
                console.log(`🏷️ 设置层级 ${layer} 到 ${parentNode.name}`);
            }
        });
        
        console.log(`✅ 已设置层级到所有父节点`);
    }
}