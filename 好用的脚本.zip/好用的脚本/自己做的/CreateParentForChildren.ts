import { _decorator, Component, Node } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 给每个子节点创建独立的父节点
 * 功能：为当前节点的每个直接子节点创建一个父节点Node，并将子节点移动到新父节点下。但是会把每个子节点的位置，旋转，缩放赋值给父节点
 * 可用于组织层级结构、分组管理等场景
 */
@ccclass('CreateParentForChildren')
@executeInEditMode
export class CreateParentForChildren extends Component {

    // ============ 配置选项 ============
    
    /** 父节点名称前缀 */
    @property({ displayName: "父节点名称前缀", tooltip: "新创建的父节点将使用此前缀+序号" })
    public parentNamePrefix: string = "Parent_";
    
    /** 保持子节点原始名称 */
    @property({ displayName: "保持子节点名称", tooltip: "是否保持子节点原有的名称不变" })
    public keepChildName: boolean = true;
    
    /** 添加后缀到子节点 */
    @property({ displayName: "子节点后缀", tooltip: "添加到子节点名称后的后缀，为空则不添加" })
    public childSuffix: string = "";
    
    /** 保持子节点原始位置 */
    @property({ displayName: "保持原始位置", tooltip: "创建父节点后保持子节点在世界坐标系中的位置不变" })
    public preserveWorldPosition: boolean = true;
    
    // ============ 操作按钮 ============
    
    /** 执行创建操作 - 编辑器按钮 */
    @property({ displayName: "🔄 执行创建父节点", tooltip: "点击为每个子节点创建独立的父节点" })
    public get executeCreate() {
        return false;
    }
    public set executeCreate(v: boolean) {
        if (EDITOR) {
            this.executeParentCreation();
            console.log("✅ 父节点创建操作执行完成！");
        }
    }
    
    /** 撤销操作 - 移除所有创建的父节点 */
    @property({ displayName: "↩️ 撤销父节点创建", tooltip: "点击移除所有创建的父节点，恢复原始结构" })
    public get executeUndo() {
        return false;
    }
    public set executeUndo(v: boolean) {
        if (EDITOR) {
            this.undoParentCreation();
            console.log("✅ 父节点创建操作已撤销！");
        }
    }
    
    // ============ 核心方法 ============
    
    /** 执行创建父节点操作 */
    private executeParentCreation() {
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点，无需创建父节点");
            return;
        }
        
        console.log(`🔧 开始为 ${children.length} 个子节点创建父节点...`);
        
        // 从后往前遍历，避免索引变化问题
        for (let i = children.length - 1; i >= 0; i--) {
            const childNode = children[i];
            this.createParentForChild(childNode, i);
        }
        
        console.log("✅ 所有父节点创建完成！");
    }
    
    /** 为单个子节点创建父节点 */
    private createParentForChild(childNode: Node, index: number) {
        // 1. 创建父节点
        const parentNode = new Node(this.parentNamePrefix + (index + 1));
        
        // 2. 设置父节点的位置和旋转
        if (this.preserveWorldPosition) {
            // 保持子节点在世界坐标系中的位置不变
            const worldPosition = childNode.worldPosition.clone();
            const worldRotation = childNode.worldRotation.clone();
            const worldScale = childNode.worldScale.clone();
            
            // 先将父节点添加到当前节点下
            parentNode.parent = this.node;
            
            // 设置父节点的变换，使子节点位置不变
            parentNode.worldPosition = worldPosition;
            parentNode.worldRotation = worldRotation;
            parentNode.worldScale = worldScale;
            
            // 将子节点移动到新父节点下，并重置其本地变换
            childNode.parent = parentNode;
            childNode.position = this.node.worldPosition.clone();
            childNode.rotation = this.node.worldRotation.clone();
            childNode.scale = this.node.worldScale.clone();
        } else {
            // 简单方式：直接设置父子关系
            parentNode.parent = this.node;
            
            // 记录子节点的本地变换
            const localPosition = childNode.position.clone();
            const localRotation = childNode.rotation.clone();
            const localScale = childNode.scale.clone();
            
            // 移动子节点到新父节点下
            childNode.parent = parentNode;
            
            // 恢复子节点的本地变换
            childNode.position = localPosition;
            childNode.rotation = localRotation;
            childNode.scale = localScale;
        }
        
        // 3. 处理子节点名称
        if (!this.keepChildName) {
            childNode.name = `Child_${index + 1}`;
        }
        
        if (this.childSuffix) {
            childNode.name += this.childSuffix;
        }
        
        console.log(`✅ 创建父节点: ${parentNode.name} ← ${childNode.name}`);
        
        return parentNode;
    }
    
    /** 撤销操作：移除所有创建的父节点 */
    private undoParentCreation() {
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点");
            return;
        }
        
        console.log("🔧 开始撤销父节点创建操作...");
        
        // 查找所有前缀匹配的父节点
        const parentNodes: Node[] = [];
        const grandchildren: { node: Node, parentIndex: number }[] = [];
        
        // 收集父节点和它们的子节点
        children.forEach((parentNode, parentIndex) => {
            if (parentNode.name.startsWith(this.parentNamePrefix)) {
                parentNodes.push(parentNode);
                
                // 收集父节点下的所有子节点
                parentNode.children.forEach(childNode => {
                    grandchildren.push({
                        node: childNode,
                        parentIndex: parentIndex
                    });
                });
            }
        });
        
        if (parentNodes.length === 0) {
            console.warn("⚠️ 未找到需要移除的父节点");
            return;
        }
        
        // 先将孙子节点移到顶层
        grandchildren.forEach(({ node, parentIndex }) => {
            // 计算原始索引（考虑插入顺序）
            const insertIndex = parentIndex < this.node.children.length ? 
                parentIndex : this.node.children.length;
            
            // 保持原来的世界位置
            const worldPosition = node.worldPosition.clone();
            const worldRotation = node.worldRotation.clone();
            const worldScale = node.worldScale.clone();
            
            // 移动到顶层
            node.parent = this.node;
            
            // 设置兄弟索引
            node.setSiblingIndex(insertIndex);
            
            // 保持世界位置不变
            node.worldPosition = worldPosition;
            node.worldRotation = worldRotation;
            node.worldScale = worldScale;
        });
        
        // 销毁所有父节点
        parentNodes.forEach(parentNode => {
            console.log(`🗑️ 移除父节点: ${parentNode.name}`);
            parentNode.destroy();
        });
        
        console.log(`✅ 已移除 ${parentNodes.length} 个父节点`);
    }
    
    // ============ 高级功能 ============
    
    /** 批量设置父节点属性（可选功能） */
    public batchSetParentProperties() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        
        children.forEach((parentNode, index) => {
            // 可以在这里批量设置父节点的属性
            // 例如：添加组件、设置层、添加标签等
            
            // 示例：为每个父节点添加一个Group组件（如果存在）
            /*
            if (parentNode.getComponent('GroupComponent') === null) {
                parentNode.addComponent('GroupComponent');
            }
            */
            
            console.log(`⚙️ 设置父节点属性: ${parentNode.name}`);
        });
    }
    
    /** 智能分组：根据名称或类型自动分组（可选功能） */
    public smartGrouping() {
        if (!EDITOR) return;
        
        const children = this.node.children;
        const groups = new Map<string, Node[]>();
        
        // 按名称模式分组
        children.forEach(child => {
            // 示例：按名称前缀分组
            let groupKey = "Default";
            
            // 可以根据实际需求修改分组逻辑
            if (child.name.includes("Player")) groupKey = "Players";
            else if (child.name.includes("Enemy")) groupKey = "Enemies";
            else if (child.name.includes("Item")) groupKey = "Items";
            else if (child.name.includes("Effect")) groupKey = "Effects";
            
            if (!groups.has(groupKey)) {
                groups.set(groupKey, []);
            }
            groups.get(groupKey)!.push(child);
        });
        
        // 为每个分组创建父节点
        let groupIndex = 0;
        groups.forEach((groupChildren, groupName) => {
            if (groupChildren.length > 0) {
                // 创建分组父节点
                const groupParent = new Node(`Group_${groupName}`);
                groupParent.parent = this.node;
                
                // 将子节点移动到分组父节点下
                groupChildren.forEach(child => {
                    const worldPosition = child.worldPosition.clone();
                    const worldRotation = child.worldRotation.clone();
                    const worldScale = child.worldScale.clone();
                    
                    child.parent = groupParent;
                    child.worldPosition = worldPosition;
                    child.worldRotation = worldRotation;
                    child.worldScale = worldScale;
                });
                
                groupIndex++;
            }
        });
        
        console.log(`✅ 智能分组完成，创建了 ${groups.size} 个分组`);
    }
}