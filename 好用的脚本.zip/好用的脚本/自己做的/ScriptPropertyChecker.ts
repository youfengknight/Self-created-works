import { _decorator, Component, Node, isValid } from 'cc';
const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 脚本属性检查器，可以检查脚本属性是否挂载。（也就是说是把所有组件没有@property装饰的属性列出来）
 * 用法：
 * 1. 将本脚本附加到一个空节点上。
 * 2. 设置检查范围（包括子节点）。
 * 3. 点击刷新按钮或在启动时自动检查。
 * 4. 查看控制台输出的检查结果。（包含未挂载的属性和已正确挂载的属性）
 */
@ccclass('ScriptPropertyChecker')
@executeInEditMode
export class ScriptPropertyChecker extends Component {
    @property({
        tooltip: '是否包括子节点'
    })
    includeChildren: boolean = true;

    @property({
        tooltip: '是否在启动时自动检查'
    })
    autoCheckOnStart: boolean = false;

    @property({
        tooltip: '是否显示已正确挂载的属性'
    })
    showValidProperties: boolean = false;

    @property({
        type: Node,
        tooltip: '自定义检查的根节点（为空则使用当前节点）'
    })
    customRootNode: Node = null!;

    @property({
        visible: function (this: any) {
            // 在编辑器中显示刷新按钮
            return !!(window as any).cc && !!(window as any).cc.internal;
        }
    })
    private _refreshButton: boolean = false;

    @property
    get refreshButton() {
        return this._refreshButton;
    }
    
    set refreshButton(value: boolean) {
        if (value) {
            this.checkAllScripts();
        }
        this._refreshButton = false;
    }

    start() {
        if (this.autoCheckOnStart) {
            this.checkAllScripts();
        }
    }

    /**
     * 检查所有脚本的未挂载属性
     */
    public checkAllScripts(): void {
        const rootNode = this.customRootNode || this.node;
        console.log('=== 开始检查脚本属性 ===');
        console.log('检查根节点: ' + rootNode.name);
        
        this._checkNodeRecursive(rootNode, 0);
        
        console.log('=== 检查完成 ===');
    }

    /**
     * 递归检查节点及其子节点
     */
    private _checkNodeRecursive(node: Node, depth: number): void {
        if (!isValid(node)) {
            return;
        }

        var indent = '';
        for (var i = 0; i < depth; i++) {
            indent += '  ';
        }
        console.log(indent + '节点: ' + node.name);
        
        // 获取节点上的所有组件
        var components = node.getComponents(Component);
        
        for (var j = 0; j < components.length; j++) {
            var component = components[j];
            this._checkComponentProperties(component, depth + 1);
        }
        
        // 递归检查子节点
        if (this.includeChildren && node.children.length > 0) {
            for (var k = 0; k < node.children.length; k++) {
                var child = node.children[k];
                this._checkNodeRecursive(child, depth + 1);
            }
        }
    }

    /**
     * 检查单个组件的属性
     */
    private _checkComponentProperties(component: Component, depth: number): void {
        var indent = '';
        for (var i = 0; i < depth; i++) {
            indent += '  ';
        }
        var componentName = component.constructor.name;
        
        console.log(indent + '└─ 脚本: ' + componentName);
        
        // 使用传统的原型链遍历方法
        var propertyNames = this._getAllPropertyNames(component);
        
        var hasUnassignedProperties = false;
        
        for (var j = 0; j < propertyNames.length; j++) {
            var propertyName = propertyNames[j];
            
            // 跳过内置属性和方法
            if (this._shouldSkipProperty(propertyName)) {
                continue;
            }
            
            // 检查属性值
            var value = (component as any)[propertyName];
            var isUnassigned = this._isPropertyUnassigned(value);
            
            if (isUnassigned) {
                hasUnassignedProperties = true;
                console.log(indent + '    ❌ 未挂载: ' + propertyName);
            } else if (this.showValidProperties) {
                console.log(indent + '    ✅ 已挂载: ' + propertyName + ' = ' + this._formatValue(value));
            }
        }
        
        if (!hasUnassignedProperties) {
            console.log(indent + '    ✓ 所有属性已正确挂载');
        }
    }

    /**
     * 获取对象及其原型链上的所有属性名
     */
    private _getAllPropertyNames(obj: any): string[] {
        var props: string[] = [];
        var current = obj;
        
        while (current && current !== Object.prototype) {
            var ownProps = Object.getOwnPropertyNames(current);
            
            for (var i = 0; i < ownProps.length; i++) {
                var prop = ownProps[i];
                if (props.indexOf(prop) === -1) {
                    props.push(prop);
                }
            }
            
            current = Object.getPrototypeOf(current);
        }
        
        return props;
    }

    /**
     * 判断是否需要跳过该属性
     */
    private _shouldSkipProperty(propertyName: string): boolean {
        // 跳过以_开头的私有属性
        if (propertyName.charAt(0) === '_') {
            return true;
        }
        
        // 跳过内置属性
        var skipProperties = [
            'name', 'node', 'uuid', 'enabled', 
            '__classname__', '__type__', '__prefab',
            'constructor', 'prototype', 'length'
        ];
        
        if (skipProperties.indexOf(propertyName) !== -1) {
            return true;
        }
        
        return false;
    }

    /**
     * 判断属性是否未挂载
     */
    private _isPropertyUnassigned(value: any): boolean {
        if (value === null || value === undefined) {
            return true;
        }
        
        // 检查数组是否为空
        if (Array.isArray(value) && value.length === 0) {
            return true;
        }
        
        // 检查节点或组件是否有效
        if (value instanceof Node || value instanceof Component) {
            return !isValid(value);
        }
        
        // 检查对象是否为空
        if (typeof value === 'object' && value !== null) {
            var keys = Object.keys(value);
            return keys.length === 0;
        }
        
        return false;
    }

    /**
     * 格式化输出值
     */
    private _formatValue(value: any): string {
        if (value === null) {
            return 'null';
        }
        if (value === undefined) {
            return 'undefined';
        }
        
        if (value instanceof Node) {
            return 'Node(' + value.name + ')';
        }
        
        if (value instanceof Component) {
            return 'Component(' + value.constructor.name + ')';
        }
        
        if (Array.isArray(value)) {
            return 'Array[' + value.length + ']';
        }
        
        if (typeof value === 'object' && value !== null) {
            var keys = Object.keys(value);
            return 'Object{' + keys.length + '}';
        }
        
        return String(value);
    }

    /**
     * 清除所有日志
     */
    public clearConsole(): void {
        // 简单的清空控制台方法
        console.log('\n'.repeat(50));
        console.log('=== 控制台已清空 ===');
    }

    /**
     * 导出检查报告
     */
    public exportReport(): void {
        var rootNode = this.customRootNode || this.node;
        var report: any = {
            timestamp: new Date().toISOString(),
            rootNode: rootNode.name,
            includeChildren: this.includeChildren,
            scripts: []
        };

        this._collectReportData(rootNode, report);
        
        // 输出JSON格式报告
        console.log('=== 脚本属性检查报告 ===');
        console.log(JSON.stringify(report, null, 2));
        
        // 复制到剪贴板（仅浏览器环境）
        if (typeof navigator !== 'undefined' && navigator.clipboard) {
            var reportText = JSON.stringify(report, null, 2);
            navigator.clipboard.writeText(reportText)
                .then(function() {
                    console.log('报告已复制到剪贴板');
                })
                .catch(function(err) {
                    console.error('复制失败:', err);
                });
        }
    }

    private _collectReportData(node: Node, report: any): void {
        var nodeInfo: any = {
            name: node.name,
            path: this._getNodePath(node),
            components: []
        };

        var components = node.getComponents(Component);
        for (var i = 0; i < components.length; i++) {
            var component = components[i];
            var componentInfo = this._collectComponentInfo(component);
            if (componentInfo.unassignedProperties.length > 0) {
                nodeInfo.components.push(componentInfo);
            }
        }

        if (nodeInfo.components.length > 0) {
            report.scripts.push(nodeInfo);
        }

        if (this.includeChildren) {
            for (var j = 0; j < node.children.length; j++) {
                var child = node.children[j];
                this._collectReportData(child, report);
            }
        }
    }

    private _getNodePath(node: Node): string {
        var path = node.name;
        var parent = node.parent;
        
        while (parent) {
            path = parent.name + '/' + path;
            parent = parent.parent;
        }
        
        return path;
    }

    private _collectComponentInfo(component: Component): any {
        var propertyNames = this._getAllPropertyNames(component);
        var unassignedProperties: any[] = [];

        for (var i = 0; i < propertyNames.length; i++) {
            var propertyName = propertyNames[i];
            
            if (this._shouldSkipProperty(propertyName)) {
                continue;
            }
            
            var value = (component as any)[propertyName];
            if (this._isPropertyUnassigned(value)) {
                unassignedProperties.push({
                    name: propertyName
                });
            }
        }

        return {
            name: component.constructor.name,
            unassignedProperties: unassignedProperties
        };
    }

    /**
     * 手动触发检查的简单方法
     */
    public manualCheck(): void {
        this.checkAllScripts();
    }

    /**
     * 检查特定节点
     */
    public checkSpecificNode(node: Node): void {
        console.log('=== 检查特定节点 ===');
        console.log('节点: ' + node.name);
        this._checkNodeRecursive(node, 0);
        console.log('=== 检查完成 ===');
    }

    /**
     * 获取未挂载属性的统计信息
     */
    public getStatistics(): any {
        var rootNode = this.customRootNode || this.node;
        var stats = {
            totalNodes: 0,
            totalComponents: 0,
            totalUnassignedProperties: 0,
            nodesWithUnassignedProperties: [] as any[]
        };

        this._collectStatistics(rootNode, stats);
        
        console.log('=== 统计信息 ===');
        console.log('总节点数: ' + stats.totalNodes);
        console.log('总组件数: ' + stats.totalComponents);
        console.log('未挂载属性总数: ' + stats.totalUnassignedProperties);
        
        return stats;
    }

    private _collectStatistics(node: Node, stats: any): void {
        stats.totalNodes++;
        
        var components = node.getComponents(Component);
        stats.totalComponents += components.length;
        
        var nodeHasUnassigned = false;
        var nodeUnassignedCount = 0;
        
        for (var i = 0; i < components.length; i++) {
            var component = components[i];
            var unassignedProps = this._getUnassignedPropertiesForComponent(component);
            
            if (unassignedProps.length > 0) {
                nodeHasUnassigned = true;
                nodeUnassignedCount += unassignedProps.length;
                stats.totalUnassignedProperties += unassignedProps.length;
            }
        }
        
        if (nodeHasUnassigned) {
            stats.nodesWithUnassignedProperties.push({
                nodeName: node.name,
                nodePath: this._getNodePath(node),
                unassignedCount: nodeUnassignedCount
            });
        }
        
        if (this.includeChildren) {
            for (var j = 0; j < node.children.length; j++) {
                this._collectStatistics(node.children[j], stats);
            }
        }
    }

    private _getUnassignedPropertiesForComponent(component: Component): string[] {
        var unassigned: string[] = [];
        var propertyNames = this._getAllPropertyNames(component);
        
        for (var i = 0; i < propertyNames.length; i++) {
            var propertyName = propertyNames[i];
            
            if (this._shouldSkipProperty(propertyName)) {
                continue;
            }
            
            var value = (component as any)[propertyName];
            if (this._isPropertyUnassigned(value)) {
                unassigned.push(propertyName);
            }
        }
        
        return unassigned;
    }
}