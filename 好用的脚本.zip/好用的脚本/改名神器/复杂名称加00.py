import os
import re

def rename_files_in_directory(directory='.'):
    """
    重命名指定目录下的文件：
    1. 将单个数字的文件名补零，如1.png -> 01.png
    2. 将括号内的单个数字补零，如xiaohuo (1).jpg -> xiaohuo (01).jpg
    3. 将字母/汉字后的单个数字补零，如火 1.jpg -> 火 01.jpg, 火1.jpg -> 火01.jpg
    """
    # 遍历目录中的所有文件
    for filename in os.listdir(directory):
        # 跳过目录，只处理文件
        if os.path.isdir(os.path.join(directory, filename)):
            continue
            
        # 分离文件名和扩展名
        name, ext = os.path.splitext(filename)
        renamed = False
        
        # 情况1：文件名就是单个数字
        if re.match(r'^\d$', name):
            # 补零并重命名
            new_name = f"{name.zfill(2)}{ext}"
            old_path = os.path.join(directory, filename)
            new_path = os.path.join(directory, new_name)
            
            try:
                os.rename(old_path, new_path)
                print(f"重命名: {filename} -> {new_name}")
                renamed = True
            except Exception as e:
                print(f"重命名失败 {filename}: {e}")
        
        # 情况2：文件名中包含括号，且括号内是单个数字
        if not renamed:
            # 匹配括号内的单个数字（支持中文和英文括号）
            pattern = re.compile(r'([\(\（])\s*(\d)\s*([\)\）])')
            match = pattern.search(name)
            
            if match:
                left_bracket = match.group(1)
                number = match.group(2)
                right_bracket = match.group(3)
                
                # 补零并替换
                new_number = number.zfill(2)
                # 保持原始的空格格式
                original_part = match.group(0)
                # 根据原始格式重建，保留可能的空格
                left_space = original_part.split(number)[0]
                right_space = original_part.split(number)[1]
                new_part = f"{left_space}{new_number}{right_space}"
                
                new_name = name.replace(original_part, new_part) + ext
                old_path = os.path.join(directory, filename)
                new_path = os.path.join(directory, new_name)
                
                try:
                    os.rename(old_path, new_path)
                    print(f"重命名: {filename} -> {new_name}")
                    renamed = True
                except Exception as e:
                    print(f"重命名失败 {filename}: {e}")
        
        # 情况3：字母/汉字后的单个数字
        if not renamed:
            # 匹配字母/汉字后的单个数字
            # 支持：火 1.jpg, 火1.jpg, h1.jpg, h 1.jpg
            pattern = re.compile(r'([^\d\s]+)(\s*)(\d)$')
            match = pattern.search(name)
            
            if match:
                prefix = match.group(1)  # 字母/汉字部分
                space = match.group(2)   # 空格部分（可能为空）
                number = match.group(3)  # 数字部分
                
                # 只处理单个数字的情况
                if len(number) == 1:
                    # 补零
                    new_number = number.zfill(2)
                    new_name = f"{prefix}{space}{new_number}{ext}"
                    old_path = os.path.join(directory, filename)
                    new_path = os.path.join(directory, new_name)
                    
                    try:
                        os.rename(old_path, new_path)
                        print(f"重命名: {filename} -> {new_name}")
                        renamed = True
                    except Exception as e:
                        print(f"重命名失败 {filename}: {e}")

def main():
    """主函数"""
    print("文件重命名工具")
    print("功能：")
    print("1. 重命名单个数字的文件名，如 1.png -> 01.png")
    print("2. 重命名括号内的单个数字，如 xiaohuo (1).jpg -> xiaohuo (01).jpg")
    print("3. 重命名字母/汉字后的单个数字，如火 1.jpg -> 火 01.jpg, 火1.jpg -> 火01.jpg")
    print()
    
    # 让用户选择目录
    directory = input("请输入要处理的目录路径（直接回车使用当前目录）: ").strip()
    if not directory:
        directory = '.'
    
    # 检查目录是否存在
    if not os.path.isdir(directory):
        print(f"错误：目录 '{directory}' 不存在！")
        return
    
    print(f"\n开始处理目录：{directory}")
    
    # 先显示将要被重命名的文件
    print("\n将要被重命名的文件：")
    found_files = False
    
    for filename in os.listdir(directory):
        if os.path.isdir(os.path.join(directory, filename)):
            continue
            
        name, ext = os.path.splitext(filename)
        
        # 检查是否是单个数字的文件名
        if re.match(r'^\d$', name):
            new_name = f"{name.zfill(2)}{ext}"
            print(f"  {filename} -> {new_name}")
            found_files = True
        
        # 检查是否包含括号内的单个数字
        else:
            pattern = re.compile(r'([\(\（])\s*(\d)\s*([\)\）])')
            match = pattern.search(name)
            
            if match:
                number = match.group(2)
                new_number = number.zfill(2)
                new_name = pattern.sub(fr'\1{new_number}\3', name) + ext
                print(f"  {filename} -> {new_name}")
                found_files = True
        
        # 检查是否是字母/汉字后的单个数字
        if not found_files:
            pattern = re.compile(r'([^\d\s]+)(\s*)(\d)$')
            match = pattern.search(name)
            
            if match:
                number = match.group(3)
                if len(number) == 1:
                    new_number = number.zfill(2)
                    new_name = pattern.sub(fr'\1\2{new_number}', name) + ext
                    print(f"  {filename} -> {new_name}")
                    found_files = True
    
    if not found_files:
        print("  没有找到需要重命名的文件")
        return
    
    # 确认操作
    print()
    confirm = input("确定要执行重命名吗？(y/n): ").strip().lower()
    
    if confirm == 'y' or confirm == 'yes':
        rename_files_in_directory(directory)
        print("\n重命名完成！")
    else:
        print("操作已取消")

if __name__ == "__main__":
    main()