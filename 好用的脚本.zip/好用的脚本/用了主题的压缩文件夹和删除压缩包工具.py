import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import zipfile

class SimpleFolderCompressor:
    def __init__(self, root):
        self.root = root
        self.root.title("文件夹压缩工具")
        self.root.geometry("500x400")
        
        # 居中显示
        self.center_window()
        
        # 创建界面
        self.create_widgets()
        self.update_status()
    
    def center_window(self):
        """窗口居中"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        """创建界面"""
        # 标题
        title = tk.Label(self.root, 
                        text="文件夹压缩工具",
                        font=("Arial", 16, "bold"),
                        bg="#2196F3",
                        fg="white",
                        pady=10)
        title.pack(fill=tk.X)
        
        # 当前目录
        dir_frame = tk.Frame(self.root, bg="white", padx=10, pady=10)
        dir_frame.pack(fill=tk.X)
        
        tk.Label(dir_frame, 
                text="当前目录:",
                font=("Arial", 10, "bold"),
                bg="white").pack(anchor=tk.W)
        
        self.dir_label = tk.Label(dir_frame, 
                                 text="",
                                 font=("Arial", 9),
                                 bg="white",
                                 fg="#666",
                                 wraplength=450)
        self.dir_label.pack(anchor=tk.W, pady=5)
        
        # 控制按钮
        control_frame = tk.Frame(self.root, bg="#f5f5f5", padx=10, pady=10)
        control_frame.pack(fill=tk.X)
        
        tk.Button(control_frame,
                 text="刷新",
                 command=self.update_status,
                 bg="#4CAF50",
                 fg="white",
                 padx=15).pack(side=tk.LEFT, padx=5)
        
        tk.Button(control_frame,
                 text="更改目录",
                 command=self.change_directory,
                 bg="#2196F3",
                 fg="white",
                 padx=15).pack(side=tk.LEFT, padx=5)
        
        # 状态显示
        status_frame = tk.LabelFrame(self.root, 
                                    text="状态信息",
                                    font=("Arial", 11, "bold"),
                                    padx=10, pady=10)
        status_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.status_text = tk.Text(status_frame,
                                  height=10,
                                  font=("Consolas", 9),
                                  bg="#fafafa",
                                  relief=tk.FLAT)
        self.status_text.pack(fill=tk.BOTH, expand=True)
        self.status_text.config(state=tk.DISABLED)
        
        # 功能按钮
        btn_frame = tk.Frame(self.root, bg="#f5f5f5", pady=10)
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame,
                 text="压缩文件夹",
                 command=self.compress_folder,
                 bg="#FF9800",
                 fg="white",
                 font=("Arial", 11, "bold"),
                 padx=20,
                 pady=8).pack(side=tk.LEFT, padx=20)
        
        tk.Button(btn_frame,
                 text="删除压缩包",
                 command=self.delete_zips,
                 bg="#F44336",
                 fg="white",
                 font=("Arial", 11, "bold"),
                 padx=20,
                 pady=8).pack(side=tk.LEFT)
        
        # 退出按钮
        tk.Button(self.root,
                 text="退出",
                 command=self.root.quit,
                 bg="#9E9E9E",
                 fg="white",
                 padx=30,
                 pady=5).pack(pady=10)
    
    def change_directory(self):
        new_dir = filedialog.askdirectory()
        if new_dir:
            os.chdir(new_dir)
            self.update_status()
    
    def update_status(self):
        current_dir = os.getcwd()
        self.dir_label.config(text=current_dir)
        
        folders = [f for f in os.listdir('.') if os.path.isdir(f) and not f.startswith('.')]
        zips = [f for f in os.listdir('.') if f.lower().endswith('.zip')]
        
        info = f"📁 文件夹: {len(folders)} 个\n"
        if folders:
            info += "  " + ", ".join(folders[:5])
            if len(folders) > 5:
                info += f" ...等{len(folders)}个"
        info += "\n\n📦 ZIP文件: " + ("无" if not zips else f"{len(zips)} 个")
        
        self.status_text.config(state=tk.NORMAL)
        self.status_text.delete(1.0, tk.END)
        self.status_text.insert(1.0, info)
        self.status_text.config(state=tk.DISABLED)
    
    def compress_folder(self):
        folders = [f for f in os.listdir('.') if os.path.isdir(f) and not f.startswith('.')]
        
        if not folders:
            messagebox.showwarning("警告", "没有找到文件夹！")
            return
        
        # 简化：总是压缩第一个文件夹
        folder = folders[0]
        if messagebox.askyesno("确认", f"压缩文件夹 '{folder}'？"):
            zip_name = f"{folder}.zip"
            try:
                with zipfile.ZipFile(zip_name, 'w') as zipf:
                    for root, dirs, files in os.walk(folder):
                        for file in files:
                            file_path = os.path.join(root, file)
                            zipf.write(file_path)
                messagebox.showinfo("成功", f"已创建: {zip_name}")
                self.update_status()
            except Exception as e:
                messagebox.showerror("错误", str(e))
    
    def delete_zips(self):
        zips = [f for f in os.listdir('.') if f.lower().endswith('.zip')]
        if not zips:
            messagebox.showinfo("提示", "没有ZIP文件")
            return
        
        if messagebox.askyesno("确认", f"删除 {len(zips)} 个ZIP文件？"):
            for zip_file in zips:
                try:
                    os.remove(zip_file)
                except:
                    pass
            self.update_status()

def main():
    root = tk.Tk()
    app = SimpleFolderCompressor(root)
    root.mainloop()

if __name__ == "__main__":
    main()