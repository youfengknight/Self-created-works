import sqlite3
import json
from pathlib import Path
from typing import List, Optional
from datetime import datetime
from models import ScriptMetadata

class MetadataManager:
    def __init__(self, db_path: str = "scripts.db"):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scripts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_path TEXT UNIQUE NOT NULL,
                file_name TEXT NOT NULL,
                file_size INTEGER,
                created_time TEXT,
                modified_time TEXT,
                functions TEXT,
                variables TEXT,
                imports TEXT,
                tags TEXT,
                description TEXT,
                use_count INTEGER DEFAULT 0,
                last_used TEXT,
                is_archived INTEGER DEFAULT 0
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_script(self, metadata: ScriptMetadata):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO scripts 
                (file_path, file_name, file_size, created_time, modified_time, 
                 functions, variables, imports, tags, description, use_count, 
                 last_used, is_archived)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                metadata.file_path,
                metadata.file_name,
                metadata.file_size,
                metadata.created_time.isoformat(),
                metadata.modified_time.isoformat(),
                json.dumps(metadata.functions),
                json.dumps(metadata.variables),
                json.dumps(metadata.imports),
                json.dumps(metadata.tags),
                metadata.description,
                metadata.use_count,
                metadata.last_used.isoformat() if metadata.last_used else None,
                1 if metadata.is_archived else 0
            ))
            conn.commit()
        except sqlite3.IntegrityError:
            pass
        finally:
            conn.close()
    
    def get_all_scripts(self, include_archived: bool = False) -> List[ScriptMetadata]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = "SELECT * FROM scripts"
        if not include_archived:
            query += " WHERE is_archived = 0"
        
        cursor.execute(query)
        rows = cursor.fetchall()
        conn.close()
        
        scripts = []
        for row in rows:
            scripts.append(self._row_to_metadata(row))
        
        return scripts
    
    def get_script_by_path(self, file_path: str) -> Optional[ScriptMetadata]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM scripts WHERE file_path = ?", (file_path,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return self._row_to_metadata(row)
        return None
    
    def update_script(self, metadata: ScriptMetadata):
        self.add_script(metadata)
    
    def increment_use_count(self, file_path: str):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE scripts 
            SET use_count = use_count + 1, last_used = ?
            WHERE file_path = ?
        ''', (datetime.now().isoformat(), file_path))
        
        conn.commit()
        conn.close()
    
    def get_most_used_scripts(self, limit: int = 10) -> List[ScriptMetadata]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM scripts 
            WHERE is_archived = 0
            ORDER BY use_count DESC 
            LIMIT ?
        ''', (limit,))
        
        rows = cursor.fetchall()
        conn.close()
        
        scripts = []
        for row in rows:
            scripts.append(self._row_to_metadata(row))
        
        return scripts
    
    def get_unused_scripts(self, days: int = 30) -> List[ScriptMetadata]:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        threshold = datetime.now().timestamp() - (days * 86400)
        cursor.execute('''
            SELECT * FROM scripts 
            WHERE is_archived = 0 
            AND (last_used IS NULL OR datetime(last_used) < datetime(?))
        ''', (datetime.fromtimestamp(threshold).isoformat(),))
        
        rows = cursor.fetchall()
        conn.close()
        
        scripts = []
        for row in rows:
            scripts.append(self._row_to_metadata(row))
        
        return scripts
    
    def _row_to_metadata(self, row) -> ScriptMetadata:
        return ScriptMetadata(
            file_path=row[1],
            file_name=row[2],
            file_size=row[3],
            created_time=datetime.fromisoformat(row[4]),
            modified_time=datetime.fromisoformat(row[5]),
            functions=json.loads(row[6]) if row[6] else [],
            variables=json.loads(row[7]) if row[7] else [],
            imports=json.loads(row[8]) if row[8] else [],
            tags=json.loads(row[9]) if row[9] else [],
            description=row[10] if row[10] else "",
            use_count=row[11] if row[11] else 0,
            last_used=datetime.fromisoformat(row[12]) if row[12] else None,
            is_archived=bool(row[13])
        )
    
    def export_metadata(self, export_path: str):
        scripts = self.get_all_scripts(include_archived=True)
        data = [script.to_dict() for script in scripts]
        
        with open(export_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def import_metadata(self, import_path: str):
        with open(import_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        for script_data in data:
            metadata = ScriptMetadata.from_dict(script_data)
            self.add_script(metadata)