import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import os
import threading
import subprocess
import sys
from datetime import datetime

from scanner import ScriptScanner
from metadata_manager import MetadataManager
from search_engine import SearchEngine
from stats import StatsManager
from models import ScriptMetadata

class ScriptManagerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("脚本管理器")
        self.root.geometry("1200x800")
        
        self.scanner = ScriptScanner()
        self.metadata_manager = MetadataManager()
        self.search_engine = SearchEngine()
        self.stats_manager = StatsManager()
        
        self.all_scripts = []
        self.current_scripts = []
        self.selected_script = None
        
        self._setup_ui()
        self._load_scripts()
    
    def _setup_ui(self):
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        search_frame = ttk.Frame(main_frame)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(search_frame, text="搜索:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 5))
        self.search_var.trace('w', self._on_search)
        
        ttk.Button(search_frame, text="扫描", command=self._scan_directories).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="添加文件", command=self._add_single_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="导出数据", command=self._export_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="导入数据", command=self._import_data).pack(side=tk.LEFT, padx=5)
        
        toolbar_frame = ttk.Frame(main_frame)
        toolbar_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(toolbar_frame, text="排序:").pack(side=tk.LEFT)
        self.sort_var = tk.StringVar(value="modified_time")
        sort_combo = ttk.Combobox(toolbar_frame, textvariable=self.sort_var, state="readonly", width=15)
        sort_combo['values'] = ('modified_time', 'created_time', 'use_count', 'name')
        sort_combo.pack(side=tk.LEFT, padx=(5, 5))
        sort_combo.bind('<<ComboboxSelected>>', self._on_sort_change)
        
        ttk.Button(toolbar_frame, text="最常用脚本", command=self._show_most_used).pack(side=tk.LEFT, padx=5)
        ttk.Button(toolbar_frame, text="未使用脚本", command=self._show_unused).pack(side=tk.LEFT, padx=5)
        ttk.Button(toolbar_frame, text="全部脚本", command=self._show_all).pack(side=tk.LEFT, padx=5)
        
        paned = ttk.PanedWindow(main_frame, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)
        
        list_frame = ttk.Frame(paned)
        paned.add(list_frame, weight=1)
        
        columns = ('name', 'modified', 'size', 'uses')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='headings')
        self.tree.heading('name', text='文件名')
        self.tree.heading('modified', text='修改时间')
        self.tree.heading('size', text='大小')
        self.tree.heading('uses', text='使用次数')
        
        self.tree.column('name', width=300)
        self.tree.column('modified', width=150)
        self.tree.column('size', width=100)
        self.tree.column('uses', width=100)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree.bind('<<TreeviewSelect>>', self._on_script_select)
        self.tree.bind('<Double-1>', self._on_script_double_click)
        
        detail_frame = ttk.Frame(paned)
        paned.add(detail_frame, weight=1)
        
        notebook = ttk.Notebook(detail_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        info_frame = ttk.Frame(notebook)
        notebook.add(info_frame, text="详细信息")
        
        ttk.Label(info_frame, text="详细信息", font=('Arial', 12, 'bold')).pack(pady=(0, 10))
        
        self.detail_text = tk.Text(info_frame, wrap=tk.WORD, width=40)
        self.detail_text.pack(fill=tk.BOTH, expand=True)
        
        content_frame = ttk.Frame(notebook)
        notebook.add(content_frame, text="文件内容")
        
        search_frame = ttk.Frame(content_frame)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(search_frame, text="搜索内容:").pack(side=tk.LEFT)
        self.content_search_var = tk.StringVar()
        content_search_entry = ttk.Entry(search_frame, textvariable=self.content_search_var, width=30)
        content_search_entry.pack(side=tk.LEFT, padx=(5, 5))
        content_search_entry.bind('<Return>', self._search_in_content)
        
        ttk.Button(search_frame, text="搜索", command=self._search_in_content).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="上一个", command=self._search_prev).pack(side=tk.LEFT, padx=5)
        ttk.Button(search_frame, text="下一个", command=self._search_next).pack(side=tk.LEFT, padx=5)
        
        self.content_text = tk.Text(content_frame, wrap=tk.NONE, width=40, font=('Consolas', 10))
        self.content_text.pack(fill=tk.BOTH, expand=True)
        
        content_scrollbar_v = ttk.Scrollbar(content_frame, orient=tk.VERTICAL, command=self.content_text.yview)
        content_scrollbar_v.pack(side=tk.RIGHT, fill=tk.Y)
        self.content_text.configure(yscrollcommand=content_scrollbar_v.set)
        
        content_scrollbar_h = ttk.Scrollbar(content_frame, orient=tk.HORIZONTAL, command=self.content_text.xview)
        content_scrollbar_h.pack(side=tk.BOTTOM, fill=tk.X)
        self.content_text.configure(xscrollcommand=content_scrollbar_h.set)
        
        self.content_search_matches = []
        self.content_search_index = 0
        
        button_frame = ttk.Frame(detail_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(button_frame, text="打开文件", command=self._open_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="编辑标签", command=self._edit_tags).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="编辑描述", command=self._edit_description).pack(side=tk.LEFT, padx=5)
        
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        ttk.Label(status_frame, textvariable=self.status_var).pack(side=tk.LEFT)
    
    def _load_scripts(self):
        self.status_var.set("加载脚本...")
        self.root.update()
        
        self.all_scripts = self.metadata_manager.get_all_scripts()
        self.current_scripts = self.all_scripts.copy()
        self._update_script_list()
        
        self.status_var.set(f"已加载 {len(self.all_scripts)} 个脚本")
    
    def _scan_directories(self):
        directory = filedialog.askdirectory(title="选择要扫描的文件夹")
        
        if not directory:
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("扫描选项")
        dialog.geometry("300x150")
        dialog.transient(self.root)
        dialog.grab_set()
        
        recursive_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(dialog, text="递归扫描子文件夹", variable=recursive_var).pack(pady=10)
        
        result = {'confirmed': False}
        
        def confirm_scan():
            result['confirmed'] = True
            dialog.destroy()
        
        def cancel_scan():
            dialog.destroy()
        
        button_frame = ttk.Frame(dialog)
        button_frame.pack(pady=10)
        ttk.Button(button_frame, text="开始扫描", command=confirm_scan).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="取消", command=cancel_scan).pack(side=tk.LEFT, padx=5)
        
        self.root.wait_window(dialog)
        
        if not result['confirmed']:
            return
        
        self.status_var.set(f"扫描中: {directory}...")
        self.root.update()
        
        def scan_task():
            scripts = self.scanner.scan_directory(directory, recursive=recursive_var.get())
            
            for script in scripts:
                self.metadata_manager.add_script(script)
            
            self.all_scripts = self.metadata_manager.get_all_scripts()
            self.current_scripts = self.all_scripts.copy()
            
            self.root.after(0, self._update_script_list)
            self.root.after(0, lambda: self.status_var.set(f"扫描完成，共 {len(self.all_scripts)} 个脚本"))
        
        threading.Thread(target=scan_task, daemon=True).start()
    
    def _add_single_file(self):
        file_path = filedialog.askopenfilename(
            title="选择脚本文件",
            filetypes=[("Python", "*.py"), ("JavaScript", "*.js"), ("TypeScript", "*.ts"), ("All", "*.*")]
        )
        
        if file_path:
            metadata = self.scanner.add_single_file(file_path)
            if metadata:
                self.metadata_manager.add_script(metadata)
                self.all_scripts = self.metadata_manager.get_all_scripts()
                self.current_scripts = self.all_scripts.copy()
                self._update_script_list()
                self.status_var.set(f"已添加: {metadata.file_name}")
    
    def _on_search(self, *args):
        query = self.search_var.get()
        if query:
            self.current_scripts = self.search_engine.search(self.all_scripts, query)
        else:
            self.current_scripts = self.all_scripts.copy()
        
        self._apply_sort()
        self._update_script_list()
    
    def _on_sort_change(self, event):
        self._apply_sort()
        self._update_script_list()
    
    def _apply_sort(self):
        sort_by = self.sort_var.get()
        if sort_by == 'modified_time':
            self.current_scripts = self.search_engine.sort_by_modified_time(self.current_scripts)
        elif sort_by == 'created_time':
            self.current_scripts = self.search_engine.sort_by_created_time(self.current_scripts)
        elif sort_by == 'use_count':
            self.current_scripts = self.search_engine.sort_by_use_count(self.current_scripts)
        elif sort_by == 'name':
            self.current_scripts.sort(key=lambda x: x.file_name.lower())
    
    def _update_script_list(self):
        self.tree.delete(*self.tree.get_children())
        
        for script in self.current_scripts:
            size_kb = script.file_size / 1024
            self.tree.insert('', tk.END, values=(
                script.file_name,
                script.modified_time.strftime('%Y-%m-%d %H:%M'),
                f'{size_kb:.1f} KB',
                script.use_count
            ), tags=(script.file_path,))
    
    def _on_script_select(self, event):
        selection = self.tree.selection()
        if selection:
            item = self.tree.item(selection[0])
            file_path = item['tags'][0]
            self.selected_script = self.metadata_manager.get_script_by_path(file_path)
            self._update_detail_view()
            self._load_file_content()
    
    def _load_file_content(self):
        if not self.selected_script:
            return
        
        try:
            with open(self.selected_script.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.content_text.delete(1.0, tk.END)
            self.content_text.insert(1.0, content)
            
            self.content_search_matches = []
            self.content_search_index = 0
        except Exception as e:
            self.content_text.delete(1.0, tk.END)
            self.content_text.insert(1.0, f"无法读取文件内容: {e}")
    
    def _search_in_content(self, event=None):
        if not self.selected_script:
            return
        
        query = self.content_search_var.get()
        if not query:
            return
        
        content = self.content_text.get(1.0, tk.END)
        self.content_search_matches = []
        
        start_pos = 1.0
        while True:
            pos = self.content_text.search(query, start_pos, stopindex=tk.END, nocase=True)
            if not pos:
                break
            end_pos = f"{pos}+{len(query)}c"
            self.content_search_matches.append((pos, end_pos))
            start_pos = end_pos
        
        self.content_search_index = 0
        
        if self.content_search_matches:
            self._highlight_match()
            self.status_var.set(f"找到 {len(self.content_search_matches)} 个匹配")
        else:
            self.status_var.set("未找到匹配")
    
    def _highlight_match(self):
        self.content_text.tag_remove('search', '1.0', tk.END)
        
        if not self.content_search_matches:
            return
        
        pos, end_pos = self.content_search_matches[self.content_search_index]
        self.content_text.tag_add('search', pos, end_pos)
        self.content_text.tag_config('search', background='yellow')
        self.content_text.see(pos)
    
    def _search_next(self):
        if not self.content_search_matches:
            return
        
        self.content_search_index = (self.content_search_index + 1) % len(self.content_search_matches)
        self._highlight_match()
        self.status_var.set(f"匹配 {self.content_search_index + 1}/{len(self.content_search_matches)}")
    
    def _search_prev(self):
        if not self.content_search_matches:
            return
        
        self.content_search_index = (self.content_search_index - 1) % len(self.content_search_matches)
        self._highlight_match()
        self.status_var.set(f"匹配 {self.content_search_index + 1}/{len(self.content_search_matches)}")
    
    def _on_script_double_click(self, event):
        self._open_file()
    
    def _update_detail_view(self):
        if not self.selected_script:
            return
        
        self.detail_text.delete(1.0, tk.END)
        
        info = f"文件名: {self.selected_script.file_name}\n"
        info += f"路径: {self.selected_script.file_path}\n"
        info += f"大小: {self.selected_script.file_size} 字节\n"
        info += f"创建时间: {self.selected_script.created_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        info += f"修改时间: {self.selected_script.modified_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        info += f"使用次数: {self.selected_script.use_count}\n"
        info += f"最后使用: {self.selected_script.last_used.strftime('%Y-%m-%d %H:%M:%S') if self.selected_script.last_used else '从未'}\n\n"
        
        if self.selected_script.description:
            info += f"描述:\n{self.selected_script.description}\n\n"
        
        if self.selected_script.tags:
            info += f"标签: {', '.join(self.selected_script.tags)}\n\n"
        
        if self.selected_script.functions:
            info += f"函数 ({len(self.selected_script.functions)}):\n"
            for func in self.selected_script.functions[:20]:
                info += f"  - {func}\n"
            if len(self.selected_script.functions) > 20:
                info += f"  ... 还有 {len(self.selected_script.functions) - 20} 个\n"
            info += "\n"
        
        if self.selected_script.imports:
            info += f"导入 ({len(self.selected_script.imports)}):\n"
            for imp in self.selected_script.imports[:20]:
                info += f"  - {imp}\n"
            if len(self.selected_script.imports) > 20:
                info += f"  ... 还有 {len(self.selected_script.imports) - 20} 个\n"
        
        self.detail_text.insert(1.0, info)
    
    def _open_file(self):
        if not self.selected_script:
            return
        
        self.metadata_manager.increment_use_count(self.selected_script.file_path)
        self.selected_script.use_count += 1
        self.selected_script.last_used = datetime.now()
        
        try:
            if sys.platform == 'win32':
                os.startfile(self.selected_script.file_path)
            elif sys.platform == 'darwin':
                subprocess.run(['open', self.selected_script.file_path])
            else:
                subprocess.run(['xdg-open', self.selected_script.file_path])
            
            self._update_detail_view()
            self._update_script_list()
        except Exception as e:
            messagebox.showerror("错误", f"无法打开文件: {e}")
    
    def _edit_tags(self):
        if not self.selected_script:
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("编辑标签")
        dialog.geometry("400x200")
        
        ttk.Label(dialog, text="标签 (用逗号分隔):").pack(pady=10)
        
        tags_var = tk.StringVar(value=', '.join(self.selected_script.tags))
        tags_entry = ttk.Entry(dialog, textvariable=tags_var, width=50)
        tags_entry.pack(pady=5)
        
        def save_tags():
            tags = [tag.strip() for tag in tags_var.get().split(',') if tag.strip()]
            self.selected_script.tags = tags
            self.metadata_manager.update_script(self.selected_script)
            self._update_detail_view()
            dialog.destroy()
        
        ttk.Button(dialog, text="保存", command=save_tags).pack(pady=10)
    
    def _edit_description(self):
        if not self.selected_script:
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("编辑描述")
        dialog.geometry("500x300")
        
        ttk.Label(dialog, text="描述:").pack(pady=10)
        
        desc_text = tk.Text(dialog, wrap=tk.WORD, width=50, height=10)
        desc_text.pack(pady=5)
        desc_text.insert(1.0, self.selected_script.description)
        
        def save_description():
            self.selected_script.description = desc_text.get(1.0, tk.END).strip()
            self.metadata_manager.update_script(self.selected_script)
            self._update_detail_view()
            dialog.destroy()
        
        ttk.Button(dialog, text="保存", command=save_description).pack(pady=10)
    
    def _show_most_used(self):
        most_used = self.stats_manager.get_most_used_scripts(self.all_scripts, 20)
        self.current_scripts = most_used
        self._update_script_list()
        self.status_var.set(f"显示最常用的 {len(most_used)} 个脚本")
    
    def _show_unused(self):
        unused = self.stats_manager.get_unused_scripts(self.all_scripts, 30)
        self.current_scripts = unused
        self._update_script_list()
        self.status_var.set(f"显示 {len(unused)} 个30天未使用的脚本")
    
    def _show_all(self):
        self.current_scripts = self.all_scripts.copy()
        self._apply_sort()
        self._update_script_list()
        self.status_var.set(f"显示全部 {len(self.all_scripts)} 个脚本")
    
    def _export_data(self):
        file_path = filedialog.asksaveasfilename(
            title="导出元数据",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")]
        )
        
        if file_path:
            try:
                self.metadata_manager.export_metadata(file_path)
                messagebox.showinfo("成功", "元数据导出成功！")
            except Exception as e:
                messagebox.showerror("错误", f"导出失败: {e}")
    
    def _import_data(self):
        file_path = filedialog.askopenfilename(
            title="导入元数据",
            filetypes=[("JSON", "*.json")]
        )
        
        if file_path:
            try:
                self.metadata_manager.import_metadata(file_path)
                self._load_scripts()
                messagebox.showinfo("成功", "元数据导入成功！")
            except Exception as e:
                messagebox.showerror("错误", f"导入失败: {e}")

def main():
    root = tk.Tk()
    app = ScriptManagerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()