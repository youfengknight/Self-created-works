import os
import ast
from pathlib import Path
from typing import List, Dict, Set
from datetime import datetime
from models import ScriptMetadata

class ScriptScanner:
    def __init__(self):
        self.supported_extensions = {'.py', '.js', '.ts', '.sh', '.bash'}
    
    def scan_directory(self, directory: str, recursive: bool = True) -> List[ScriptMetadata]:
        scripts = []
        path = Path(directory)
        
        if not path.exists():
            return scripts
        
        pattern = '**/*' if recursive else '*'
        for file_path in path.glob(pattern):
            if file_path.is_file() and file_path.suffix.lower() in self.supported_extensions:
                metadata = self._analyze_script(file_path)
                if metadata:
                    scripts.append(metadata)
        
        return scripts
    
    def _analyze_script(self, file_path: Path) -> ScriptMetadata:
        try:
            stat = file_path.stat()
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            
            metadata = ScriptMetadata(
                file_path=str(file_path.absolute()),
                file_name=file_path.name,
                file_size=stat.st_size,
                created_time=datetime.fromtimestamp(stat.st_ctime),
                modified_time=datetime.fromtimestamp(stat.st_mtime)
            )
            
            if file_path.suffix.lower() == '.py':
                self._parse_python(content, metadata)
            elif file_path.suffix.lower() in {'.js', '.ts'}:
                self._parse_javascript(content, metadata)
            
            return metadata
        except Exception as e:
            print(f"Error analyzing {file_path}: {e}")
            return None
    
    def _parse_python(self, content: str, metadata: ScriptMetadata):
        try:
            tree = ast.parse(content)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    metadata.functions.append(node.name)
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            metadata.variables.append(target.id)
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        metadata.imports.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        metadata.imports.append(node.module)
            
            metadata.functions = list(set(metadata.functions))
            metadata.variables = list(set(metadata.variables))
            metadata.imports = list(set(metadata.imports))
        except:
            pass
    
    def _parse_javascript(self, content: str, metadata: ScriptMetadata):
        import re
        
        function_pattern = r'function\s+(\w+)|const\s+(\w+)\s*=\s*\(|(\w+)\s*:\s*function'
        for match in re.finditer(function_pattern, content):
            func_name = match.group(1) or match.group(2) or match.group(3)
            if func_name:
                metadata.functions.append(func_name)
        
        import_pattern = r'import\s+.*from\s+[\'"]([^\'"]+)[\'"]|require\([\'"]([^\'"]+)[\'"]\)'
        for match in re.finditer(import_pattern, content):
            module = match.group(1) or match.group(2)
            if module:
                metadata.imports.append(module)
        
        metadata.functions = list(set(metadata.functions))
        metadata.imports = list(set(metadata.imports))
    
    def add_single_file(self, file_path: str) -> ScriptMetadata:
        path = Path(file_path)
        if not path.exists():
            return None
        return self._analyze_script(path)