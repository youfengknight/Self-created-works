from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional
import json

@dataclass
class ScriptMetadata:
    file_path: str
    file_name: str
    file_size: int
    created_time: datetime
    modified_time: datetime
    functions: List[str] = field(default_factory=list)
    variables: List[str] = field(default_factory=list)
    imports: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    description: str = ""
    use_count: int = 0
    last_used: Optional[datetime] = None
    is_archived: bool = False
    
    def to_dict(self):
        return {
            "file_path": self.file_path,
            "file_name": self.file_name,
            "file_size": self.file_size,
            "created_time": self.created_time.isoformat(),
            "modified_time": self.modified_time.isoformat(),
            "functions": self.functions,
            "variables": self.variables,
            "imports": self.imports,
            "tags": self.tags,
            "description": self.description,
            "use_count": self.use_count,
            "last_used": self.last_used.isoformat() if self.last_used else None,
            "is_archived": self.is_archived
        }
    
    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            file_path=data["file_path"],
            file_name=data["file_name"],
            file_size=data["file_size"],
            created_time=datetime.fromisoformat(data["created_time"]),
            modified_time=datetime.fromisoformat(data["modified_time"]),
            functions=data.get("functions", []),
            variables=data.get("variables", []),
            imports=data.get("imports", []),
            tags=data.get("tags", []),
            description=data.get("description", ""),
            use_count=data.get("use_count", 0),
            last_used=datetime.fromisoformat(data["last_used"]) if data.get("last_used") else None,
            is_archived=data.get("is_archived", False)
        )