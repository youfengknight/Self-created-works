from typing import List
from models import ScriptMetadata

class SearchEngine:
    def __init__(self):
        pass
    
    def search(self, scripts: List[ScriptMetadata], query: str) -> List[ScriptMetadata]:
        if not query:
            return scripts
        
        query = query.lower()
        results = []
        
        for script in scripts:
            if self._matches_query(script, query):
                results.append(script)
        
        return results
    
    def _matches_query(self, script: ScriptMetadata, query: str) -> bool:
        if query in script.file_name.lower():
            return True
        
        if query in script.description.lower():
            return True
        
        for func in script.functions:
            if query in func.lower():
                return True
        
        for var in script.variables:
            if query in var.lower():
                return True
        
        for imp in script.imports:
            if query in imp.lower():
                return True
        
        for tag in script.tags:
            if query in tag.lower():
                return True
        
        return False
    
    def search_by_tag(self, scripts: List[ScriptMetadata], tag: str) -> List[ScriptMetadata]:
        tag = tag.lower()
        return [s for s in scripts if any(tag in t.lower() for t in s.tags)]
    
    def search_by_function(self, scripts: List[ScriptMetadata], function_name: str) -> List[ScriptMetadata]:
        function_name = function_name.lower()
        return [s for s in scripts if any(function_name in f.lower() for f in s.functions)]
    
    def search_by_import(self, scripts: List[ScriptMetadata], import_name: str) -> List[ScriptMetadata]:
        import_name = import_name.lower()
        return [s for s in scripts if any(import_name in i.lower() for i in s.imports)]
    
    def sort_by_modified_time(self, scripts: List[ScriptMetadata], reverse: bool = True) -> List[ScriptMetadata]:
        return sorted(scripts, key=lambda x: x.modified_time, reverse=reverse)
    
    def sort_by_created_time(self, scripts: List[ScriptMetadata], reverse: bool = True) -> List[ScriptMetadata]:
        return sorted(scripts, key=lambda x: x.created_time, reverse=reverse)
    
    def sort_by_use_count(self, scripts: List[ScriptMetadata], reverse: bool = True) -> List[ScriptMetadata]:
        return sorted(scripts, key=lambda x: x.use_count, reverse=reverse)