from typing import List, Dict
from datetime import datetime, timedelta
from models import ScriptMetadata

class StatsManager:
    def __init__(self):
        pass
    
    def get_total_scripts(self, scripts: List[ScriptMetadata]) -> int:
        return len(scripts)
    
    def get_total_size(self, scripts: List[ScriptMetadata]) -> int:
        return sum(s.file_size for s in scripts)
    
    def get_most_used_scripts(self, scripts: List[ScriptMetadata], limit: int = 10) -> List[ScriptMetadata]:
        return sorted(scripts, key=lambda x: x.use_count, reverse=True)[:limit]
    
    def get_unused_scripts(self, scripts: List[ScriptMetadata], days: int = 30) -> List[ScriptMetadata]:
        threshold = datetime.now() - timedelta(days=days)
        return [s for s in scripts if s.last_used is None or s.last_used < threshold]
    
    def get_scripts_by_language(self, scripts: List[ScriptMetadata]) -> Dict[str, int]:
        language_count = {}
        for script in scripts:
            ext = script.file_name.split('.')[-1].lower()
            language_count[ext] = language_count.get(ext, 0) + 1
        return language_count
    
    def get_average_script_size(self, scripts: List[ScriptMetadata]) -> float:
        if not scripts:
            return 0.0
        return self.get_total_size(scripts) / len(scripts)