import os
import zipfile
import glob
import tkinter as tk
from tkinter import filedialog, messagebox
import sys

def find_single_folder():
    """在当前目录下查找唯一的文件夹"""
    current_dir = os.getcwd()
    
    folders = [f for f in os.listdir(current_dir) 
              if os.path.isdir(os.path.join(current_dir, f)) 
              and not f.startswith('.')]
    
    if len(folders) == 0:
        messagebox.showwarning("警告", "当前目录下没有找到任何文件夹！")
        return None
    elif len(folders) > 1:
        return select_folder_from_list(folders)
    else:
        return folders[0]

def find_zip_files():
    """查找当前目录下的ZIP文件"""
    current_dir = os.getcwd()
    zip_files = [f for f in os.listdir(current_dir) 
                if f.lower().endswith('.zip')]
    return zip_files

def select_folder_from_list(folders):
    """让用户从多个文件夹中选择一个"""
    def on_select():
        selected_index = listbox.curselection()
        if selected_index:
            selected_folder = folders[selected_index[0]]
            select_window.selected_folder = selected_folder
            select_window.destroy()
    
    select_window = tk.Toplevel(root)
    select_window.title("选择文件夹")
    select_window.geometry("300x300")
    select_window.selected_folder = None
    
    tk.Label(select_window, text="发现多个文件夹，请选择要压缩的文件夹：", 
            pady=10).pack()
    
    listbox = tk.Listbox(select_window, selectmode=tk.SINGLE)
    for folder in folders:
        listbox.insert(tk.END, folder)
    listbox.pack(expand=True, fill=tk.BOTH, padx=10, pady=5)
    
    tk.Button(select_window, text="选择", command=on_select, 
             width=10).pack(pady=10)
    
    root.wait_window(select_window)
    return select_window.selected_folder

def select_zip_from_list(zip_files):
    """让用户从多个ZIP文件中选择一个"""
    def on_select():
        selected_index = listbox.curselection()
        if selected_index:
            selected_zip = zip_files[selected_index[0]]
            select_window.selected_zip = selected_zip
            select_window.destroy()
    
    select_window = tk.Toplevel(root)
    select_window.title("选择ZIP文件")
    select_window.geometry("300x300")
    select_window.selected_zip = None
    
    tk.Label(select_window, text="发现多个ZIP文件，请选择要删除的文件：", 
            pady=10).pack()
    
    listbox = tk.Listbox(select_window, selectmode=tk.SINGLE)
    for zip_file in zip_files:
        listbox.insert(tk.END, zip_file)
    listbox.pack(expand=True, fill=tk.BOTH, padx=10, pady=5)
    
    tk.Button(select_window, text="选择", command=on_select, 
             width=10).pack(pady=10)
    
    root.wait_window(select_window)
    return select_window.selected_zip

def zip_folder(folder_name):
    """将指定文件夹压缩为ZIP文件"""
    current_dir = os.getcwd()
    folder_path = os.path.join(current_dir, folder_name)
    zip_filename = f"{folder_name}.zip"
    zip_path = os.path.join(current_dir, zip_filename)
    
    # 检查ZIP文件是否已存在
    if os.path.exists(zip_path):
        if not messagebox.askyesno("确认", 
                                  f"ZIP文件 '{zip_filename}' 已存在，是否覆盖？"):
            return False, "用户取消操作"
    
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, current_dir)
                    zipf.write(file_path, arcname)
        
        return True, zip_filename
    except Exception as e:
        return False, str(e)

def delete_zip_files():
    """删除ZIP文件"""
    zip_files = find_zip_files()
    
    if len(zip_files) == 0:
        messagebox.showinfo("提示", "当前目录下没有找到ZIP文件！")
        return
    
    if len(zip_files) == 1:
        zip_to_delete = zip_files[0]
    else:
        zip_to_delete = select_zip_from_list(zip_files)
    
    if not zip_to_delete:
        return
    
    # 确认删除
    if not messagebox.askyesno("确认删除", 
                              f"确定要删除文件 '{zip_to_delete}' 吗？\n此操作不可恢复！"):
        return
    
    try:
        os.remove(zip_to_delete)
        messagebox.showinfo("成功", f"已删除文件: {zip_to_delete}")
        # 更新状态显示
        update_status()
    except Exception as e:
        messagebox.showerror("错误", f"删除失败: {e}")

def compress_folder():
    """主压缩函数"""
    folder_name = find_single_folder()
    
    if not folder_name:
        return
    
    if not messagebox.askyesno("确认", f"确定要压缩文件夹 '{folder_name}' 吗？"):
        return
    
    success, result = zip_folder(folder_name)
    
    if success:
        messagebox.showinfo("成功", f"文件夹已成功压缩为: {result}")
        # 更新状态显示
        update_status()
    else:
        messagebox.showerror("错误", f"压缩失败: {result}")

def update_status():
    """更新状态显示"""
    current_dir = os.getcwd()
    dir_label.config(text=f"当前目录: {current_dir}")
    
    # 更新文件夹和ZIP文件信息
    folders = [f for f in os.listdir(current_dir) 
              if os.path.isdir(os.path.join(current_dir, f)) 
              and not f.startswith('.')]
    
    zip_files = find_zip_files()
    
    info_text = f"文件夹数量: {len(folders)}\nZIP文件数量: {len(zip_files)}"
    
    if zip_files:
        info_text += "\n\n当前ZIP文件:"
        for zip_file in zip_files:
            size = os.path.getsize(zip_file) / 1024
            info_text += f"\n  • {zip_file} ({size:.1f} KB)"
    
    status_label.config(text=info_text)

def refresh_window():
    """刷新窗口"""
    update_status()

def change_directory():
    """更改当前工作目录"""
    new_dir = filedialog.askdirectory(title="选择目录")
    if new_dir:
        os.chdir(new_dir)
        update_status()

def create_gui():
    """创建GUI界面"""
    global root, dir_label, status_label
    
    root = tk.Tk()
    root.title("文件夹压缩工具 v2.0")
    root.geometry("500x500")
    
    # 设置窗口图标
    try:
        root.iconbitmap(default='icon.ico')
    except:
        pass
    
    # 标题
    tk.Label(root, text="文件夹压缩与清理工具", 
            font=("Arial", 16, "bold")).pack(pady=10)
    
    # 当前目录显示
    dir_label = tk.Label(root, text=f"当前目录: {os.getcwd()}", 
                        wraplength=480, justify="left")
    dir_label.pack(pady=5)
    
    # 目录操作按钮框架
    dir_frame = tk.Frame(root)
    dir_frame.pack(pady=5)
    
    tk.Button(dir_frame, text="刷新", command=refresh_window,
             padx=10).pack(side=tk.LEFT, padx=5)
    
    tk.Button(dir_frame, text="更改目录", command=change_directory,
             padx=10).pack(side=tk.LEFT, padx=5)
    
    # 分隔线
    tk.Frame(root, height=2, bg="gray").pack(fill=tk.X, padx=20, pady=10)
    
    # 状态显示区域
    status_label = tk.Label(root, text="", justify="left", 
                           relief=tk.SUNKEN, bg="#f0f0f0",
                           padx=10, pady=10, wraplength=480)
    status_label.pack(pady=10, padx=10, fill=tk.X)
    
    # 操作按钮框架
    button_frame = tk.Frame(root)
    button_frame.pack(pady=20)
    
    # 压缩按钮
    compress_btn = tk.Button(button_frame, text="📦 压缩文件夹", 
                           command=compress_folder,
                           font=("Arial", 12),
                           bg="#4CAF50", fg="white",
                           padx=20, pady=10, width=15)
    compress_btn.pack(pady=5)
    
    # 删除按钮
    delete_btn = tk.Button(button_frame, text="🗑️ 删除压缩包", 
                         command=delete_zip_files,
                         font=("Arial", 12),
                         bg="#f44336", fg="white",
                         padx=20, pady=10, width=15)
    delete_btn.pack(pady=5)
    
    # 批量删除按钮（删除所有ZIP文件）
    def delete_all_zips():
        zip_files = find_zip_files()
        if not zip_files:
            messagebox.showinfo("提示", "没有找到ZIP文件！")
            return
        
        if messagebox.askyesno("确认删除", 
                              f"确定要删除所有 {len(zip_files)} 个ZIP文件吗？\n"
                              f"文件列表:\n" + "\n".join(zip_files)):
            deleted_count = 0
            failed_files = []
            
            for zip_file in zip_files:
                try:
                    os.remove(zip_file)
                    deleted_count += 1
                except Exception as e:
                    failed_files.append(f"{zip_file}: {e}")
            
            if failed_files:
                messagebox.showwarning("部分成功", 
                                      f"已删除 {deleted_count} 个文件，失败 {len(failed_files)} 个:\n" +
                                      "\n".join(failed_files))
            else:
                messagebox.showinfo("成功", f"已删除所有 {deleted_count} 个ZIP文件")
            
            update_status()
    
    delete_all_btn = tk.Button(button_frame, text="🗑️ 删除所有压缩包", 
                             command=delete_all_zips,
                             font=("Arial", 10),
                             bg="#FF9800", fg="white",
                             padx=15, pady=8, width=15)
    delete_all_btn.pack(pady=5)
    
    # 退出按钮
    tk.Frame(root, height=2, bg="gray").pack(fill=tk.X, padx=20, pady=10)
    
    tk.Button(root, text="退出", command=root.quit,
             bg="#9E9E9E", fg="white",
             padx=20, pady=8).pack(pady=10)
    
    # 初始状态更新
    update_status()
    
    root.mainloop()

def main():
    """主函数"""
    create_gui()

if __name__ == "__main__":
    main()