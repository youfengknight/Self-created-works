import { _decorator, Component, Node, director, Vec3, Color, Mat4, Quat, Vec2, Vec4, Enum } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

enum SearchScope {
    CurrentNodeAndChildren = 0,
    EntireScene = 1
}

declare const Editor: any;

/**
 * 组件查找与属性修改工具(带撤销功能)
 * 功能：查找组件 -> 打印日志 -> 高亮节点 -> 批量修改属性
 * 既可以查找也可以修改组件的属性，公有私有的属性都能修改。比如能修改组件的enabled，填false就会取消组件的勾选。也能修改显示在编辑器里的属性
 * 注意事项：
    撤销功能是基于内存的，如果关闭了编辑器或者场景，备份就会丢失。
    备份仅针对最近一次点击“修改”按钮的操作。
 */

@ccclass('ComponentFinderAndModifyAttrTool')
@executeInEditMode
export class ComponentFinderAndModifyAttrTool extends Component {

    // --- 1. 查找配置 ---
    @property({ type: Enum(SearchScope), tooltip: '选择查找范围' })
    scope: SearchScope = SearchScope.CurrentNodeAndChildren;

    @property({ tooltip: '要查找的组件名字（例如：MeshRenderer, AudioSource）' })
    componentName: string = '';

    @property({ tooltip: '查找成功后，是否在层级管理器中选中这些物体' })
    selectInHierarchy: boolean = true;

    // --- 2. 修改配置 ---
    @property({ tooltip: '要修改的属性名（例如：enabled, speed）' })
    propertyName: string = '';

    @property({ tooltip: '目标属性值。支持：数字、true/false、字符串、JSON对象' })
    propertyValue: string = '';

    // --- 3. 备份与撤销 ---
    @property({ 
        multiline: true, 
        tooltip: '修改前的属性值会自动备份在这里（只读）。可用于撤销操作。',
        readonly: true 
    })
    backupData: string = '';


    

    // --- 触发器 ---
    private _triggerSearch: boolean = false;
    @property({ displayName: "👉 1. 执行查找" })
    get triggerSearch(): boolean { return this._triggerSearch; }
    set triggerSearch(v: boolean) {
        if (EDITOR && v && !this._triggerSearch) this.doSearch();
        this._triggerSearch = false;
    }

    private _triggerModify: boolean = false;
    @property({ displayName: "✍️ 2. 批量修改属性" })
    get triggerModify(): boolean { return this._triggerModify; }
    set triggerModify(v: boolean) {
        if (EDITOR && v && !this._triggerModify) this.doModify();
        this._triggerModify = false;
    }

    private _triggerRestore: boolean = false;
    @property({ 
        displayName: "🔙 3. 撤销上次修改", 
        tooltip: '将属性恢复到上次修改前的状态' 
    })
    get triggerRestore(): boolean { return this._triggerRestore; }
    set triggerRestore(v: boolean) {
        if (EDITOR && v && !this._triggerRestore) this.doRestore();
        this._triggerRestore = false;
    }

    // 缓存组件和备份数据
    private _lastFoundComponents: any[] = [];
    // 内部缓存解析后的对象列表，用于还原
    private _backupValues: any[] = []; 

    start() {
        if (!EDITOR) this.destroy();
    }

    private doSearch() {
        if (!this.componentName) return;
        let searchRoot = this.scope === SearchScope.CurrentNodeAndChildren ? this.node : director.getScene();
        if (!searchRoot) return;

        this._lastFoundComponents = [];
        const foundNodes: Node[] = [];

        const walkNodes = (node: Node) => {
            const comp = node.getComponent(this.componentName);
            if (comp) {
                foundNodes.push(node);
                this._lastFoundComponents.push(comp);
            }
            node.children.forEach(walkNodes);
        };
        walkNodes(searchRoot);

        if (foundNodes.length === 0) {
            console.warn(`[ComponentFinder] 未找到组件: ${this.componentName}`);
            this.backupData = "未找到组件";
        } else {
            console.log(`%c[ComponentFinder] 找到 ${foundNodes.length} 个组件`, 'color: #00FFFF;');
            foundNodes.forEach((node, index) => {
                console.log(`${index + 1}. [${node.name}] 路径: ${this.getNodePath(node)}`, node);
            });

            if (this.selectInHierarchy && typeof Editor !== 'undefined') {
                Editor.Selection.clear('node');
                Editor.Selection.select('node', foundNodes.map(n => n.uuid));
            }
        }
    }

    private doModify() {
        if (this._lastFoundComponents.length === 0) {
            console.warn('[ComponentFinder] 请先执行查找操作。');
            return;
        }
        if (!this.propertyName) {
            console.warn('[ComponentFinder] 请输入属性名。');
            return;
        }

        const propName = this.propertyName.trim();
        const strValue = this.propertyValue;

        console.log(`%c[ComponentFinder] 开始批量修改: ${propName} -> ${strValue}`, 'color: #FFA500;');

        // 清空之前的备份
        this._backupValues = [];
        const backupJsonArray: string[] = [];

        let successCount = 0;

        this._lastFoundComponents.forEach((comp) => {
            if (!(propName in comp)) {
                console.warn(`[ComponentFinder] 组件 ${comp.constructor.name} 无属性: ${propName}`);
                return;
            }

            try {
                const currentVal = comp[propName];
                
                // 1. 备份旧值 (深拷贝)
                const backupObj = this.deepClone(currentVal);
                this._backupValues.push(backupObj);
                backupJsonArray.push(JSON.stringify(this.serializeForDisplay(backupObj)));

                // 2. 解析新值并赋值
                const finalValue = this.parseValue(strValue, currentVal);
                comp[propName] = finalValue;
                
                successCount++;
            } catch (e) {
                console.error(`[ComponentFinder] 修改失败 (${comp.node.name}):`, e);
            }
        });

        // 更新界面显示的备份文本
        this.backupData = backupJsonArray.join('\n');
        
        console.log(`%c[ComponentFinder] 修改完成！成功 ${successCount} 个。已自动备份旧值。`, 'color: #00FF00; font-weight: bold;');
    }

    private doRestore() {
        if (this._lastFoundComponents.length === 0 || this._backupValues.length === 0) {
            console.warn('[ComponentFinder] 没有可撤销的操作。请先执行修改。');
            return;
        }
        if (!this.propertyName) return;

        const propName = this.propertyName.trim();
        console.log(`%c[ComponentFinder] 正在撤销修改...`, 'color: #FFAA00;');

        let count = 0;
        // 注意：备份列表的长度可能小于组件列表长度（如果之前有些组件属性不存在）
        // 我们假设 backupValues 的顺序与 lastFoundComponents 中成功处理过的顺序一致
        // 为了更严谨，这里做一个简单的对应。如果之前跳过了某些组件，这里索引可能会错位，
        // 但为了工具简洁，我们假设用户操作是连续的。
        
        let backupIndex = 0;
        for (let i = 0; i < this._lastFoundComponents.length; i++) {
            const comp = this._lastFoundComponents[i];
            if (!(propName in comp)) continue;

            if (backupIndex < this._backupValues.length) {
                const oldVal = this._backupValues[backupIndex];
                try {
                    // 如果是对象，需要再次深拷贝回去，或者属性赋值
                    if (typeof oldVal === 'object' && oldVal !== null) {
                         // 如果当前属性是对象，我们复用 parseValue 逻辑来赋值，或者直接属性拷贝
                         // 这里简单处理：直接把备份的对象赋值回去（如果是Vec3等引用类型，需确保comp接收引用）
                         // Cocos组件通常持有引用，所以直接赋值备份的引用是安全的（因为备份是我们new出来的新对象）
                         comp[propName] = oldVal; 
                    } else {
                        comp[propName] = oldVal;
                    }
                    count++;
                } catch(e) {
                    console.error(`还原失败: ${comp.node.name}`, e);
                }
                backupIndex++;
            }
        }

        console.log(`%c[ComponentFinder] 撤销完成！还原了 ${count} 个组件。`, 'color: #00FF00;');
        
        // 清空备份防止重复撤销
        // this._backupValues = []; // 如果希望可以重复撤销，可以注释掉这行
    }

    // --- 辅助工具方法 ---

    /**
     * 深拷贝值。支持基础类型、JSON对象、Cocos类型
     */
    private deepClone(val: any): any {
        if (val === null || typeof val !== 'object') {
            return val;
        }
        
        // Cocos 类型处理 (Vec3, Color 等)
        // 检查是否有 clone 方法，这是最准确的方式
        if (typeof val.clone === 'function') {
            return val.clone();
        }

        // 普通对象
        if (val.constructor === Object) {
            const newObj: any = {};
            for (let key in val) {
                newObj[key] = this.deepClone(val[key]);
            }
            return newObj;
        }

        // 数组
        if (Array.isArray(val)) {
            return val.map(item => this.deepClone(item));
        }

        // 其他复杂对象直接返回引用（无法深拷贝的类实例，如 Material 引用等）
        return val;
    }

    /**
     * 用于展示的序列化：将 Cocos 对象转为普通 JSON 以便显示在文本框
     */
    private serializeForDisplay(val: any): any {
        if (val === null || typeof val !== 'object') return val;
        
        // 如果是 Vec/Color/Quat 等，转成 JSON
        if (val instanceof Vec2 || val instanceof Vec3 || val instanceof Vec4 || 
            val instanceof Color || val instanceof Quat || val instanceof Mat4) {
            // @ts-ignore
            return val; // JSON.stringify 会自动调用它们的 toJSON 方法
        }
        
        // 尝试普通对象
        try {
            return JSON.parse(JSON.stringify(val));
        } catch(e) {
            return String(val);
        }
    }

    private parseValue(strVal: string, currentValue: any): any {
        if (strVal === 'true') return true;
        if (strVal === 'false') return false;
        if (!isNaN(Number(strVal)) && strVal.trim() !== '') return Number(strVal);

        if (strVal.startsWith('{') && strVal.endsWith('}')) {
            try {
                const obj = JSON.parse(strVal);
                if (typeof currentValue === 'object' && currentValue !== null) {
                    for (let key in obj) {
                        if (currentValue.hasOwnProperty(key)) {
                            currentValue[key] = obj[key];
                        }
                    }
                    return currentValue;
                }
                return obj;
            } catch (e) {}
        }
        return strVal;
    }

    private getNodePath(node: Node): string {
        if (!node) return '';
        let path = node.name;
        let parent = node.parent;
        while (parent && parent !== director.getScene()) {
            path = parent.name + '/' + path;
            parent = parent.parent;
        }
        return path;
    }
}