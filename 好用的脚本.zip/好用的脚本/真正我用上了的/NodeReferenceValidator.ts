import { _decorator, Component, Node, isValid, director } from 'cc';
const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 节点引用验证器
 * 作用：验证自己/子节点身上的脚本上挂的节点是否是自身或者子节点，防止出现跨节点引用
 */
@ccclass('NodeReferenceValidator')
@executeInEditMode
export class NodeReferenceValidator extends Component {
    @property({
        tooltip: '是否包括子节点'
    })
    includeChildren: boolean = true;

    @property({
        tooltip: '是否在启动时自动检查'
    })
    autoCheckOnStart: boolean = false;

    @property({
        tooltip: '是否排除Cocos Creator自带的组件'
    })
    excludeCocosComponents: boolean = true;

    @property({
        type: Node,
        tooltip: '自定义检查的根节点（为空则使用当前节点）'
    })
    customRootNode: Node = null!;

    @property({
        visible: function (this: any) {
            // 在编辑器中显示刷新按钮
            return !!(window as any).cc && !!(window as any).cc.internal;
        }
    })
    private _refreshButton: boolean = false;

    @property
    get refreshButton() {
        return this._refreshButton;
    }
    
    set refreshButton(value: boolean) {
        if (value) {
            this.validateNodeReferences();
        }
        this._refreshButton = false;
    }

    // 存储所有需要检查的节点（当前节点和所有子节点）
    private _allNodesInHierarchy: Set<Node> = new Set<Node>();
    // 存储所有需要检查的组件（当前节点和所有子节点上的组件）
    private _allComponentsInHierarchy: Set<Component> = new Set<Component>();

    // Cocos Creator 3.x 自带组件列表
    private readonly COCOS_COMPONENTS: string[] = [
        'Transform', 'UITransform', 'Node',
        'Sprite', 'Label', 'Mask', 'Graphics', 'RichText',
        'Button', 'EditBox', 'Layout', 'ProgressBar',
        'ScrollView', 'Slider', 'Toggle', 'ToggleContainer',
        'Widget', 'Canvas', 'Animation', 'AnimationController',
        'RigidBody', 'Collider', 'BoxCollider', 'SphereCollider',
        'CapsuleCollider', 'Camera', 'Light', 'AudioSource',
        'ParticleSystem'
    ];

    start() {
        if (this.autoCheckOnStart) {
            this.validateNodeReferences();
        }
    }

    /**
     * 验证所有节点引用
     */
    public validateNodeReferences(): void {
        const rootNode = this.customRootNode || this.node;
        console.log('=== 开始验证节点引用 ===');
        console.log('检查根节点: ' + rootNode.name);
        console.log('排除Cocos组件: ' + (this.excludeCocosComponents ? '是' : '否'));
        
        // 收集所有需要检查的节点和组件
        this._collectAllNodesAndComponents(rootNode);
        
        // 开始验证
        var invalidReferences = this._validateHierarchyRecursive(rootNode, 0);
        
        console.log('=== 验证完成 ===');
        console.log('总计发现 ' + invalidReferences + ' 个无效的外部引用');
    }

    /**
     * 收集所有节点和组件
     */
    private _collectAllNodesAndComponents(rootNode: Node): void {
        this._allNodesInHierarchy.clear();
        this._allComponentsInHierarchy.clear();
        
        this._collectRecursive(rootNode);
        
        console.log('收集到 ' + this._allNodesInHierarchy.size + ' 个节点');
        console.log('收集到 ' + this._allComponentsInHierarchy.size + ' 个组件');
    }

    /**
     * 递归收集节点和组件
     */
    private _collectRecursive(node: Node): void {
        if (!isValid(node)) return;
        
        // 添加当前节点
        this._allNodesInHierarchy.add(node);
        
        // 添加当前节点的所有组件
        var components = node.getComponents(Component);
        for (var i = 0; i < components.length; i++) {
            this._allComponentsInHierarchy.add(components[i]);
        }
        
        // 递归收集子节点
        if (this.includeChildren) {
            for (var j = 0; j < node.children.length; j++) {
                this._collectRecursive(node.children[j]);
            }
        }
    }

    /**
     * 递归验证节点引用
     */
    private _validateHierarchyRecursive(node: Node, depth: number): number {
        if (!isValid(node)) return 0;

        var indent = '';
        for (var i = 0; i < depth; i++) {
            indent += '  ';
        }
        
        var invalidCount = 0;
        var hasInvalidInNode = false;
        
        // 检查当前节点的所有组件
        var components = node.getComponents(Component);
        
        for (var j = 0; j < components.length; j++) {
            var component = components[j];
            var componentInvalid = this._validateComponentReferences(component, depth + 1);
            
            if (componentInvalid > 0) {
                invalidCount += componentInvalid;
                hasInvalidInNode = true;
            }
        }
        
        // 只在有无效引用时才显示节点名
        if (hasInvalidInNode) {
            console.log(indent + '📌 节点: ' + node.name);
        }
        
        // 递归检查子节点
        if (this.includeChildren && node.children.length > 0) {
            for (var k = 0; k < node.children.length; k++) {
                invalidCount += this._validateHierarchyRecursive(node.children[k], depth + 1);
            }
        }
        
        return invalidCount;
    }

    /**
     * 验证单个组件的引用
     */
    private _validateComponentReferences(component: Component, depth: number): number {
        // 检查是否为Cocos自带组件
        var componentName = component.constructor.name;
        
        if (this.excludeCocosComponents && this._isCocosComponent(componentName)) {
            return 0; // 跳过Cocos自带组件
        }
        
        var indent = '';
        for (var i = 0; i < depth; i++) {
            indent += '  ';
        }
        
        // 获取组件的所有属性
        var propertyInfos = this._getPropertyInfos(component);
        var invalidCount = 0;
        var hasInvalid = false;
        
        // 按属性名排序
        propertyInfos.sort(function(a, b) {
            return a.name.localeCompare(b.name);
        });
        
        for (var j = 0; j < propertyInfos.length; j++) {
            var propertyInfo = propertyInfos[j];
            var value = propertyInfo.value;
            
            // 只检查Node和Component类型的属性
            if (value instanceof Node) {
                var isValidRef = this._isValidNodeReference(value);
                if (!isValidRef) {
                    if (!hasInvalid) {
                        console.log(indent + '   └─ 🟡 组件: ' + componentName);
                        hasInvalid = true;
                    }
                    invalidCount++;
                    console.log(indent + '        ❌ 节点引用: ' + propertyInfo.name + 
                              ' → 引用了外部节点: ' + (value.name || 'Unnamed'));
                }
            } 
            else if (value instanceof Component) {
                var isValidRef = this._isValidComponentReference(value);
                if (!isValidRef) {
                    if (!hasInvalid) {
                        console.log(indent + '   └─ 🟡 组件: ' + componentName);
                        hasInvalid = true;
                    }
                    invalidCount++;
                    console.log(indent + '        ❌ 组件引用: ' + propertyInfo.name + 
                              ' → 引用了外部组件: ' + value.constructor.name);
                }
            }
            else if (Array.isArray(value)) {
                // 检查数组中的元素
                var arrayInvalid = this._validateArrayReferences(value, propertyInfo.name, componentName, indent);
                if (arrayInvalid > 0) {
                    if (!hasInvalid) {
                        console.log(indent + '   └─ 🟡 组件: ' + componentName);
                        hasInvalid = true;
                    }
                    invalidCount += arrayInvalid;
                }
            }
        }
        
        if (!hasInvalid && propertyInfos.length > 0) {
            console.log(indent + '   └─ ✅ 组件: ' + componentName + ' (所有引用都在当前层级内)');
        }
        
        return invalidCount;
    }

    /**
     * 验证数组中的引用
     */
    private _validateArrayReferences(array: any[], propertyName: string, componentName: string, indent: string): number {
        var invalidCount = 0;
        
        for (var i = 0; i < array.length; i++) {
            var item = array[i];
            var indexInfo = '[' + i + ']';
            
            if (item instanceof Node) {
                if (!this._isValidNodeReference(item)) {
                    console.log(indent + '        ❌ 数组引用: ' + propertyName + indexInfo + 
                              ' → 引用了外部节点: ' + (item.name || 'Unnamed'));
                    invalidCount++;
                }
            }
            else if (item instanceof Component) {
                if (!this._isValidComponentReference(item)) {
                    console.log(indent + '        ❌ 数组引用: ' + propertyName + indexInfo + 
                              ' → 引用了外部组件: ' + item.constructor.name);
                    invalidCount++;
                }
            }
            else if (Array.isArray(item)) {
                // 递归检查嵌套数组
                invalidCount += this._validateArrayReferences(item, propertyName + indexInfo, componentName, indent);
            }
        }
        
        return invalidCount;
    }

    /**
     * 检查节点引用是否在当前层级内
     */
    private _isValidNodeReference(node: Node): boolean {
        if (!isValid(node)) return false;
        return this._allNodesInHierarchy.has(node);
    }

    /**
     * 检查组件引用是否在当前层级内
     */
    private _isValidComponentReference(component: Component): boolean {
        if (!isValid(component)) return false;
        return this._allComponentsInHierarchy.has(component);
    }

    /**
     * 判断是否为Cocos自带组件
     */
    private _isCocosComponent(componentName: string): boolean {
        for (var i = 0; i < this.COCOS_COMPONENTS.length; i++) {
            if (componentName === this.COCOS_COMPONENTS[i]) {
                return true;
            }
        }
        
        if (componentName.indexOf('cc.') === 0) {
            return true;
        }
        
        return false;
    }

    /**
     * 获取组件的所有属性信息
     */
    private _getPropertyInfos(component: Component): Array<{name: string, value: any, type: string}> {
        var propertyInfos: Array<{name: string, value: any, type: string}> = [];
        
        // 获取可序列化的属性（通常是 @property 装饰的属性）
        var serializableProperties = this._getSerializableProperties(component);
        
        // 获取每个属性的值
        for (var i = 0; i < serializableProperties.length; i++) {
            var propName = serializableProperties[i];
            
            // 跳过不需要的属性
            if (this._shouldSkipProperty(propName)) {
                continue;
            }
            
            var value = (component as any)[propName];
            
            // 只收集Node、Component或数组类型的属性
            if (value instanceof Node || 
                value instanceof Component || 
                Array.isArray(value)) {
                
                var type = this._getValueType(value);
                propertyInfos.push({
                    name: propName,
                    value: value,
                    type: type
                });
            }
        }
        
        return propertyInfos;
    }

    /**
     * 判断是否为编辑器专用属性
     */
    private _isEditorOnlyProperty(propertyName: string): boolean {
        var editorProperties = [
            'gizmo', 'iconGizmo', 'persistentGizmo',
            '_hideFlags', '__scriptAsset', '__editorExtras__',
            '_isValid', '_objFlags', '_parent', '_children'
        ];
        
        if (editorProperties.indexOf(propertyName) !== -1) {
            return true;
        }
        
        var patterns = [
            /^_/, /^__/, /gizmo$/i, /^editor/i
        ];
        
        for (var i = 0; i < patterns.length; i++) {
            if (patterns[i].test(propertyName)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * 判断是否应该跳过该属性
     */
    private _shouldSkipProperty(propertyName: string): boolean {
        if (this._isEditorOnlyProperty(propertyName)) {
            return true;
        }
        
        var skipProperties = [
            'name', 'node', 'uuid', 'enabled', 
            '__classname__', '__type__',
            'constructor', 'prototype', 'length',
            'onLoad', 'start', 'update', 'lateUpdate',
            'onDestroy', 'onEnable', 'onDisable'
        ];
        
        return skipProperties.indexOf(propertyName) !== -1;
    }

    /**
     * 获取可序列化的属性
     */
    private _getSerializableProperties(component: Component): string[] {
        var properties: string[] = [];
        var compProto = Object.getPrototypeOf(component) as any;
        
        // 检查是否有 __props__ 属性
        if (compProto.__props__ && Array.isArray(compProto.__props__)) {
            for (var i = 0; i < compProto.__props__.length; i++) {
                var propName = compProto.__props__[i] as string;
                if (!this._shouldSkipProperty(propName)) {
                    properties.push(propName);
                }
            }
            return properties;
        }
        
        // 检查是否有 __attrs__ 属性
        if (compProto.__attrs__ && typeof compProto.__attrs__ === 'object') {
            for (var attrName in compProto.__attrs__) {
                if (compProto.__attrs__.hasOwnProperty(attrName)) {
                    if (!this._shouldSkipProperty(attrName)) {
                        properties.push(attrName);
                    }
                }
            }
            return properties;
        }
        
        // 备用方法：获取组件实例的所有属性
        var keys = Object.keys(component);
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            if (!this._shouldSkipProperty(key)) {
                var value = (component as any)[key];
                // 只收集Node/Component/Array类型
                if (value instanceof Node || 
                    value instanceof Component || 
                    Array.isArray(value)) {
                    properties.push(key);
                }
            }
        }
        
        return properties;
    }

    /**
     * 获取值的类型名
     */
    private _getValueType(value: any): string {
        if (value instanceof Node) return 'Node';
        if (value instanceof Component) return 'Component';
        if (Array.isArray(value)) return 'Array';
        return typeof value;
    }

    /**
     * 快速检查当前节点
     */
    public validateCurrentNode(): void {
        console.log('=== 验证当前节点引用 ===');
        this._collectAllNodesAndComponents(this.node);
        var count = this._validateHierarchyRecursive(this.node, 0);
        console.log('发现 ' + count + ' 个外部引用');//无效的外部引用
        console.log('=== 验证完成 ===');
    }

    /**
     * 导出验证报告
     */
    public exportValidationReport(): void {
        var rootNode = this.customRootNode || this.node;
        
        // 重新收集数据
        this._collectAllNodesAndComponents(rootNode);
        
        var report: any = {
            timestamp: new Date().toISOString(),
            rootNode: rootNode.name,
            includeChildren: this.includeChildren,
            excludeCocosComponents: this.excludeCocosComponents,
            totalNodes: this._allNodesInHierarchy.size,
            totalComponents: this._allComponentsInHierarchy.size,
            invalidReferences: [],
            summary: {
                invalidNodeReferences: 0,
                invalidComponentReferences: 0,
                totalInvalid: 0
            }
        };

        // 收集所有无效引用
        this._collectInvalidReferences(rootNode, report);
        
        console.log('=== 节点引用验证报告 ===');
        console.log('总节点数: ' + report.totalNodes);
        console.log('总组件数: ' + report.totalComponents);
        console.log('无效引用总数: ' + report.summary.totalInvalid);
        console.log(JSON.stringify(report, null, 2));
        
        this._saveReportToFile(report);
    }

    /**
     * 收集所有无效引用
     */
    private _collectInvalidReferences(node: Node, report: any): void {
        var components = node.getComponents(Component);
        
        for (var i = 0; i < components.length; i++) {
            var component = components[i];
            var componentName = component.constructor.name;
            
            // 如果排除Cocos组件且是Cocos组件，则跳过
            if (this.excludeCocosComponents && this._isCocosComponent(componentName)) {
                continue;
            }
            
            var propertyInfos = this._getPropertyInfos(component);
            
            for (var j = 0; j < propertyInfos.length; j++) {
                var propertyInfo = propertyInfos[j];
                var value = propertyInfo.value;
                
                if (value instanceof Node && !this._isValidNodeReference(value)) {
                    report.invalidReferences.push({
                        node: node.name,
                        component: componentName,
                        property: propertyInfo.name,
                        type: 'Node',
                        referencedNode: value.name,
                        isValid: false
                    });
                    report.summary.invalidNodeReferences++;
                    report.summary.totalInvalid++;
                }
                else if (value instanceof Component && !this._isValidComponentReference(value)) {
                    report.invalidReferences.push({
                        node: node.name,
                        component: componentName,
                        property: propertyInfo.name,
                        type: 'Component',
                        referencedComponent: value.constructor.name,
                        isValid: false
                    });
                    report.summary.invalidComponentReferences++;
                    report.summary.totalInvalid++;
                }
                else if (Array.isArray(value)) {
                    this._collectInvalidArrayReferences(value, node.name, componentName, propertyInfo.name, report);
                }
            }
        }
        
        if (this.includeChildren) {
            for (var k = 0; k < node.children.length; k++) {
                this._collectInvalidReferences(node.children[k], report);
            }
        }
    }

    /**
     * 收集数组中无效的引用
     */
    private _collectInvalidArrayReferences(array: any[], nodeName: string, componentName: string, propertyName: string, report: any): void {
        for (var i = 0; i < array.length; i++) {
            var item = array[i];
            var fullPropName = propertyName + '[' + i + ']';
            
            if (item instanceof Node && !this._isValidNodeReference(item)) {
                report.invalidReferences.push({
                    node: nodeName,
                    component: componentName,
                    property: fullPropName,
                    type: 'Node',
                    referencedNode: item.name,
                    isValid: false
                });
                report.summary.invalidNodeReferences++;
                report.summary.totalInvalid++;
            }
            else if (item instanceof Component && !this._isValidComponentReference(item)) {
                report.invalidReferences.push({
                    node: nodeName,
                    component: componentName,
                    property: fullPropName,
                    type: 'Component',
                    referencedComponent: item.constructor.name,
                    isValid: false
                });
                report.summary.invalidComponentReferences++;
                report.summary.totalInvalid++;
            }
            else if (Array.isArray(item)) {
                this._collectInvalidArrayReferences(item, nodeName, componentName, fullPropName, report);
            }
        }
    }

    /**
     * 保存报告到文件
     */
    private _saveReportToFile(report: any): void {
        if (typeof window === 'undefined' || !window.Blob) {
            console.log('当前环境不支持文件保存');
            return;
        }
        
        var reportText = JSON.stringify(report, null, 2);
        var blob = new Blob([reportText], { type: 'application/json' });
        var url = URL.createObjectURL(blob);
        
        var a = document.createElement('a');
        a.href = url;
        a.download = 'node-reference-validation-' + new Date().getTime() + '.json';
        document.body.appendChild(a);
        a.click();
        
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);
    }

    /**
     * 查找引用特定节点的属性
     */
    public findReferencesToNode(targetNode: Node): void {
        const rootNode = this.customRootNode || this.node;
        console.log('=== 查找对节点的引用: ' + targetNode.name + ' ===');
        
        this._collectAllNodesAndComponents(rootNode);
        
        var references = this._findNodeReferencesRecursive(rootNode, targetNode, 0);
        
        console.log('=== 查找完成 ===');
        console.log('找到 ' + references + ' 个对该节点的引用');
    }

    private _findNodeReferencesRecursive(node: Node, targetNode: Node, depth: number): number {
        if (!isValid(node)) return 0;
        
        var references = 0;
        var components = node.getComponents(Component);
        
        for (var i = 0; i < components.length; i++) {
            var component = components[i];
            
            // 跳过Cocos组件
            if (this.excludeCocosComponents && this._isCocosComponent(component.constructor.name)) {
                continue;
            }
            
            var propertyInfos = this._getPropertyInfos(component);
            
            for (var j = 0; j < propertyInfos.length; j++) {
                var propertyInfo = propertyInfos[j];
                var value = propertyInfo.value;
                
                if (value === targetNode) {
                    console.log('🔍 在 ' + node.name + '.' + component.constructor.name + '.' + propertyInfo.name);
                    references++;
                }
                else if (Array.isArray(value)) {
                    references += this._findNodeInArray(value, targetNode, node.name, component.constructor.name, propertyInfo.name);
                }
            }
        }
        
        if (this.includeChildren) {
            for (var k = 0; k < node.children.length; k++) {
                references += this._findNodeReferencesRecursive(node.children[k], targetNode, depth + 1);
            }
        }
        
        return references;
    }

    private _findNodeInArray(array: any[], targetNode: Node, nodeName: string, componentName: string, propertyName: string): number {
        var references = 0;
        
        for (var i = 0; i < array.length; i++) {
            var item = array[i];
            if (item === targetNode) {
                console.log('🔍 在 ' + nodeName + '.' + componentName + '.' + propertyName + '[' + i + ']');
                references++;
            }
            else if (Array.isArray(item)) {
                references += this._findNodeInArray(item, targetNode, nodeName, componentName, propertyName + '[' + i + ']');
            }
        }
        
        return references;
    }
}