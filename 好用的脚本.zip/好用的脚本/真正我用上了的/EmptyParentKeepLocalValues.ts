import { _decorator, Component, Node, Vec3, Quat } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 空父节点创建工具（保持子节点编辑器面板值）
 * 功能：为每个子节点创建空的父节点，确保子节点在编辑器面板中显示的位置、旋转、缩放值保持不变
 * 注意：直接记录和恢复编辑器面板中的数值，不经过矩阵运算。可行！不过会改变几个子节点的顺序，这个无所谓
 */
@ccclass('EmptyParentKeepLocalValues')
@executeInEditMode
export class EmptyParentKeepLocalValues extends Component {

    // ============ 配置选项 ============
    
    /** 父节点名称前缀 */
    @property({ displayName: "父节点名称前缀", tooltip: "新创建的父节点将使用此前缀+序号" })
    public parentNamePrefix: string = "Parent_";
    
    // ============ 状态记录（用于撤销） ============
    private originalState: Array<{
        child: Node,
        parent: Node,
        siblingIndex: number,
        editorPosition: Vec3,      // 编辑器面板中的位置值
        editorRotation: Vec3,      // 编辑器面板中的旋转值（欧拉角）
        editorScale: Vec3,         // 编辑器面板中的缩放值
        worldRotation: Quat        // 世界旋转（用于备份）
    }> = [];
    
    private createdParents: Node[] = [];
    
    // ============ 操作按钮 ============
    
    /** 执行创建操作 */
    @property({ displayName: "🔄 创建空父节点", tooltip: "点击为每个子节点创建空的父节点，保持子节点编辑器面板值不变" })
    public get executeCreate() {
        return false;
    }
    public set executeCreate(v: boolean) {
        if (EDITOR && v) {
            this.createEmptyParentsWithEditorValues();
            console.log("✅ 空父节点创建完成！子节点编辑器面板值已保持");
        }
    }
    
    /** 撤销操作 */
    @property({ displayName: "↩️ 撤销创建", tooltip: "点击移除所有创建的父节点，恢复原始结构" })
    public get executeUndo() {
        return false;
    }
    public set executeUndo(v: boolean) {
        if (EDITOR && v) {
            this.removeEmptyParents();
            console.log("✅ 父节点已移除！子节点编辑器面板值已恢复");
        }
    }
    
    // ============ 核心方法 ============
    
    /** 创建空的父节点，保持子节点编辑器面板值 */
    private createEmptyParentsWithEditorValues() {
        // 清空之前的记录
        this.originalState = [];
        this.createdParents = [];
        
        const children = this.node.children;
        
        if (children.length === 0) {
            console.warn("⚠️ 当前节点下没有子节点");
            return;
        }
        
        console.log(`🔧 开始为 ${children.length} 个子节点创建空父节点...`);
        console.log(`💡 目标：创建父节点后，每个子节点在编辑器面板中显示的位置、旋转、缩放值保持不变`);
        
        // 记录所有子节点的原始编辑器面板值
        children.forEach((child, index) => {
            // 获取编辑器面板中显示的值
            const editorPosition = child.position.clone();           // 本地位置
            const editorRotation = child.eulerAngles.clone();       // 本地旋转（欧拉角）
            const editorScale = child.scale.clone();                // 本地缩放
            
            console.log(`📋 记录子节点 ${child.name} 的编辑器面板值：`);
            console.log(`   位置: (${editorPosition.x}, ${editorPosition.y}, ${editorPosition.z})`);
            console.log(`   旋转: (${editorRotation.x}, ${editorRotation.y}, ${editorRotation.z})`);
            console.log(`   缩放: (${editorScale.x}, ${editorScale.y}, ${editorScale.z})`);
            
            this.originalState.push({
                child: child,
                parent: child.parent,
                siblingIndex: child.getSiblingIndex(),
                editorPosition: editorPosition,
                editorRotation: editorRotation,
                editorScale: editorScale,
                worldRotation: child.worldRotation.clone()  // 备份世界旋转
            });
        });
        
        // 从后往前遍历，避免索引变化问题
        for (let i = children.length - 1; i >= 0; i--) {
            const childNode = children[i];
            this.createParentKeepEditorValues(childNode, i);
        }
        
        console.log(`✅ 创建了 ${this.createdParents.length} 个空父节点`);
        console.log(`🎯 所有子节点在编辑器面板中显示的位置、旋转、缩放值已保持为原始值`);
        
        // 验证结果
        this.verifyChildEditorValues();
    }
    
    /** 为单个子节点创建空父节点，保持编辑器面板值 */
    private createParentKeepEditorValues(childNode: Node, index: number) {
        // 1. 保存子节点的原始编辑器面板值
        const originalEditorPosition = childNode.position.clone();     // 直接复制位置
        const originalEditorRotation = childNode.eulerAngles.clone();  // 直接复制旋转（欧拉角）
        const originalEditorScale = childNode.scale.clone();           // 直接复制缩放
        
        // 2. 创建空的父节点
        const parentNode = new Node(this.parentNamePrefix + (index + 1));
        
        // 3. 设置父节点为默认值（位置0，旋转0，缩放1）
        parentNode.setPosition(0, 0, 0);
        parentNode.setRotationFromEuler(0, 0, 0);
        parentNode.setScale(1, 1, 1);
        
        // 4. 将父节点添加到当前节点下
        parentNode.parent = this.node;
        
        // 5. 将子节点移动到新父节点下
        childNode.parent = parentNode;
        
        // 6. 关键步骤：直接设置编辑器面板中的值！
        // 使用属性赋值，确保编辑器面板中显示的值不变
        childNode.setPosition(originalEditorPosition);
        childNode.eulerAngles = originalEditorRotation;  // 设置欧拉角
        childNode.setScale(originalEditorScale);
        
        // 7. 记录创建的父节点
        this.createdParents.push(parentNode);
        
        console.log(`   ✅ 创建父节点: ${parentNode.name} ← ${childNode.name}`);
        console.log(`      子节点 ${childNode.name} 在编辑器面板中的值：`);
        console.log(`        位置: (${originalEditorPosition.x}, ${originalEditorPosition.y}, ${originalEditorPosition.z})`);
        console.log(`        旋转: (${originalEditorRotation.x}, ${originalEditorRotation.y}, ${originalEditorRotation.z})`);
        console.log(`        缩放: (${originalEditorScale.x}, ${originalEditorScale.y}, ${originalEditorScale.z})`);
        
        return parentNode;
    }
    
    /** 移除空的父节点，恢复子节点原始编辑器面板值 */
    private removeEmptyParents() {
        if (this.createdParents.length === 0 && this.originalState.length === 0) {
            console.warn("⚠️ 没有可撤销的操作");
            return;
        }
        
        console.log(`🔧 开始移除空父节点，恢复子节点原始编辑器面板值...`);
        
        let restoredCount = 0;
        
        // 恢复每个子节点到原始状态
        this.originalState.forEach(state => {
            const childNode = state.child;
            
            // 检查这个子节点是否还在父节点下
            if (childNode.parent && childNode.parent.name.startsWith(this.parentNamePrefix)) {
                // 将子节点移回原来的父节点（this.node）
                childNode.parent = this.node;
                
                // 恢复原始兄弟索引
                childNode.setSiblingIndex(state.siblingIndex);
                
                // 恢复原始的编辑器面板值
                childNode.setPosition(state.editorPosition);
                childNode.eulerAngles = state.editorRotation;
                childNode.setScale(state.editorScale);
                
                console.log(`   ↩️ 恢复子节点: ${childNode.name}`);
                console.log(`      恢复后的编辑器面板值：`);
                console.log(`        位置: (${state.editorPosition.x}, ${state.editorPosition.y}, ${state.editorPosition.z})`);
                console.log(`        旋转: (${state.editorRotation.x}, ${state.editorRotation.y}, ${state.editorRotation.z})`);
                console.log(`        缩放: (${state.editorScale.x}, ${state.editorScale.y}, ${state.editorScale.z})`);
                
                restoredCount++;
            }
        });
        
        // 销毁所有创建的父节点
        let destroyedCount = 0;
        this.createdParents.forEach(parentNode => {
            if (!parentNode.isValid) return;
            
            console.log(`   🗑️ 移除父节点: ${parentNode.name}`);
            parentNode.destroy();
            destroyedCount++;
        });
        
        // 清空记录
        this.createdParents = [];
        this.originalState = [];
        
        console.log(`✅ 已移除 ${destroyedCount} 个空父节点，恢复了 ${restoredCount} 个子节点的原始编辑器面板值`);
    }
    
    /** 查看当前状态 */
    @property({ displayName: "🔍 查看状态", tooltip: "查看当前父节点和子节点的状态" })
    public get checkStatus() {
        return false;
    }
    public set checkStatus(v: boolean) {
        if (EDITOR && v) this.printCurrentStatus();
    }
    
    private printCurrentStatus() {
        const children = this.node.children;
        
        console.log(`📊 当前节点 ${this.node.name} 的状态：`);
        console.log(`子节点数量: ${children.length}`);
        console.log(`创建的空父节点数量: ${this.createdParents.length}`);
        
        children.forEach((node, index) => {
            if (node.name.startsWith(this.parentNamePrefix)) {
                // 这是创建的父节点
                console.log(`\n父节点 ${index + 1}: ${node.name}`);
                console.log(`   编辑器面板位置: (${node.position.x}, ${node.position.y}, ${node.position.z})`);
                console.log(`   编辑器面板欧拉角: (${node.eulerAngles.x}, ${node.eulerAngles.y}, ${node.eulerAngles.z})`);
                console.log(`   编辑器面板缩放: (${node.scale.x}, ${node.scale.y}, ${node.scale.z})`);
                
                // 检查子节点
                if (node.children.length > 0) {
                    node.children.forEach(child => {
                        console.log(`   └─ 子节点: ${child.name}`);
                        console.log(`       编辑器面板位置: (${child.position.x}, ${child.position.y}, ${child.position.z})`);
                        console.log(`       编辑器面板欧拉角: (${child.eulerAngles.x}, ${child.eulerAngles.y}, ${child.eulerAngles.z})`);
                        console.log(`       编辑器面板缩放: (${child.scale.x}, ${child.scale.y}, ${child.scale.z})`);
                    });
                }
            } else {
                // 这是普通子节点
                console.log(`\n子节点 ${index + 1}: ${node.name}`);
                console.log(`   编辑器面板位置: (${node.position.x}, ${node.position.y}, ${node.position.z})`);
                console.log(`   编辑器面板欧拉角: (${node.eulerAngles.x}, ${node.eulerAngles.y}, ${node.eulerAngles.z})`);
                console.log(`   编辑器面板缩放: (${node.scale.x}, ${node.scale.y}, ${node.scale.z})`);
            }
        });
    }
    
    /** 验证子节点编辑器面板值是否保持 */
    @property({ displayName: "✅ 验证编辑器面板值", tooltip: "验证子节点在编辑器面板中显示的值是否保持为原始值" })
    public get verifyEditorValues() {
        return false;
    }
    public set verifyEditorValues(v: boolean) {
        if (EDITOR && v) this.verifyChildEditorValues();
    }
    
    private verifyChildEditorValues() {
        if (this.originalState.length === 0) {
            console.log("⚠️ 没有原始状态记录");
            return;
        }
        
        console.log("🔍 验证子节点编辑器面板值保持情况：");
        
        let matchedCount = 0;
        let mismatchedCount = 0;
        
        this.originalState.forEach(state => {
            const childNode = state.child;
            
            // 检查子节点是否在创建的父节点下
            if (childNode.parent && childNode.parent.name.startsWith(this.parentNamePrefix)) {
                // 获取当前编辑器面板值
                const currentPos = childNode.position;
                const currentRot = childNode.eulerAngles;  // 欧拉角
                const currentScale = childNode.scale;
                
                // 比较编辑器面板值（使用容差比较）
                const tolerance = 0.0001;
                
                const posMatch = 
                    Math.abs(currentPos.x - state.editorPosition.x) < tolerance &&
                    Math.abs(currentPos.y - state.editorPosition.y) < tolerance &&
                    Math.abs(currentPos.z - state.editorPosition.z) < tolerance;
                
                const rotMatch = 
                    Math.abs(currentRot.x - state.editorRotation.x) < tolerance &&
                    Math.abs(currentRot.y - state.editorRotation.y) < tolerance &&
                    Math.abs(currentRot.z - state.editorRotation.z) < tolerance;
                    
                const scaleMatch = 
                    Math.abs(currentScale.x - state.editorScale.x) < tolerance &&
                    Math.abs(currentScale.y - state.editorScale.y) < tolerance &&
                    Math.abs(currentScale.z - state.editorScale.z) < tolerance;
                
                if (posMatch && rotMatch && scaleMatch) {
                    console.log(`✅ ${childNode.name}: 编辑器面板值保持正确`);
                    matchedCount++;
                } else {
                    console.log(`❌ ${childNode.name}: 编辑器面板值不匹配`);
                    if (!posMatch) {
                        console.log(`   期望位置: (${state.editorPosition.x}, ${state.editorPosition.y}, ${state.editorPosition.z})`);
                        console.log(`   实际位置: (${currentPos.x}, ${currentPos.y}, ${currentPos.z})`);
                    }
                    if (!rotMatch) {
                        console.log(`   期望旋转: (${state.editorRotation.x}, ${state.editorRotation.y}, ${state.editorRotation.z})`);
                        console.log(`   实际旋转: (${currentRot.x}, ${currentRot.y}, ${currentRot.z})`);
                    }
                    if (!scaleMatch) {
                        console.log(`   期望缩放: (${state.editorScale.x}, ${state.editorScale.y}, ${state.editorScale.z})`);
                        console.log(`   实际缩放: (${currentScale.x}, ${currentScale.y}, ${currentScale.z})`);
                    }
                    mismatchedCount++;
                }
            } else {
                console.log(`⚠️ ${childNode.name}: 不在创建的父节点下，跳过验证`);
            }
        });
        
        console.log(`📊 验证结果: ${matchedCount} 个匹配, ${mismatchedCount} 个不匹配`);
        
        if (mismatchedCount === 0 && matchedCount > 0) {
            console.log("🎉 完美！所有子节点在编辑器面板中显示的值都与原始值完全一致！");
        }
    }
    
    /** 清空状态记录 */
    @property({ displayName: "🧹 清空记录", tooltip: "清空所有状态记录" })
    public get clearRecords() {
        return false;
    }
    public set clearRecords(v: boolean) {
        if (EDITOR && v) {
            this.originalState = [];
            this.createdParents = [];
            console.log("🧹 已清空所有状态记录");
        }
    }
}
