import { _decorator, Component, Node, isValid } from 'cc';
const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 注意：把下面的某行注释了，就会只判断@property的属性。因为@property的属性才会是null
 * 脚本属性检查器，可以检查脚本属性是否挂载。（也就是说是把所有组件没有@property装饰的属性列出来）这个比ScriptPropertyChecker更好点，因为过滤了编辑器专用属性和组件
 * 用法：
 * 1. 将本脚本附加到一个空节点上。
 * 2. 设置检查范围（包括子节点）。
 * 3. 点击刷新按钮或在启动时自动检查。
 * 4. 查看控制台输出的检查结果。（包含未挂载的属性和已正确挂载的属性）
 */

@ccclass('ScriptPropertyChecker1')
@executeInEditMode
export class ScriptPropertyChecker1 extends Component {
    @property({
        tooltip: '是否包括子节点'
    })
    includeChildren: boolean = true;

    @property({
        tooltip: '是否在启动时自动检查'
    })
    autoCheckOnStart: boolean = false;

    @property({
        tooltip: '是否显示已正确设置的属性'
    })
    showValidProperties: boolean = false;

    @property({
        tooltip: '是否排除Cocos Creator自带的组件'
    })
    excludeCocosComponents: boolean = true;

    @property({
        type: Node,
        tooltip: '自定义检查的根节点（为空则使用当前节点）'
    })
    customRootNode: Node = null!;

    @property({
        visible: function (this: any) {
            // 在编辑器中显示刷新按钮
            return !!(window as any).cc && !!(window as any).cc.internal;
        }
    })
    private _refreshButton: boolean = false;

    @property
    get refreshButton() {
        return this._refreshButton;
    }
    
    set refreshButton(value: boolean) {
        if (value) {
            this.checkAllScripts();
        }
        this._refreshButton = false;
    }

    // Cocos Creator 3.x 自带组件列表
    private readonly COCOS_COMPONENTS: string[] = [
        // 基础组件
        'Transform',
        'UITransform',
        'Node',
        
        // 渲染组件
        'Sprite',
        'Label',
        'Mask',
        'Graphics',
        'RichText',
        'SpriteRenderer',
        'SkinnedMeshRenderer',
        'MeshRenderer',
        
        // UI组件
        'Button',
        'EditBox',
        'Layout',
        'ProgressBar',
        'ScrollView',
        'Slider',
        'Toggle',
        'ToggleContainer',
        'Widget',
        'Canvas',
        'UICoordinateTracker',
        
        // 动画组件
        'Animation',
        'AnimationController',
        
        // 物理组件
        'RigidBody',
        'Collider',
        'BoxCollider',
        'SphereCollider',
        'CapsuleCollider',
        'MeshCollider',
        'PhysicsMaterial',
        
        // 其他内置组件
        'Camera',
        'Light',
        'AudioSource',
        'ParticleSystem',
        'Terrain',
        'Billboard',
        'LODGroup',
        
        // 可能的名字变体
        'cc.Transform',
        'cc.UITransform',
        'cc.Sprite',
        'cc.Label',
        'cc.Button',
        'cc.Camera',
        'cc.AudioSource'
    ];

    start() {
        if (this.autoCheckOnStart) {
            this.checkAllScripts();
        }
    }

    /**
     * 检查所有脚本的未设置属性
     */
    public checkAllScripts(): void {
        const rootNode = this.customRootNode || this.node;
        console.log('=== 开始检查脚本属性 ===');
        console.log('检查根节点: ' + rootNode.name);
        console.log('排除Cocos组件: ' + (this.excludeCocosComponents ? '是' : '否'));
        
        var totalUnassigned = this._checkNodeRecursive(rootNode, 0);
        
        console.log('=== 检查完成 ===');
        console.log('总计发现 ' + totalUnassigned + ' 个未设置的属性');
    }

    /**
     * 递归检查节点及其子节点
     * @returns 未设置属性的总数
     */
    private _checkNodeRecursive(node: Node, depth: number): number {
        if (!isValid(node)) {
            return 0;
        }

        var indent = '';
        for (var i = 0; i < depth; i++) {
            indent += '  ';
        }
        
        var unassignedCount = 0;
        var hasUnassignedInNode = false;
        
        // 获取节点上的所有组件
        var components = node.getComponents(Component);
        
        // 按组件名排序，让输出更整洁
        components.sort(function(a, b) {
            return a.constructor.name.localeCompare(b.constructor.name);
        });
        
        for (var j = 0; j < components.length; j++) {
            var component = components[j];
            var componentUnassigned = this._checkComponentProperties(component, depth + 1);
            
            if (componentUnassigned > 0) {
                unassignedCount += componentUnassigned;
                hasUnassignedInNode = true;
            }
        }
        
        // 只在有未设置属性时才显示节点名
        if (hasUnassignedInNode) {
            console.log(indent + '📌 节点: ' + node.name);
        }
        
        // 递归检查子节点
        if (this.includeChildren && node.children.length > 0) {
            for (var k = 0; k < node.children.length; k++) {
                var child = node.children[k];
                unassignedCount += this._checkNodeRecursive(child, depth + 1);
            }
        }
        
        return unassignedCount;
    }

    /**
     * 检查单个组件的属性
     * @returns 该组件中未设置属性的数量
     */
    private _checkComponentProperties(component: Component, depth: number): number {
        // 检查是否为Cocos自带组件
        var componentName = component.constructor.name;
        
        if (this.excludeCocosComponents && this._isCocosComponent(componentName)) {
            return 0; // 跳过Cocos自带组件
        }
        
        var indent = '';
        for (var i = 0; i < depth; i++) {
            indent += '  ';
        }
        
        // 获取通过 @property 装饰的属性
        var propertyInfos = this._getPropertyInfos(component);
        var unassignedCount = 0;
        var hasUnassigned = false;
        
        // 按属性名排序
        propertyInfos.sort(function(a, b) {
            return a.name.localeCompare(b.name);
        });
        
        for (var j = 0; j < propertyInfos.length; j++) {
            var propertyInfo = propertyInfos[j];
            var value = propertyInfo.value;
            var isUnassigned = this._isPropertyUnassigned(value, propertyInfo.type);
            
            if (isUnassigned) {
                if (!hasUnassigned) {
                    console.log(indent + '   └─ 🟡 组件: ' + componentName);
                    hasUnassigned = true;
                }
                unassignedCount++;
                console.log(indent + '        ❌ ' + propertyInfo.name + 
                          ' (' + this._getTypeName(propertyInfo.type) + ')');
            } else if (this.showValidProperties) {
                if (!hasUnassigned) {
                    console.log(indent + '   └─ 🟢 组件: ' + componentName);
                    hasUnassigned = true;
                }
                console.log(indent + '        ✅ ' + propertyInfo.name + ' = ' + 
                          this._formatValue(value));
            }
        }
        
        if (!hasUnassigned && propertyInfos.length > 0) {
            console.log(indent + '   └─ ✅ 组件: ' + componentName + ' (所有属性已设置)');
        }
        
        return unassignedCount;
    }

    /**
     * 判断是否为Cocos自带组件
     */
    private _isCocosComponent(componentName: string): boolean {
        // 检查完整匹配
        for (var i = 0; i < this.COCOS_COMPONENTS.length; i++) {
            if (componentName === this.COCOS_COMPONENTS[i]) {
                return true;
            }
        }
        
        // 检查是否以'cc.'开头（旧版本组件名）
        if (componentName.indexOf('cc.') === 0) {
            return true;
        }
        
        // 检查是否包含'Component'且不是自定义组件
        if (componentName.indexOf('Component') !== -1 && 
            componentName !== 'ScriptPropertyChecker') {
            // 可能是内置组件
            return true;
        }
        
        return false;
    }

    /**
     * 获取组件的所有 @property 属性信息
     */
    private _getPropertyInfos(component: Component): Array<{name: string, value: any, type: any}> {
        var propertyInfos: Array<{name: string, value: any, type: any}> = [];
        
        // 遍历组件实例的所有属性
        var keys = Object.keys(component);
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            
            // 跳过私有属性和内置属性
            if (this._shouldSkipProperty(key)) {
                continue;
            }
            
            var value = (component as any)[key];
            
            // 尝试获取属性类型
            var type = this._getValueType(value);
            
            propertyInfos.push({
                name: key,
                value: value,
                type: type
            });
        }
        
        return propertyInfos;
    }

    /**
     * 判断是否应该跳过该属性
     */
    private _shouldSkipProperty(propertyName: string): boolean {
        // 跳过私有属性
        if (propertyName.charAt(0) === '_') {
            return true;
        }
        
        // 跳过内置属性
        var skipProperties = [
            'name', 'node', 'uuid', 'enabled', 
            '__classname__', '__type__', '__prefab',
            'constructor', 'prototype', 'length',
            'onLoad', 'start', 'update', 'lateUpdate',
            'onDestroy', 'onEnable', 'onDisable',
            // 新增：跳过编辑器专用属性
            'gizmo', 'iconGizmo', 'persistentGizmo',
            // 可能还有其他编辑器属性
            '_hideFlags', '__scriptAsset'
        ];
        
        return skipProperties.indexOf(propertyName) !== -1;
    }

    /**
     * 判断属性是否未设置
     */
    private _isPropertyUnassigned(value: any, type?: string): boolean {
        // 处理 null 和 undefined
        // if (value === null || value === undefined) {//这行注释了，就会只判断@property的属性。因为@property的属性才会是null
        if (value === null)
        {
            return true;
        }
        
        // 处理字符串
        if (typeof value === 'string') {
            return value === '';
        }
        
        // 处理数组
        if (Array.isArray(value)) {
            return value.length === 0;
        }
        
        // 处理节点
        if (value instanceof Node) {
            return !isValid(value);
        }
        
        // 处理组件
        if (value instanceof Component) {
            return !isValid(value);
        }
        
        // 处理对象（但不是数组、节点或组件）
        if (typeof value === 'object' && value !== null) {
            // 检查是否为空对象
            var keys = Object.keys(value);
            return keys.length === 0;
        }
        
        // 数值和布尔值不算未设置
        if (typeof value === 'number' || typeof value === 'boolean') {
            return false;
        }
        
        return false;
    }

    /**
     * 获取值的类型名
     */
    private _getValueType(value: any): string {
        if (value === null) return 'null';
        if (value === undefined) return 'undefined';
        
        if (value instanceof Node) return 'Node';
        if (value instanceof Component) return 'Component';
        if (Array.isArray(value)) return 'Array';
        
        return typeof value;
    }

    /**
     * 获取类型名（用于显示）
     */
    private _getTypeName(type: any): string {
        if (typeof type === 'string') {
            return type;
        }
        return 'unknown';
    }

    /**
     * 格式化输出值
     */
    private _formatValue(value: any): string {
        if (value === null) return 'null';
        if (value === undefined) return 'undefined';
        
        if (value instanceof Node) {
            return 'Node(' + (value.name || 'Unnamed') + ')';
        }
        
        if (value instanceof Component) {
            return 'Component(' + value.constructor.name + ')';
        }
        
        if (Array.isArray(value)) {
            var content = '';
            for (var i = 0; i < Math.min(value.length, 3); i++) {
                if (i > 0) content += ', ';
                content += this._formatValue(value[i]);
            }
            if (value.length > 3) content += ', ...';
            return '[' + content + ']';
        }
        
        if (typeof value === 'object' && value !== null) {
            var keys = Object.keys(value);
            if (keys.length === 0) return '{}';
            
            var content = '';
            var count = 0;
            for (var key in value) {
                if (count >= 3) break;
                if (content) content += ', ';
                content += key + ': ' + this._formatValue(value[key]);
                count++;
            }
            if (keys.length > 3) content += ', ...';
            return '{' + content + '}';
        }
        
        return String(value);
    }

    /**
     * 快速检查当前节点
     */
    public checkCurrentNode(): void {
        console.log('=== 检查当前节点 ===');
        var count = this._checkNodeRecursive(this.node, 0);
        console.log('发现 ' + count + ' 个未设置的属性');
        console.log('=== 检查完成 ===');
    }

    /**
     * 导出检查报告
     */
    public exportReport(): void {
        var rootNode = this.customRootNode || this.node;
        var report: any = {
            timestamp: new Date().toISOString(),
            rootNode: rootNode.name,
            includeChildren: this.includeChildren,
            excludeCocosComponents: this.excludeCocosComponents,
            nodes: []
        };

        this._collectReportData(rootNode, report, '');
        
        console.log('=== 脚本属性检查报告 ===');
        console.log(JSON.stringify(report, null, 2));
        
        // 保存到本地（仅浏览器环境）
        this._saveReportToFile(report);
    }

    /**
     * 收集检查报告数据
     */
    private _collectReportData(node: Node, report: any, path: string): void {
        var currentPath = path ? path + '/' + node.name : node.name;
        var nodeInfo: any = {
            name: node.name,
            path: currentPath,
            components: []
        };

        var components = node.getComponents(Component);
        for (var i = 0; i < components.length; i++) {
            var component = components[i];
            var componentName = component.constructor.name;
            
            // 如果排除Cocos组件且是Cocos组件，则跳过
            if (this.excludeCocosComponents && this._isCocosComponent(componentName)) {
                continue;
            }
            
            var componentInfo = this._collectComponentInfo(component);
            if (componentInfo.unassignedProperties.length > 0) {
                nodeInfo.components.push(componentInfo);
            }
        }

        if (nodeInfo.components.length > 0) {
            report.nodes.push(nodeInfo);
        }

        if (this.includeChildren) {
            for (var j = 0; j < node.children.length; j++) {
                this._collectReportData(node.children[j], report, currentPath);
            }
        }
    }

    /**
     * 收集组件信息
     */
    private _collectComponentInfo(component: Component): any {
        var propertyInfos = this._getPropertyInfos(component);
        var unassignedProperties: any[] = [];

        for (var i = 0; i < propertyInfos.length; i++) {
            var propertyInfo = propertyInfos[i];
            if (this._isPropertyUnassigned(propertyInfo.value, propertyInfo.type)) {
                unassignedProperties.push({
                    name: propertyInfo.name,
                    type: propertyInfo.type,
                    value: null
                });
            }
        }

        return {
            name: component.constructor.name,
            unassignedProperties: unassignedProperties
        };
    }

    /**
     * 保存检查报告到文件
     */
    private _saveReportToFile(report: any): void {
        if (typeof window === 'undefined' || !window.Blob) {
            console.log('当前环境不支持文件保存');
            return;
        }
        
        var reportText = JSON.stringify(report, null, 2);
        var blob = new Blob([reportText], { type: 'application/json' });
        var url = URL.createObjectURL(blob);
        
        var a = document.createElement('a');
        a.href = url;
        a.download = 'script-property-report-' + new Date().getTime() + '.json';
        document.body.appendChild(a);
        a.click();
        
        setTimeout(function() {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);
    }

    /**
     * 添加自定义Cocos组件名（如果需要）
     */
    public addCustomCocosComponentName(componentName: string): void {
        if (this.COCOS_COMPONENTS.indexOf(componentName) === -1) {
            this.COCOS_COMPONENTS.push(componentName);
            console.log('已添加组件到排除列表: ' + componentName);
        }
    }

    /**
     * 获取当前排除的Cocos组件列表
     */
    public getExcludedComponentList(): string[] {
        return [...this.COCOS_COMPONENTS];
    }
}