import { _decorator, Component, Node, director, Vec3, Color, Mat4, Quat, Vec2, Vec4, Enum } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

enum SearchScope {
    CurrentNodeAndChildren = 0,
    EntireScene = 1
}

declare const Editor: any;

/**
 * 属性编辑项定义
 */
@ccclass('PropertyEditItem')
class PropertyEditItem {
    @property({ tooltip: '要修改的属性名' })
    propName: string = '';

    @property({ tooltip: '目标值', multiline: true })
    propValue: string = '';
}

/**
 * 组件查找与属性修改工具 (自动填充版)
 * 新增：自动抓取当前属性值填充到列表，免去手写麻烦。
 */
@ccclass('ComponentFinderAndModifyAttrTool')
@executeInEditMode
export class ComponentFinderAndModifyAttrTool extends Component {

    // --- 1. 查找配置 ---
    @property({ type: Enum(SearchScope), tooltip: '选择查找范围' })
    scope: SearchScope = SearchScope.CurrentNodeAndChildren;

    @property({ tooltip: '要查找的组件名字（例如：MeshRenderer, AudioSource）' })
    componentName: string = '';

    @property({ tooltip: '查找成功后，是否在层级管理器中选中这些物体' })
    selectInHierarchy: boolean = true;

    // --- 2. 修改配置 ---
    
    // 这是一个辅助字段，用于告诉工具我们要抓取/操作哪个属性
    @property({ tooltip: '目标属性名（用于自动填充）' })
    targetPropertyName: string = '';

    @property({ 
        type: [PropertyEditItem], 
        tooltip: '修改列表。点击下方按钮自动填充，或手动添加。' 
    })
    editList: PropertyEditItem[] = [];

    // --- 3. 备份与撤销 ---
    @property({ multiline: true, readonly: true })
    backupData: string = '暂无备份数据';

    // --- 触发器 ---
    private _triggerSearch: boolean = false;
    @property({ displayName: "👉 1. 执行查找" })
    get triggerSearch(): boolean { return this._triggerSearch; }
    set triggerSearch(v: boolean) {
        if (EDITOR && v && !this._triggerSearch) this.doSearch();
        this._triggerSearch = false;
    }

    // 新增：自动填充按钮
    private _triggerAutoFill: boolean = false;
    @property({ 
        displayName: "📝 2. 自动填充当前值", 
        tooltip: '根据上方属性名，抓取所有组件当前的值并填入列表' 
    })
    get triggerAutoFill(): boolean { return this._triggerAutoFill; }
    set triggerAutoFill(v: boolean) {
        if (EDITOR && v && !this._triggerAutoFill) this.doAutoFill();
        this._triggerAutoFill = false;
    }

    private _triggerModify: boolean = false;
    @property({ displayName: "✍️ 3. 按顺序赋值" })
    get triggerModify(): boolean { return this._triggerModify; }
    set triggerModify(v: boolean) {
        if (EDITOR && v && !this._triggerModify) this.doModify();
        this._triggerModify = false;
    }

    private _triggerRestore: boolean = false;
    @property({ displayName: "🔙 4. 撤销上次修改" })
    get triggerRestore(): boolean { return this._triggerRestore; }
    set triggerRestore(v: boolean) {
        if (EDITOR && v && !this._triggerRestore) this.doRestore();
        this._triggerRestore = false;
    }

    private _lastFoundComponents: any[] = [];
    private _backupList: any[] = []; 

    start() {
        if (!EDITOR) this.destroy();
    }

    private doSearch() {
        if (!this.componentName) return;
        let searchRoot = this.scope === SearchScope.CurrentNodeAndChildren ? this.node : director.getScene();
        if (!searchRoot) return;

        this._lastFoundComponents = [];
        const foundNodes: Node[] = [];

        const walkNodes = (node: Node) => {
            const comp = node.getComponent(this.componentName);
            if (comp) {
                foundNodes.push(node);
                this._lastFoundComponents.push(comp);
            }
            node.children.forEach(walkNodes);
        };
        walkNodes(searchRoot);

        if (foundNodes.length === 0) {
            console.warn(`[Finder] 未找到组件: ${this.componentName}`);
        } else {
            console.log(`%c[Finder] 找到 ${foundNodes.length} 个组件，已缓存。`, 'color: #00FFFF;');
            if (this.selectInHierarchy && typeof Editor !== 'undefined') {
                Editor.Selection.clear('node');
                Editor.Selection.select('node', foundNodes.map(n => n.uuid));
            }
        }
    }

    /**
     * 新增功能：自动抓取当前值并填充列表
     */
    private doAutoFill() {
        if (this._lastFoundComponents.length === 0) {
            console.warn('[Finder] 请先执行查找。');
            return;
        }
        if (!this.targetPropertyName) {
            console.warn('[Finder] 请先填写“目标属性名”用于抓取。');
            return;
        }

        const propName = this.targetPropertyName.trim();
        console.log(`%c[Finder] 正在抓取属性: ${propName}`, 'color: #FFA500;');

        // 清空旧列表
        this.editList = [];

        this._lastFoundComponents.forEach((comp, index) => {
            const item = new PropertyEditItem();
            item.propName = propName; // 自动填好属性名
            
            if (propName in comp) {
                const val = comp[propName];
                // 将值转为字符串显示
                item.propValue = this.valueToString(val);
            } else {
                item.propValue = `<属性不存在>`;
                console.warn(`[Finder] 组件 ${comp.node.name} 不存在属性: ${propName}`);
            }
            
            this.editList.push(item);
        });

        console.log(`%c[Finder] 抓取完成！已生成 ${this.editList.length} 条数据。请直接在列表中修改数值。`, 'color: #00FF00;');
    }

    private doModify() {
        if (this._lastFoundComponents.length === 0) {
            console.warn('[Finder] 请先执行查找操作。');
            return;
        }
        if (this.editList.length === 0) {
            console.warn('[Finder] 修改列表为空。');
            return;
        }

        this._backupList = [];
        let successCount = 0;

        for (let i = 0; i < this.editList.length; i++) {
            const item = this.editList[i];
            const propName = item.propName.trim();
            const strValue = item.propValue;

            if (!propName || propName === "") continue; // 跳过空属性行

            if (i >= this._lastFoundComponents.length) break;
            const comp = this._lastFoundComponents[i];

            if (!(propName in comp)) {
                this._backupList.push(null);
                continue;
            }

            try {
                const currentVal = comp[propName];
                this._backupList.push(this.deepClone(currentVal));
                
                const finalValue = this.parseValue(strValue, currentVal);
                comp[propName] = finalValue;
                
                successCount++;
            } catch (e) {
                console.error(`修改失败 (${comp.node.name}):`, e);
                this._backupList.push(null);
            }
        }

        this.updateBackupDisplay();
        console.log(`%c[Finder] 赋值完成！成功 ${successCount} 个。`, 'color: #00FF00; font-weight: bold;');
    }

    private doRestore() {
        if (this._backupList.length === 0) {
            console.warn('[Finder] 无可撤销操作。');
            return;
        }
        
        let count = 0;
        for (let i = 0; i < this._backupList.length; i++) {
            const oldVal = this._backupList[i];
            if (oldVal === null) continue;

            if (i >= this._lastFoundComponents.length) break;
            const comp = this._lastFoundComponents[i];
            
            // 从 editList 获取属性名以确保一致性
            const propName = this.editList[i]?.propName.trim();
            if (!propName) continue;

            try {
                if (typeof oldVal === 'object' && oldVal !== null && typeof comp[propName] === 'object') {
                    comp[propName] = oldVal;
                } else {
                    comp[propName] = oldVal;
                }
                count++;
            } catch(e) {}
        }
        console.log(`%c[Finder] 撤销完成！还原 ${count} 个。`, 'color: #00FF00;');
    }

    // --- 辅助方法 ---

    /**
     * 将属性值转为适合编辑器显示的字符串
     */
    private valueToString(val: any): string {
        if (val === null) return "null";
        if (val === undefined) return "undefined";
        
        // 处理 Cocos 类型
        if (val instanceof Vec2 || val instanceof Vec3 || val instanceof Vec4 || 
            val instanceof Color || val instanceof Quat) {
            // 简单的 JSON 格式
            return JSON.stringify(val); 
        }

        // 处理普通对象
        if (typeof val === 'object') {
            try {
                return JSON.stringify(val);
            } catch(e) {
                return String(val);
            }
        }

        // 基础类型直接转字符串
        return String(val);
    }

    private updateBackupDisplay() {
        let str = "";
        for (let i = 0; i < this._backupList.length; i++) {
            const val = this._backupList[i];
            const pName = this.editList[i]?.propName || "?";
            str += `[${i}] ${pName}: ${this.valueToString(val)}\n`;
        }
        this.backupData = str || "无备份";
    }

    private deepClone(val: any): any {
        if (val === null || typeof val !== 'object') return val;
        if (typeof val.clone === 'function') return val.clone();
        if (val.constructor === Object) {
            const newObj: any = {};
            for (let key in val) newObj[key] = this.deepClone(val[key]);
            return newObj;
        }
        if (Array.isArray(val)) return val.map(item => this.deepClone(item));
        return val;
    }

    private parseValue(strVal: string, currentValue: any): any {
        if (strVal === 'true') return true;
        if (strVal === 'false') return false;
        if (!isNaN(Number(strVal)) && strVal.trim() !== '') return Number(strVal);

        if (strVal.startsWith('{') && strVal.endsWith('}')) {
            try {
                const obj = JSON.parse(strVal);
                if (typeof currentValue === 'object' && currentValue !== null) {
                    for (let key in obj) {
                        if (currentValue.hasOwnProperty(key)) {
                            currentValue[key] = obj[key];
                        }
                    }
                    return currentValue;
                }
                return obj;
            } catch (e) {}
        }
        return strVal;
    }
}