import { _decorator, Component, Node, director, Vec3, Color, Mat4, Quat, Vec2, Vec4, Enum } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

enum SearchScope {
    CurrentNodeAndChildren = 0,
    EntireScene = 1
}

declare const Editor: any;

/**
 * 属性编辑项定义
 */
@ccclass('PropertyEditItem')
class PropertyEditItem {
    @property({ tooltip: '要修改的属性名（如 enabled, speed）' })
    propName: string = '';

    @property({ tooltip: '目标值', multiline: true })
    propValue: string = '';
}

/**
 * 组件查找与属性修改工具 (一一对应版)
 * 功能：
 * 1. 查找组件并按顺序缓存。
 * 2. Edit List 的第 N 项会赋值给 第 N 个 找到的组件。
 * 3. 支持一键撤销。
 *  * 功能：查找组件 -> 打印日志 -> 高亮节点 -> 批量修改属性
 * 既可以查找也可以修改组件的属性，公有私有的属性都能修改。比如能修改组件的enabled，填false就会取消组件的勾选。也能修改显示在编辑器里的属性
 * 注意事项：
    撤销功能是基于内存的，如果关闭了编辑器或者场景，备份就会丢失。
    备份仅针对最近一次点击“修改”按钮的操作。

 */
@ccclass('ComponentFinderAndModifyAttrTool')
@executeInEditMode
export class ComponentFinderAndModifyAttrTool extends Component {

    // --- 1. 查找配置 ---
    @property({ type: Enum(SearchScope), tooltip: '选择查找范围' })
    scope: SearchScope = SearchScope.CurrentNodeAndChildren;

    @property({ tooltip: '要查找的组件名字（例如：MeshRenderer, AudioSource）' })
    componentName: string = '';

    @property({ tooltip: '查找成功后，是否在层级管理器中选中这些物体' })
    selectInHierarchy: boolean = true;

    // --- 2. 修改配置 (列表模式) ---
    @property({ 
        type: [PropertyEditItem], 
        tooltip: '修改列表。第N项会赋值给第N个找到的组件。请确保数量匹配。' 
    })
    editList: PropertyEditItem[] = [];

    // --- 3. 备份与撤销 ---
    @property({ 
        multiline: true, 
        tooltip: '修改前的属性值会自动备份在这里（只读）。',
        readonly: true 
    })
    backupData: string = '暂无备份数据';

    // --- 触发器 ---
    private _triggerSearch: boolean = false;
    @property({ displayName: "👉 1. 执行查找" })
    get triggerSearch(): boolean { return this._triggerSearch; }
    set triggerSearch(v: boolean) {
        if (EDITOR && v && !this._triggerSearch) this.doSearch();
        this._triggerSearch = false;
    }

    private _triggerModify: boolean = false;
    @property({ displayName: "✍️ 2. 按顺序赋值" })
    get triggerModify(): boolean { return this._triggerModify; }
    set triggerModify(v: boolean) {
        if (EDITOR && v && !this._triggerModify) this.doModify();
        this._triggerModify = false;
    }

    private _triggerRestore: boolean = false;
    @property({ 
        displayName: "🔙 3. 撤销上次修改", 
        tooltip: '将属性恢复到上次修改前的状态' 
    })
    get triggerRestore(): boolean { return this._triggerRestore; }
    set triggerRestore(v: boolean) {
        if (EDITOR && v && !this._triggerRestore) this.doRestore();
        this._triggerRestore = false;
    }

    // 缓存组件列表
    private _lastFoundComponents: any[] = [];
    
    // 备份数据：结构与 EditList 一一对应，存储对应索引组件的旧值
    // 结构：[ { propName: oldVal }, ... ]
    private _backupList: any[] = []; 

    start() {
        if (!EDITOR) this.destroy();
    }

    private doSearch() {
        if (!this.componentName) return;
        let searchRoot = this.scope === SearchScope.CurrentNodeAndChildren ? this.node : director.getScene();
        if (!searchRoot) return;

        this._lastFoundComponents = [];
        const foundNodes: Node[] = [];

        const walkNodes = (node: Node) => {
            const comp = node.getComponent(this.componentName);
            if (comp) {
                foundNodes.push(node);
                this._lastFoundComponents.push(comp);
            }
            node.children.forEach(walkNodes);
        };
        walkNodes(searchRoot);

        if (foundNodes.length === 0) {
            console.warn(`[ComponentFinder] 未找到组件: ${this.componentName}`);
            this.backupData = "未找到组件";
        } else {
            console.log(`%c[ComponentFinder] 找到 ${foundNodes.length} 个组件，已按顺序缓存。`, 'color: #00FFFF;');
            foundNodes.forEach((node, index) => {
                console.log(`${index + 1}. [${node.name}]`, node);
            });

            if (this.selectInHierarchy && typeof Editor !== 'undefined') {
                Editor.Selection.clear('node');
                Editor.Selection.select('node', foundNodes.map(n => n.uuid));
            }
        }
    }

    private doModify() {
        if (this._lastFoundComponents.length === 0) {
            console.warn('[ComponentFinder] 请先执行查找操作。');
            return;
        }
        if (this.editList.length === 0) {
            console.warn('[ComponentFinder] 修改列表为空。');
            return;
        }

        console.log(`%c[ComponentFinder] 开始按顺序赋值...`, 'color: #FFA500;');

        // 重置备份
        this._backupList = [];
        let successCount = 0;

        // 以 EditList 为主循环进行遍历
        for (let i = 0; i < this.editList.length; i++) {
            const item = this.editList[i];
            const propName = item.propName.trim();
            const strValue = item.propValue;

            if (!propName) continue;

            // 关键逻辑：取对应索引的组件
            if (i >= this._lastFoundComponents.length) {
                console.warn(`[ComponentFinder] 索引 ${i} 超出查找范围（只找到了 ${this._lastFoundComponents.length} 个组件），后续已忽略。`);
                break;
            }

            const comp = this._lastFoundComponents[i];

            if (!(propName in comp)) {
                console.warn(`[ComponentFinder] 组件 ${comp.node.name} (索引${i}) 无属性: ${propName}`);
                // 即使没有该属性，也在备份中占位，保持索引一致
                this._backupList.push(null); 
                continue;
            }

            try {
                const currentVal = comp[propName];

                // 1. 备份旧值 (深拷贝)
                const backupObj = this.deepClone(currentVal);
                this._backupList.push(backupObj);

                // 2. 解析新值并赋值
                const finalValue = this.parseValue(strValue, currentVal);
                comp[propName] = finalValue;
                
                successCount++;
                console.log(`[ComponentFinder] 成功: [${comp.node.name}] (${propName} = ${strValue})`);
            } catch (e) {
                console.error(`[ComponentFinder] 修改失败 (${comp.node.name}):`, e);
                this._backupList.push(null); // 失败也占位
            }
        }

        // 更新界面显示
        this.updateBackupDisplay();
        console.log(`%c[ComponentFinder] 赋值完成！成功修改 ${successCount} 个。`, 'color: #00FF00; font-weight: bold;');
    }

    private doRestore() {
        if (this._backupList.length === 0) {
            console.warn('[ComponentFinder] 没有可撤销的操作。');
            return;
        }
        
        console.log(`%c[ComponentFinder] 正在撤销修改...`, 'color: #FFAA00;');

        let count = 0;
        
        // 再次遍历备份列表，按索引还原
        for (let i = 0; i < this._backupList.length; i++) {
            const oldVal = this._backupList[i];
            
            // 如果当时备份的是 null (属性不存在或出错)，则跳过
            if (oldVal === null) continue;

            // 取对应索引的组件
            if (i >= this._lastFoundComponents.length) break;
            const comp = this._lastFoundComponents[i];

            // 这里的 propName 需要从 editList 里取，因为备份列表只存了值，没存 key
            // 所以要求 editList 的结构不能在修改后被用户乱改，否则 key 对不上
            // 为了更稳健，我们可以假设 editList 没变
            const propName = this.editList[i]?.propName.trim();
            if (!propName) continue;

            try {
                // 赋值逻辑
                if (typeof oldVal === 'object' && oldVal !== null && typeof comp[propName] === 'object') {
                    comp[propName] = oldVal;
                } else {
                    comp[propName] = oldVal;
                }
                count++;
            } catch(e) {
                console.error(`还原失败: ${comp.node.name}`, e);
            }
        }

        console.log(`%c[ComponentFinder] 撤销完成！还原了 ${count} 个属性。`, 'color: #00FF00;');
    }

    // --- 辅助工具方法 ---

    private updateBackupDisplay() {
        let displayStr = "";
        for (let i = 0; i < this._backupList.length; i++) {
            const val = this._backupList[i];
            const propName = this.editList[i]?.propName || "N/A";
            const compName = (i < this._lastFoundComponents.length) ? this._lastFoundComponents[i].node.name : "N/A";
            
            displayStr += `[${i}] ${compName}.${propName} = ${JSON.stringify(this.serializeForDisplay(val))}\n`;
        }
        this.backupData = displayStr || "无备份数据";
    }

    private deepClone(val: any): any {
        if (val === null || typeof val !== 'object') return val;
        if (typeof val.clone === 'function') return val.clone();
        
        if (val.constructor === Object) {
            const newObj: any = {};
            for (let key in val) newObj[key] = this.deepClone(val[key]);
            return newObj;
        }
        if (Array.isArray(val)) return val.map(item => this.deepClone(item));
        
        return val;
    }

    private serializeForDisplay(val: any): any {
        if (val === null || typeof val !== 'object') return val;
        if (val instanceof Vec2 || val instanceof Vec3 || val instanceof Vec4 || 
            val instanceof Color || val instanceof Quat || val instanceof Mat4) {
            return val;
        }
        try { return JSON.parse(JSON.stringify(val)); } 
        catch(e) { return String(val); }
    }

    private parseValue(strVal: string, currentValue: any): any {
        if (strVal === 'true') return true;
        if (strVal === 'false') return false;
        if (!isNaN(Number(strVal)) && strVal.trim() !== '') return Number(strVal);

        if (strVal.startsWith('{') && strVal.endsWith('}')) {
            try {
                const obj = JSON.parse(strVal);
                if (typeof currentValue === 'object' && currentValue !== null) {
                    for (let key in obj) {
                        if (currentValue.hasOwnProperty(key)) {
                            currentValue[key] = obj[key];
                        }
                    }
                    return currentValue;
                }
                return obj;
            } catch (e) {}
        }
        return strVal;
    }
}