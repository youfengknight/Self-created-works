// SimpleSwapTool.ts
import { _decorator, Component, Node, Vec3 } from 'cc';
const { ccclass, property, executeInEditMode } = _decorator;

@ccclass('SimpleSwapTool')
@executeInEditMode
export class SimpleSwapTool extends Component {

    @property(Node)
    objectA: Node | null = null;

    @property(Node)
    objectB: Node | null = null;

    /**
     * 在编辑器中点击这个按钮
     */
    @property
    get swapInEditor() {
        return false;
    }
    
    set swapInEditor(value: boolean) {
        if (value === true) {
            this.swapPositions();
        }
    }

    /**
     * 交换位置
     */
    public swapPositions() {
        if (!this.objectA || !this.objectB) {
            console.error('请先设置 objectA 和 objectB');
            return;
        }

        if (this.objectA === this.objectB) {
            console.error('objectA 和 objectB 不能是同一个物体');
            return;
        }

        // 交换位置
        const tempPos = new Vec3();
        Vec3.copy(tempPos, this.objectA.position);
        
        this.objectA.position = this.objectB.position.clone();
        this.objectB.position = tempPos;

        console.log(`✅ 位置已交换：${this.objectA.name} ↔ ${this.objectB.name}`);
    }
}