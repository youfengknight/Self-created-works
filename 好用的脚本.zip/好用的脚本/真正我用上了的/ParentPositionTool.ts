import { _decorator, Component, Node, Vec3 } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

/**
 * 父节点位置重置工具 (适配 Cocos Creator 3.x)
 * 功能：将父节点移动到子节点的世界位置，并将子节点本地坐标归零。在只有一层的父子关系下完美生效，多层的话父物体能正常到达目标位置，但是子物体的本地坐标都为0，但是中间的物体的本地坐标不会变。如果反过来的话，把子拖到父的框，父拖到子的框，则不会正常生效
 */
@ccclass('ParentPositionTool')
@executeInEditMode
export class ParentPositionTool extends Component {

    @property({ type: Node, tooltip: '请拖入需要移动的【父节点】' })
    parentNode: Node = null;

    @property({ type: Node, tooltip: '请拖入目标位置的【子节点】' })
    childNode: Node = null;

    // --- 核心修改 ---
    // 使用 boolean 类型作为触发器
    @property({
        displayName: "👉 点击执行合并",
        tooltip: "勾选此选项执行一次逻辑，执行完后会自动取消勾选"
    })
    public doMerge: boolean = false;

    /**
     * 利用 update 监听属性面板的变化
     * 在编辑器模式下，update 会每帧调用
     */
    update() {
        // 只在编辑器模式下运行
        if (EDITOR) {
            if (this.doMerge) {
                this.executeMove();
                // 执行完毕后，强制重置为 false，这样属性面板上的勾选会自动弹起
                this.doMerge = false;
            }
        }
    }

    /**
     * 具体的移动逻辑
     */
    private executeMove() {
        if (!this.parentNode || !this.childNode) {
            console.warn('[ParentPositionTool] 请先在属性面板中正确绑定 parentNode 和 childNode！');
            return;
        }

        // 1. 获取子节点当前的世界坐标
        const targetWorldPos = new Vec3();
        this.childNode.getWorldPosition(targetWorldPos);

        // 2. 将父节点直接设置到该世界坐标
        this.parentNode.setWorldPosition(targetWorldPos);

        // 3. 将子节点的本地坐标归零
        this.childNode.setPosition(Vec3.ZERO);

        console.log(`[EditorTool] 位置已重置。父节点移动至: [${targetWorldPos.x}, ${targetWorldPos.y}, ${targetWorldPos.z}]`);
    }
}
