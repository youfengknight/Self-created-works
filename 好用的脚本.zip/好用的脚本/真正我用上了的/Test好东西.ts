import { _decorator, Component, instantiate, Node, Prefab, Vec3 } from 'cc';
import { EDITOR } from 'cc/env';
const { ccclass, property, executeInEditMode } = _decorator;

@ccclass('Test')
@executeInEditMode
export class Test extends Component {
    @property(Node)
    private ctrlNode: Node = null;
    @property(Prefab)
    private enemyPrefab: Prefab = null;
    /** 执行一次 */
    @property({ displayName: "执行一次" })
    public get runningOnce() {
        return false;
    }
    public set runningOnce(v: boolean) {
        if (EDITOR) {
            this.runOnce();
            console.log("执行成功");
        }
    }




    /** 执行一次方法 */
    private runOnce() {
        this.node.removeAllChildren();
        for(let i = 0; i < this.ctrlNode.children.length; i++) {
            let localPos = this.ctrlNode.children[i].worldPosition;
            let xuanzhuan = this.ctrlNode.children[i].worldRotation;
            let enemyNode = instantiate(this.enemyPrefab);
            enemyNode.setParent(this.node);
            enemyNode.setWorldPosition(localPos);
            enemyNode.setWorldRotation(xuanzhuan);
        }
    }
}


