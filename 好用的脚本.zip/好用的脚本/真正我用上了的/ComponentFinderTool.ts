import { _decorator, Component, Node, director, Enum } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

// 定义查找范围的枚举
enum SearchScope {
    CurrentNodeAndChildren = 0, // 当前节点及子节点
    EntireScene = 1             // 整个场景
}

// 声明编辑器全局变量，防止 TS 报错
declare const Editor: any;

/**
 * 组件查找工具（增强版）
 * 功能：查找挂载了指定组件的节点，打印信息并在层级管理器中高亮选中
 */
@ccclass('ComponentFinderTool')
@executeInEditMode
export class ComponentFinderTool extends Component {

    @property({ type: Enum(SearchScope), tooltip: '选择查找范围' })
    scope: SearchScope = SearchScope.CurrentNodeAndChildren;

    @property({ tooltip: '要查找的组件名字（例如：MeshRenderer, AudioSource）' })
    componentName: string = '';

    @property({ tooltip: '查找成功后，是否自动在层级管理器中选中这些物体？\n注意：如果找到的物体过多，可能会造成编辑器短暂卡顿。' })
    selectInHierarchy: boolean = true;

    private _triggerSearch: boolean = false;
    
    @property({ 
        displayName: "👉 点击执行查找", 
        tooltip: '勾选此项即可开始查找' 
    })
    get triggerSearch(): boolean {
        return this._triggerSearch;
    }
    set triggerSearch(v: boolean) {
        if (EDITOR && v && !this._triggerSearch) {
            this.doSearch();
        }
        this._triggerSearch = false;
    }

    start () {
        if (!EDITOR) {
            this.destroy();
        }
    }

    private doSearch() {
        if (!this.componentName || this.componentName.trim() === '') {
            console.warn('[ComponentFinder] 请先输入要查找的组件名字！');
            return;
        }

        console.log(`%c[ComponentFinder] 开始查找组件: "${this.componentName}"`, 'color: #00FF00; font-weight: bold;');

        let searchRoot: Node | null = null;
        
        if (this.scope === SearchScope.CurrentNodeAndChildren) {
            searchRoot = this.node;
        } else {
            searchRoot = director.getScene();
        }

        if (!searchRoot) {
            console.error('[ComponentFinder] 未找到查找范围的根节点！');
            return;
        }

        const foundNodes: Node[] = [];

        const walkNodes = (node: Node) => {
            const comp = node.getComponent(this.componentName);
            if (comp) {
                foundNodes.push(node);
            }
            for (const child of node.children) {
                walkNodes(child);
            }
        };

        walkNodes(searchRoot);

        // 输出结果
        if (foundNodes.length === 0) {
            console.warn(`[ComponentFinder] 未找到挂载组件 "${this.componentName}" 的物体。`);
            // 如果没找到，清空之前的选中状态
            if (this.selectInHierarchy && typeof Editor !== 'undefined') {
                Editor.Selection.clear('node');
            }
        } else {
            console.log(`%c[ComponentFinder] 查找完成！共找到 ${foundNodes.length} 个物体：`, 'color: #00FFFF; font-weight: bold;');
            
            // 用于存储 UUID 的数组
            const uuids: string[] = [];

            foundNodes.forEach((node, index) => {
                const path = this.getNodePath(node);
                console.log(`${index + 1}. [${node.name}] 路径: ${path}`, node);
                
                // 获取节点的 UUID
                // 注意：在 Cocos 3.x 中，node.uuid 是标准属性
                uuids.push(node.uuid);
            });

            // 核心功能：在层级管理器中选中
            if (this.selectInHierarchy && typeof Editor !== 'undefined') {
                // 先取消之前的选中
                Editor.Selection.clear('node');
                // 选中新找到的节点（传入 UUID 数组）
                // 第一个参数 'node' 代表选中的类型是节点
                // 第二个参数是 UUID 数组
                Editor.Selection.select('node', uuids);
                
                console.log(`%c[ComponentFinder] 已在层级管理器中选中 ${uuids.length} 个节点。`, 'color: #FFA500;');
            }
        }
    }

    private getNodePath(node: Node): string {
        if (!node) return '';
        let path = node.name;
        let parent = node.parent;
        while (parent && parent !== director.getScene()) {
            path = parent.name + '/' + path;
            parent = parent.parent;
        }
        return path;
    }
}