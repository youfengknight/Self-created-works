import { _decorator, Component, Node, director, Enum } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

// 定义查找范围的枚举
enum SearchScope {
    CurrentNodeAndChildren = 0, // 当前节点及子节点
    EntireScene = 1             // 整个场景
}

// 声明编辑器全局变量
declare const Editor: any;

@ccclass('MissingReferenceDetector')
@executeInEditMode
export class MissingReferenceDetector extends Component {

    @property({ type: Enum(SearchScope), tooltip: '选择查找范围' })
    scope: SearchScope = SearchScope.CurrentNodeAndChildren;

    @property({ tooltip: '检测节点上是否挂载了丢失的脚本组件（红色报错）' })
    checkMissingScripts: boolean = true;

    @property({ 
        tooltip: '检测脚本中值为 null 的引用属性。\n注意：某些属性故意设为 null 也会被检测出来，请根据业务逻辑判断。' 
    })
    checkNullReferences: boolean = true;

    @property({ 
        tooltip: '查找完成后，是否自动在层级管理器中选中这些有问题的物体？\n(如果问题较多，建议关闭以防卡顿)' 
    })
    selectInHierarchy: boolean = true;

    private _triggerSearch: boolean = false;

    @property({
        displayName: "👉 开始体检",
        tooltip: '勾选此项开始检测问题'
    })
    get triggerSearch(): boolean {
        return this._triggerSearch;
    }
    set triggerSearch(v: boolean) {
        if (EDITOR && v && !this._triggerSearch) {
            this.doDetection();
        }
        this._triggerSearch = false;
    }

    start() {
        if (!EDITOR) {
            this.destroy();
        }
    }

    private doDetection() {
        console.log(`%c[体检工具] 开始检测...`, 'color: #00FF00; font-weight: bold; font-size: 14px;');

        let searchRoot: Node | null = null;
        if (this.scope === SearchScope.CurrentNodeAndChildren) {
            searchRoot = this.node;
        } else {
            searchRoot = director.getScene();
        }

        if (!searchRoot) return;

        // 存储问题节点的 UUID
        const problemNodeUUIDs: string[] = [];
        let missingScriptCount = 0;
        let nullRefCount = 0;

        // 遍历节点
        const walkNodes = (node: Node) => {
            let nodeHasProblem = false;

            // 1. 检测丢失的脚本
            if (this.checkMissingScripts) {
                // @ts-ignore
                const comps = node._components;
                if (comps) {
                    for (let i = 0; i < comps.length; i++) {
                        const comp = comps[i];
                        try {
                            const compName = comp.constructor.name;
                            // 如果构造函数名字异常，或者无法获取有效名字
                            if (!compName || compName === '' || compName === 'Object') {
                                console.error(`[丢失脚本] 节点 "${node.name}" 上存在丢失的组件！`, node);
                                missingScriptCount++;
                                nodeHasProblem = true;
                            }
                        } catch (e) {
                            console.error(`[丢失脚本] 节点 "${node.name}" 上存在损坏的组件！`, node);
                            missingScriptCount++;
                            nodeHasProblem = true;
                        }
                    }
                }
            }

            // 2. 检测空引用
            if (this.checkNullReferences) {
                const comps = node.components; 
                for (const comp of comps) {
                    for (const key in comp) {
                        // 过滤内置属性和私有属性
                        if (key.startsWith('_')) continue;
                        if (['node', 'name', 'uuid', 'enabled', 'isValid'].indexOf(key) !== -1) continue;
                        
                        const value = comp[key];
                        
                        if ((value === null || value === undefined) && typeof comp[key] !== 'function') {
                            console.warn(`[空引用] 节点 "${node.name}" 的组件 "${comp.constructor.name}" 属性 "${key}" 为 null。`, node);
                            nullRefCount++;
                            nodeHasProblem = true;
                        }
                    }
                }
            }

            if (nodeHasProblem) {
                problemNodeUUIDs.push(node.uuid);
            }

            // 递归子节点
            for (const child of node.children) {
                walkNodes(child);
            }
        };

        walkNodes(searchRoot);

        // 输出总结
        console.log(`%c[体检结果] 检测完成！`, 'color: #00FFFF; font-weight: bold; font-size: 14px;');
        
        if (missingScriptCount === 0 && nullRefCount === 0) {
            console.log('%c未发现丢失脚本或空引用问题，项目非常健康！', 'color: green; font-size: 12px;');
        } else {
            if (missingScriptCount > 0) {
                console.error(`发现 ${missingScriptCount} 个丢失的脚本组件！`);
            }
            if (nullRefCount > 0) {
                console.warn(`发现 ${nullRefCount} 处空引用属性。`);
            }

            // 核心修改：根据开关决定是否选中
            if (this.selectInHierarchy && problemNodeUUIDs.length > 0 && typeof Editor !== 'undefined') {
                Editor.Selection.clear('node');
                Editor.Selection.select('node', problemNodeUUIDs);
                console.log(`%c已在层级管理器中选中 ${problemNodeUUIDs.length} 个问题节点。`, 'color: #FFA500;');
            }
        }
    }
}