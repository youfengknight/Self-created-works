import { _decorator, Component, Node, director, Enum } from 'cc';
import { EDITOR } from 'cc/env';

const { ccclass, property, executeInEditMode } = _decorator;

// 定义查找范围的枚举
enum SearchScope {
    CurrentNodeAndChildren = 0, // 当前节点及子节点
    EntireScene = 1             // 整个场景
}

/**
 * 组件查找工具
 * 功能：在编辑器中查找挂载了指定组件的节点，并打印信息
 */
@ccclass('ComponentFinderTool')
@executeInEditMode
export class ComponentFinderTool extends Component {

    // 属性定义
    @property({ type:  Enum(SearchScope), tooltip: '选择查找范围，当前|全局' })
    scope: SearchScope = SearchScope.CurrentNodeAndChildren;
    // // 属性定义
    // @property({ type: SearchScope, tooltip: '选择查找范围' })
    // scope: SearchScope = SearchScope.CurrentNodeAndChildren;

    @property({ tooltip: '要查找的组件名字（例如：MeshRenderer, AudioSource）' })
    componentName: string = '';

    // 这是一个编辑器专用的属性，用于模拟按钮
    // 我们利用 get/set 访问器，当在面板中“勾选”它时触发查找，随后立即重置为 false
    private _triggerSearch: boolean = false;
    
    @property({ 
        displayName: "👉 点击执行查找", 
        tooltip: '勾选此项或点击右侧按钮即可开始查找（查找完成后会自动取消勾选）' 
    })
    get triggerSearch(): boolean {
        return this._triggerSearch;
    }
    set triggerSearch(v: boolean) {
        if (EDITOR && v && !this._triggerSearch) {
            // 当用户尝试将其设为 true 时，执行查找逻辑
            this.doSearch();
        }
        // 无论是否执行，都重置为 false，方便下次点击
        this._triggerSearch = false;
    }

    // 仅在编辑器模式下运行
    start () {
        if (!EDITOR) {
            // 如果是运行时，可以销毁自身或者禁用，避免性能消耗
            this.destroy();
        }
    }

    /**
     * 执行查找逻辑
     */
    private doSearch() {
        if (!this.componentName || this.componentName.trim() === '') {
            console.warn('[ComponentFinder] 请先输入要查找的组件名字！');
            return;
        }

        console.log("=================================");
        
        console.log(`%c[ComponentFinder] 开始查找组件: "${this.componentName}"`, 'color: #00FF00; font-weight: bold;');

        let searchRoot: Node | null = null;
        
        // 根据范围确定根节点
        if (this.scope === SearchScope.CurrentNodeAndChildren) {
            searchRoot = this.node;
        } else {
            // 获取当前场景
            searchRoot = director.getScene();
        }

        if (!searchRoot) {
            console.error('[ComponentFinder] 未找到查找范围的根节点！');
            return;
        }

        const foundNodes: Node[] = [];

        // 递归遍历节点树
        const walkNodes = (node: Node) => {
            // 检查节点是否挂载了该组件
            // 注意：getComponent 传入字符串在 Cocos Creator 3.x 中是支持的
            const comp = node.getComponent(this.componentName);
            if (comp) {
                foundNodes.push(node);
            }
            
            // 递归遍历子节点
            for (const child of node.children) {
                walkNodes(child);
            }
        };

        walkNodes(searchRoot);

        // 输出结果
        if (foundNodes.length === 0) {
            console.warn(`[ComponentFinder] 未找到挂载组件 "${this.componentName}" 的物体。`);
        } else {
            console.log(`%c[ComponentFinder] 查找完成！共找到 ${foundNodes.length} 个物体：`, 'color: #00FFFF; font-weight: bold;');
            console.log("=================================");
            foundNodes.forEach((node, index) => {
                // 获取节点在层级管理器中的路径，方便定位
                const path = this.getNodePath(node);
                console.log(`${index + 1}. [${node.name}] 路径: ${path}`, node);
            });
        }
    }

    /**
     * 辅助函数：获取节点在层级中的路径
     */
    private getNodePath(node: Node): string {
        if (!node) return '';
        let path = node.name;
        let parent = node.parent;
        while (parent && parent !== director.getScene()) {
            path = parent.name + '/' + path;
            parent = parent.parent;
        }
        return path;
    }
}