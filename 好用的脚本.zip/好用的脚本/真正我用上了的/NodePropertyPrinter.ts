import { EDITOR } from 'cc/env';
import { _decorator, Component, Node, Vec3, Quat } from 'cc';

const { ccclass, property, executeInEditMode } = _decorator;
// 用于在编辑器中打印节点的属性,方便调试。世界坐标系的位置、旋转、缩放还有基础属性以及本地坐标系的基础属性。

@ccclass('NodePropertyPrinter')
@executeInEditMode
export class NodePropertyPrinter extends Component {

    @property({ type: Node, tooltip: '拖拽任意节点到此，将打印其属性' })
    targetNode: Node | null = null;

    // 存储上一次的节点引用，用于检测变化
    private _lastNode: Node | null = null;

    update(deltaTime: number) {
        if (!EDITOR) return;
        
        // 检查是否有新的节点被拖入
        if (this.targetNode && this.targetNode !== this._lastNode) {
            this.printNodeProperties();
            this._lastNode = this.targetNode;
        }
    }

    /**
     * 打印节点的世界属性和局部属性
     */
    private printNodeProperties(): void {
        if (!this.targetNode) return;

        console.log('========== 节点属性打印 ==========');
        console.log('节点名称:', this.targetNode.name);
        console.log('节点UUID:', this.targetNode.uuid);
        
        // 世界属性
        const worldPosition = new Vec3();
        const worldScale = new Vec3();
        const worldRotation = new Quat();
        
        this.targetNode.getWorldPosition(worldPosition);
        this.targetNode.getWorldScale(worldScale);
        this.targetNode.getWorldRotation(worldRotation);
        
        console.log('--- 世界属性 ---');
        console.log('世界位置:', `x: ${worldPosition.x.toFixed(3)}, y: ${worldPosition.y.toFixed(3)}, z: ${worldPosition.z.toFixed(3)}`);
        console.log('世界缩放:', `x: ${worldScale.x.toFixed(3)}, y: ${worldScale.y.toFixed(3)}, z: ${worldScale.z.toFixed(3)}`);
        
        const eulerWorldRotation = new Vec3();
        worldRotation.getEulerAngles(eulerWorldRotation);
        console.log('世界旋转(欧拉角):', `x: ${eulerWorldRotation.x.toFixed(3)}, y: ${eulerWorldRotation.y.toFixed(3)}, z: ${eulerWorldRotation.z.toFixed(3)}`);
        
        // 局部属性
        const localPosition = this.targetNode.position;
        const localScale = this.targetNode.scale;
        const localRotation = this.targetNode.rotation;
        
        console.log('--- 局部属性 ---');
        console.log('局部位置:', `x: ${localPosition.x.toFixed(3)}, y: ${localPosition.y.toFixed(3)}, z: ${localPosition.z.toFixed(3)}`);
        console.log('局部缩放:', `x: ${localScale.x.toFixed(3)}, y: ${localScale.y.toFixed(3)}, z: ${localScale.z.toFixed(3)}`);
        
        const eulerLocalRotation = new Vec3();
        localRotation.getEulerAngles(eulerLocalRotation);
        console.log('局部旋转(欧拉角):', `x: ${eulerLocalRotation.x.toFixed(3)}, y: ${eulerLocalRotation.y.toFixed(3)}, z: ${eulerLocalRotation.z.toFixed(3)}`);
        
        // 四元数格式的旋转
        console.log('--- 旋转(四元数) ---');
        console.log('世界旋转(四元数):', `x: ${worldRotation.x.toFixed(3)}, y: ${worldRotation.y.toFixed(3)}, z: ${worldRotation.z.toFixed(3)}, w: ${worldRotation.w.toFixed(3)}`);
        console.log('局部旋转(四元数):', `x: ${localRotation.x.toFixed(3)}, y: ${localRotation.y.toFixed(3)}, z: ${localRotation.z.toFixed(3)}, w: ${localRotation.w.toFixed(3)}`);
        
        console.log('========== 打印结束 ==========');
        console.log('\n'); // 添加空行以便区分
    }

    /**
     * 当属性在编辑器中发生变化时调用
     */
    onPropertyChanged(): void {
        if (!EDITOR) return;
        this.printNodeProperties();
    }

    onDestroy() {
        this._lastNode = null;
    }
}