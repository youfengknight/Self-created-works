import { _decorator,Camera, Component, Node, Vec3, input, Input, EventKeyboard, KeyCode, RigidBody, CharacterController, CCFloat, CCBoolean, Collider, ICollisionEvent } from 'cc';
import { MainGame } from '../MainGame';
const { ccclass, property } = _decorator;


/**
 * 玩家移动脚本,只是让AI写的简单的键盘移动，已经没用了
 */
@ccclass('PlayerMove')
export class PlayerMove extends Component {

    @property({ tooltip: '移动速度' })
    moveSpeed: number = 10; // 米/秒

    @property({ tooltip: '跳跃力度' })
    jumpForce: number = 8; // 米/秒

    @property({ tooltip: '重力加速度' })
    gravity: number = -20; // 米/秒²

    @property({ tooltip: '是否允许跳跃' })
    canJump: boolean = true;

    @property({ tooltip: '是否使用CharacterController' })
    useCharacterController: boolean = false;

    private rigidbody: RigidBody = null;
    private collider: Collider = null;
    private characterController: CharacterController = null;
    private velocity: Vec3 = new Vec3();
    private isGrounded: boolean = false;
    
    // 存储按键状态
    private keysPressed: Set<KeyCode> = new Set();

    start() {
        this.collider = this.getComponent(Collider);

        // this.collider.on('onCollisionEnter', this.onCollisionEnter, this);


        if (this.useCharacterController) {
            this.characterController = this.getComponent(CharacterController);
            if (!this.characterController) {
                // console.warn('未找到 CharacterController 组件');
            }
        } else {
            this.rigidbody = this.getComponent(RigidBody);
            if (!this.rigidbody) {
                // console.warn('未找到 RigidBody 组件，已自动添加');
                this.rigidbody = this.addComponent(RigidBody);
                this.rigidbody.useGravity = false; // 我们自己处理重力
            } else {
                this.rigidbody.useGravity = false;
            }
        }

        // 注册键盘事件
        input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        input.on(Input.EventType.KEY_UP, this.onKeyUp, this);
    }

    update(deltaTime: number) {
        if (MainGame.instance.isGameOver) {
            return;
        }        // 水平移动输入
        let horizontal = 0;
        let vertical = 0;

        if (this.keysPressed.has(KeyCode.KEY_A) || this.keysPressed.has(KeyCode.ARROW_LEFT)) {
            // console.log('按下了A键或左箭头键');
            horizontal = -1;
        } else if (this.keysPressed.has(KeyCode.KEY_D) || this.keysPressed.has(KeyCode.ARROW_RIGHT)) {
            // console.log('按下了D键或右箭头键');
            horizontal = 1;
        }

        if (this.keysPressed.has(KeyCode.KEY_W) || this.keysPressed.has(KeyCode.ARROW_UP)) {
            // console.log('按下了W键或上箭头键');
            vertical = 1;
        } else if (this.keysPressed.has(KeyCode.KEY_S) || this.keysPressed.has(KeyCode.ARROW_DOWN)) {
            // console.log('按下了S键或下箭头键');
            vertical = -1;
        }

        // 计算水平方向移动向量
        const cameraForward = new Vec3();
        const cameraRight = new Vec3();
        
        // // 获取场景主相机的方向
        // const sceneCamera = this.node.scene.renderScene.findCamera('Main Camera') || 
        //                    this.node.scene.renderScene.cameras[0];
        

        // 获取场景主相机的方向
        let sceneCamera = null;
        // 方法1: 按名称查找主相机
        const cameraNode = this.node.scene.getChildByName('Main Camera');
        if (cameraNode) {
            sceneCamera = cameraNode.getComponent(Camera);
        }

        // 方法2: 如果找不到，尝试获取第一个相机组件
        if (!sceneCamera) {
            const cameras = this.node.scene.getComponentsInChildren(Camera);
            if (cameras.length > 0) {
            sceneCamera = cameras[0];
            }
        }

        if (sceneCamera) {
            Vec3.transformQuat(cameraForward, Vec3.FORWARD, sceneCamera.node.worldRotation);
            Vec3.transformQuat(cameraRight, Vec3.RIGHT, sceneCamera.node.worldRotation);
            
            // 忽略Y轴分量，只保留水平方向
            cameraForward.y = 0;
            cameraRight.y = 0;
            Vec3.normalize(cameraForward, cameraForward);
            Vec3.normalize(cameraRight, cameraRight);
        } else {
            // 如果找不到相机，使用默认的世界坐标系
            Vec3.copy(cameraForward, Vec3.FORWARD);
            Vec3.copy(cameraRight, Vec3.RIGHT);
        }

        const moveDirection = new Vec3();
        Vec3.multiplyScalar(moveDirection, cameraRight, horizontal);
        const forwardComponent = new Vec3();
        Vec3.multiplyScalar(forwardComponent, cameraForward, vertical);
        Vec3.add(moveDirection, moveDirection, forwardComponent);

        if (!Vec3.equals(moveDirection, Vec3.ZERO)) {
            Vec3.normalize(moveDirection, moveDirection);
            Vec3.multiplyScalar(moveDirection, moveDirection, this.moveSpeed);
        }

        // 应用重力
        this.velocity.y += this.gravity * deltaTime;

        // 更新X和Z轴速度
        this.velocity.x = moveDirection.x;
        this.velocity.z = moveDirection.z;

        // 应用移动
        if (this.useCharacterController && this.characterController) {
            // 使用CharacterController移动
            this.characterController.move(this.velocity.multiplyScalar(deltaTime));
        } else if (this.rigidbody) {
            // 使用Rigidbody移动
            this.rigidbody.setLinearVelocity(this.velocity);
        }

        // 检查是否在地面（简单检测，实际项目中需要更精确的检测）
        if (this.node.worldPosition.y <= 0.5) { // 假设地面在y=0，角色高度为1
            this.isGrounded = true;
            if (this.velocity.y < 0) {
                this.velocity.y = 0;
            }
        } else {
            this.isGrounded = false;
        }
    }

    onKeyDown(event: EventKeyboard) {
        // 添加按键到按下集合
        this.keysPressed.add(event.keyCode);
        
        // 跳跃
        if (event.keyCode === KeyCode.SPACE && this.canJump && this.isGrounded) {
            this.velocity.y = this.jumpForce;
            this.isGrounded = false;
        }
    }

    onKeyUp(event: EventKeyboard) {
        // 从按下集合中移除按键
        this.keysPressed.delete(event.keyCode);
    }

    onDestroy() {
        // 移除键盘事件监听
        input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        input.off(Input.EventType.KEY_UP, this.onKeyUp, this);
    }




    /*******************
     * 
     * 下面是跟金币相关代码
     * 
     *********************/
    // onCollisionEnter(event: ICollisionEvent)  {
    //     if (event.otherCollider.node.name === "createTent") {
    //         // 处理金币收集逻辑
    //         console.log('收集到金币🎉');

    //         // 调用金币管理器的方法，将金币飞出去
    //         // CoinManager.instance.flyCoinAway(event.otherCollider.node);

    //         console.log(MoneyBag.instance.lastItem());
            
    //         MoneyBag.instance.remove(MoneyBag.instance.lastItem(),event.otherCollider.node,2);
    //         // 销毁金币节点
    //         // other.destroy();
    //     }
    // }

}



