import { _decorator, Camera, Component, EventHandler, Node, Quat, Vec3 } from 'cc';
const { ccclass, property, type } = _decorator;

/**
 * @en The component that converts 3D node coordinates to UI node coordinates.
 * It mainly provides the converted world coordinates after mapping and the perspective ratio of the simulated perspective camera.
 * @zh 3D 节点坐标转换到 UI 节点坐标组件
 * 主要提供映射后的转换世界坐标以及模拟透视相机远近比。
 */

// 3D 节点坐标转换到 UI 节点坐标组件，不知道有啥用
@ccclass('UICoordinateTracker')
export class UICoordinateTracker extends Component {
    /** 是否跟随相机缩放 */
    followScale: boolean = true;
    /** 位置缓动时间（秒），为 0 则不缓动 */
    public smoothTime: number = 0;
    /**
     * @en
     * Target node.
     *
     * @zh
     * 目标对象。
     */
    @type(Node)
    get target(): Node | null {
        return this._target;
    }

    set target(value) {
        if (this._target === value) {
            return;
        }

        this._target = value;
        this._checkCanMove();
    }

    /**
     * @en
     * The 3D camera representing the original coordinate system.
     *
     * @zh
     * 照射相机。
     */
    @type(Camera)
    get camera(): Camera | null {
        return this._camera;
    }

    set camera(value) {
        if (this._camera === value) {
            return;
        }

        this._camera = value;
        this._checkCanMove();
    }

    /**
     * @en
     * Whether to scale the converted 2d node's size according to the distance between the camera and the 3d node.
     *
     * @zh
     * 是否是缩放映射。
     */
    get useScale(): boolean {
        return this._useScale;
    }

    set useScale(value) {
        if (this._useScale === value) {
            return;
        }

        this._useScale = value;
    }

    /**
     * @en
     * The distance from the camera for displaying the 2d node in normal size.
     *
     * @zh
     * 距相机多少距离为正常显示计算大小。
     */
    get distance(): number {
        return this._distance;
    }

    set distance(value) {
        if (this._distance === value) {
            return;
        }

        this._distance = value;
    }


    protected _target: Node | null = null;
    protected _camera: Camera | null = null;
    protected _useScale = true;
    protected _distance = 1;

    protected _transformPos = new Vec3();
    protected _viewPos = new Vec3();
    /** 用于位置插值的临时向量 */
    protected _smoothPos = new Vec3();
    protected _canMove = true;

    protected QuatZero: Quat = new Quat();

    public onEnable(): void {
        this._checkCanMove();
    }

    public lateUpdate(dt: number): void {
        // 检查是否可以移动
        if (!this._canMove || !this.camera) {
            return;
        }

        // 保持UI节点不旋转
        this.node.setWorldRotation(this.QuatZero);

        // 获取目标节点的世界坐标（只访问一次，避免重复计算）
        const wPos = this._target.worldPosition;
        const camera = this._camera;
        camera.camera.update();// 确保相机更新，否则转换坐标会出错
        // 将3D世界坐标转换为UI坐标
        camera.convertToUINode(wPos, this.node.parent!, this._transformPos);
        // 根据缓动时间对位置进行平滑插值（0.1秒内到达目标）
        if (this.smoothTime > 0) {
            /** 本帧插值系数（基于缓动时间） */
            const t = Math.min(1, dt / this.smoothTime);
            Vec3.lerp(this._smoothPos, this.node.position, this._transformPos, t);
            this.node.setPosition(this._smoothPos);
        } else {
            this.node.setPosition(this._transformPos);
        }

        // 根据距离缩放UI节点
        if (this._useScale && this.followScale) {
            // 使用已经获取的 wPos，避免再次访问 worldPosition
            Vec3.transformMat4(this._viewPos, wPos, camera.camera.matView);
            const ratio = this._distance / Math.abs(this._viewPos.z);
            this.node.setScale(ratio, ratio, 1);
        }
        // this.node.active = this._target.activeInHierarchy;
    }
    protected _checkCanMove(): void {
        this._canMove = !!(this._camera && this._camera.camera && this._target);
    }
}
