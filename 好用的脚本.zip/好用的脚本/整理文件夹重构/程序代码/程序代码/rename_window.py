"""
重命名窗口模块
批量重命名文件工具
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from utils import FileUtils

class RenameWindow:
    def __init__(self, parent, file_scanner, file_renamer, refresh_callback=None):
        self.parent = parent
        self.file_scanner = file_scanner
        self.file_renamer = file_renamer
        self.refresh_callback = refresh_callback
        
        self.window = tk.Toplevel(parent)
        self.window.title("批量重命名工具")
        self.window.geometry("700x600")
        self.window.transient(parent)
        self.window.grab_set()
        
        FileUtils.center_window(self.window, 700, 600)
        self.create_widgets()
    
    def create_widgets(self):
        """创建重命名界面组件"""
        # 标题
        ttk.Label(self.window,
                 text="📝 批量重命名工具",
                 font=("微软雅黑", 14, "bold")).pack(pady=10)
        
        # 文件选择区域
        select_frame = ttk.LabelFrame(self.window, text="选择要重命名的文件", padding="10")
        select_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # 文件列表
        list_frame = ttk.Frame(select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建列表框
        self.file_list = tk.Listbox(list_frame, 
                                   selectmode=tk.EXTENDED,
                                   font=("Consolas", 9))
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL)
        self.file_list.configure(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.file_list.yview)
        
        # 填充文件列表
        if self.file_scanner.all_files:
            for i, file_info in enumerate(self.file_scanner.all_files[:100]):  # 只显示前100个
                display_name = f"{file_info['name']} ({FileUtils.format_size(file_info['size'])})"
                self.file_list.insert(tk.END, display_name)
        else:
            self.file_list.insert(tk.END, "没有文件，请先扫描文件夹")
        
        self.file_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 全选/取消全选按钮
        select_buttons = ttk.Frame(select_frame)
        select_buttons.pack(fill=tk.X, pady=(5, 0))
        
        ttk.Button(select_buttons,
                  text="全选",
                  command=self.select_all_files,
                  width=10).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(select_buttons,
                  text="取消全选",
                  command=self.deselect_all_files,
                  width=10).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(select_buttons,
                  text="选择图片文件",
                  command=lambda: self.select_by_extension([".jpg", ".png", ".gif"]),
                  width=12).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(select_buttons,
                  text="选择文档文件",
                  command=lambda: self.select_by_extension([".txt", ".doc", ".pdf"]),
                  width=12).pack(side=tk.RIGHT, padx=5)
        
        # 重命名模式选择
        mode_frame = ttk.LabelFrame(self.window, text="重命名模式", padding="10")
        mode_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.rename_mode = tk.StringVar(value="serial")
        
        mode_options = [
            ("批量序号", "serial", "文件(1).jpg, 文件(2).jpg"),
            ("添加前缀", "prefix", "前缀_原文件名.jpg"),
            ("添加后缀", "suffix", "原文件名_后缀.jpg"),
            ("文本替换", "replace", "将A替换为B"),
            ("日期前缀", "date", "YYYY-MM-DD_文件名")
        ]
        
        for i, (text, value, desc) in enumerate(mode_options):
            frame = ttk.Frame(mode_frame)
            frame.pack(fill=tk.X, pady=2)
            
            ttk.Radiobutton(frame,
                           text=text,
                           variable=self.rename_mode,
                           value=value,
                           command=self.on_mode_change).pack(side=tk.LEFT)
            
            ttk.Label(frame, 
                     text=desc,
                     foreground="gray").pack(side=tk.LEFT, padx=(20, 0))
        
        # 参数设置区域
        param_frame = ttk.LabelFrame(self.window, text="参数设置", padding="10")
        param_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.param_container = ttk.Frame(param_frame)
        self.param_container.pack(fill=tk.X)
        
        # 创建不同模式的参数控件
        self.create_parameter_widgets()
        
        # 预览区域
        preview_frame = ttk.LabelFrame(self.window, text="重命名预览", padding="10")
        preview_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.preview_text = scrolledtext.ScrolledText(preview_frame, 
                                                     height=8,
                                                     font=("Consolas", 9))
        self.preview_text.pack(fill=tk.BOTH, expand=True)
        self.preview_text.config(state=tk.DISABLED)
        
        # 按钮区域
        button_frame = ttk.Frame(self.window)
        button_frame.pack(fill=tk.X, padx=10, pady=(5, 10))
        
        ttk.Button(button_frame,
                  text="🔄 更新预览",
                  command=self.update_preview,
                  width=15).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame,
                  text="✅ 执行重命名",
                  command=self.execute_rename,
                  width=15).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame,
                  text="❌ 取消",
                  command=self.window.destroy,
                  width=15).pack(side=tk.RIGHT, padx=5)
    
    def create_parameter_widgets(self):
        """创建参数设置控件"""
        # 清空现有控件
        for widget in self.param_container.winfo_children():
            widget.destroy()
        
        mode = self.rename_mode.get()
        
        if mode == "serial":
            frame = ttk.Frame(self.param_container)
            frame.pack(fill=tk.X)
            
            ttk.Label(frame, text="起始序号:").pack(side=tk.LEFT)
            self.start_num = ttk.Spinbox(frame, from_=1, to=9999, width=8)
            self.start_num.pack(side=tk.LEFT, padx=(5, 20))
            self.start_num.set(1)
            
            ttk.Label(frame, text="位数:").pack(side=tk.LEFT)
            self.digit_count = ttk.Spinbox(frame, from_=1, to=6, width=6)
            self.digit_count.pack(side=tk.LEFT, padx=(5, 0))
            self.digit_count.set(3)
        
        elif mode == "prefix":
            frame = ttk.Frame(self.param_container)
            frame.pack(fill=tk.X)
            
            ttk.Label(frame, text="前缀文字:").pack(side=tk.LEFT)
            self.prefix_text = ttk.Entry(frame, width=20)
            self.prefix_text.pack(side=tk.LEFT, padx=(5, 0))
            self.prefix_text.insert(0, "new_")
        
        elif mode == "suffix":
            frame = ttk.Frame(self.param_container)
            frame.pack(fill=tk.X)
            
            ttk.Label(frame, text="后缀文字:").pack(side=tk.LEFT)
            self.suffix_text = ttk.Entry(frame, width=20)
            self.suffix_text.pack(side=tk.LEFT, padx=(5, 0))
        
        elif mode == "replace":
            frame = ttk.Frame(self.param_container)
            frame.pack(fill=tk.X)
            
            ttk.Label(frame, text="查找:").pack(side=tk.LEFT)
            self.find_text = ttk.Entry(frame, width=15)
            self.find_text.pack(side=tk.LEFT, padx=(5, 10))
            
            ttk.Label(frame, text="替换为:").pack(side=tk.LEFT)
            self.replace_text = ttk.Entry(frame, width=15)
            self.replace_text.pack(side=tk.LEFT, padx=(5, 0))
        
        elif mode == "date":
            # 日期模式不需要额外参数
            frame = ttk.Frame(self.param_container)
            frame.pack(fill=tk.X)
            
            ttk.Label(frame, 
                     text="将添加当前日期作为前缀，格式: YYYY-MM-DD_文件名",
                     foreground="gray").pack()
    
    def on_mode_change(self):
        """重命名模式改变事件"""
        self.create_parameter_widgets()
        self.update_preview()
    
    def select_all_files(self):
        """选择所有文件"""
        self.file_list.selection_set(0, tk.END)
    
    def deselect_all_files(self):
        """取消选择所有文件"""
        self.file_list.selection_clear(0, tk.END)
    
    def select_by_extension(self, extensions):
        """按扩展名选择文件"""
        self.deselect_all_files()
        
        for i in range(self.file_list.size()):
            item_text = self.file_list.get(i)
            for ext in extensions:
                if item_text.lower().endswith(ext):
                    self.file_list.selection_set(i)
                    break
    
    def update_preview(self):
        """更新重命名预览"""
        selected_indices = self.file_list.curselection()
        if not selected_indices:
            return
        
        self.preview_text.config(state=tk.NORMAL)
        self.preview_text.delete("1.0", tk.END)
        
        mode = self.rename_mode.get()
        params = self.get_current_params()
        
        preview_text = "📋 重命名预览\n"
        preview_text += "=" * 50 + "\n\n"
        
        for i, idx in enumerate(selected_indices[:10]):  # 只显示前10个预览
            display_text = self.file_list.get(idx)
            if " (" in display_text:
                original_name = display_text.split(" (")[0]
            else:
                original_name = display_text
            
            new_name = self.generate_new_filename(original_name, mode, params, i)
            
            preview_text += f"原文件: {original_name}\n"
            preview_text += f"新文件: {new_name}\n"
            preview_text += "-" * 30 + "\n"
        
        if len(selected_indices) > 10:
            preview_text += f"\n... 还有 {len(selected_indices) - 10} 个文件\n"
        
        self.preview_text.insert("1.0", preview_text)
        self.preview_text.config(state=tk.DISABLED)
    
    def get_current_params(self):
        """获取当前参数设置"""
        mode = self.rename_mode.get()
        params = {}
        
        if mode == "serial":
            try:
                params["start"] = int(self.start_num.get())
                params["digits"] = int(self.digit_count.get())
            except:
                params["start"] = 1
                params["digits"] = 3
        
        elif mode == "prefix":
            params["prefix"] = self.prefix_text.get()
        
        elif mode == "suffix":
            params["suffix"] = self.suffix_text.get()
        
        elif mode == "replace":
            params["find"] = self.find_text.get()
            params["replace"] = self.replace_text.get()
        
        return params
    
    def generate_new_filename(self, original_name, mode, params, index):
        """生成新的文件名"""
        import os
        
        name, ext = os.path.splitext(original_name)
        
        if mode == "serial":
            start = params.get("start", 1)
            digits = params.get("digits", 3)
            return f"{name}({str(start + index).zfill(digits)}){ext}"
        
        elif mode == "prefix":
            prefix = params.get("prefix", "")
            return f"{prefix}{original_name}"
        
        elif mode == "suffix":
            suffix = params.get("suffix", "")
            return f"{name}{suffix}{ext}"
        
        elif mode == "replace":
            find_text = params.get("find", "")
            replace_text = params.get("replace", "")
            new_name = original_name.replace(find_text, replace_text)
            return new_name
        
        elif mode == "date":
            from datetime import datetime
            date_str = datetime.now().strftime("%Y-%m-%d")
            return f"{date_str}_{original_name}"
        
        return original_name
    
    def execute_rename(self):
        """执行重命名"""
        selected_indices = self.file_list.curselection()
        if not selected_indices:
            messagebox.showinfo("提示", "请先选择要重命名的文件")
            return
        
        if not messagebox.askyesno("确认", f"确定要重命名 {len(selected_indices)} 个文件吗？"):
            return
        
        mode = self.rename_mode.get()
        params = self.get_current_params()
        
        # 执行重命名
        result = self.file_renamer.rename_files(
            list(selected_indices),
            mode,
            params,
            preview_mode=False
        )
        
        if "error" in result:
            messagebox.showerror("错误", result["error"])
            return
        
        success_count = result["success_count"]
        error_count = result["error_count"]
        
        if error_count == 0:
            messagebox.showinfo("成功", f"重命名完成！成功 {success_count} 个文件。")
        else:
            messagebox.showwarning("部分完成", 
                                 f"重命名完成！成功 {success_count} 个，失败 {error_count} 个。")
        
        # 关闭窗口并刷新
        self.window.destroy()
        if self.refresh_callback:
            self.refresh_callback()