"""
文件整理模块
负责文件的整理、移动操作
"""

import os
import shutil
from datetime import datetime
from utils import FileUtils

class FileOrganizer:
    def __init__(self, scanner, config_manager, backup_manager=None):
        self.scanner = scanner
        self.config_manager = config_manager
        self.backup_manager = backup_manager
        self.operations_log = []
    
    def set_backup_manager(self, backup_manager):
        """设置备份管理器"""
        self.backup_manager = backup_manager
    
    def organize_by_type(self, preview_mode=True):
        """按文件类型整理"""
        return self._organize_files("type", preview_mode)
    
    def organize_by_size(self, preview_mode=True):
        """按文件大小整理"""
        return self._organize_files("size", preview_mode)
    
    def organize_by_time(self, preview_mode=True):
        """按修改时间整理"""
        return self._organize_files("time", preview_mode)
    
    def _organize_files(self, mode, preview_mode):
        """整理文件的核心函数"""
        if not self.scanner.all_files:
            return {"error": "没有可整理的文件"}
        
        operation_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        operation = {
            "id": operation_id,
            "time": datetime.now(),
            "mode": mode,
            "files": []
        }
        
        preview = []
        success_count = 0
        
        for file_info in self.scanner.all_files:
            try:
                # 确定目标文件夹
                if mode == "type":
                    dest_folder = file_info["type"]
                elif mode == "size":
                    dest_folder = file_info["size_category"]
                else:  # time
                    dest_folder = file_info["time_category"]
                
                # 创建目标路径
                dest_path = os.path.join(self.scanner.current_folder, dest_folder)
                
                if not preview_mode:
                    os.makedirs(dest_path, exist_ok=True)
                
                # 处理目标文件名
                dest_file = os.path.join(dest_path, file_info["name"])
                
                # 处理重名
                new_name = self._handle_duplicate_name(dest_path, file_info["name"])
                if new_name != file_info["name"]:
                    dest_file = os.path.join(dest_path, new_name)
                
                if preview_mode:
                    preview.append({
                        "from": file_info["path"],
                        "to": dest_file,
                        "type": file_info["type"],
                        "size": file_info["size"]
                    })
                else:
                    # 实际移动文件
                    shutil.move(file_info["path"], dest_file)
                    operation["files"].append({
                        "original": file_info["path"],
                        "new": dest_file
                    })
                    success_count += 1
                    
            except Exception as e:
                if not preview_mode:
                    print(f"移动文件失败 {file_info['name']}: {e}")
        
        if not preview_mode:
            self.operations_log.append(operation)
            
            # 持久化操作历史
            if self.backup_manager:
                self.backup_manager.record_operation({
                    "type": f"organize_by_{mode}",
                    "folder": self.scanner.current_folder,
                    "details": {"mode": mode},
                    "files_moved": operation["files"]
                })
            
            return {
                "success_count": success_count,
                "total_files": len(self.scanner.all_files),
                "operation_id": operation_id
            }
        else:
            return {"preview": preview}
    
    def _handle_duplicate_name(self, folder_path, filename):
        """处理重名文件"""
        name, ext = os.path.splitext(filename)
        new_name = filename
        counter = 1
        
        while os.path.exists(os.path.join(folder_path, new_name)):
            new_name = f"{name}({counter}){ext}"
            counter += 1
        
        return new_name
    
    def undo_last_operation(self):
        """撤销上次操作"""
        if not self.operations_log:
            return {"error": "没有可撤销的操作"}
        
        last_op = self.operations_log[-1]
        success_count = 0
        error_count = 0
        
        for file_move in reversed(last_op["files"]):
            try:
                # 将文件移回原位置
                shutil.move(file_move["new"], file_move["original"])
                success_count += 1
                
                # 删除可能为空的文件夹
                dest_folder = os.path.dirname(file_move["new"])
                if os.path.exists(dest_folder) and not os.listdir(dest_folder):
                    os.rmdir(dest_folder)
                    
            except Exception as e:
                error_count += 1
                print(f"撤销失败: {e}")
        
        # 移除操作记录
        self.operations_log.pop()
        
        return {
            "success_count": success_count,
            "error_count": error_count,
            "operation_id": last_op["id"]
        }