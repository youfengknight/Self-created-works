"""
统计窗口模块
提供数据统计和可视化的图形界面
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import os

class StatsWindow:
    def __init__(self, parent, scanner, visualizer):
        self.parent = parent
        self.scanner = scanner
        self.visualizer = visualizer
        
        self.window = tk.Toplevel(parent)
        self.window.title("数据统计与分析")
        self.window.geometry("1000x700")
        self.window.transient(parent)
        self.window.grab_set()
        
        from utils import FileUtils
        FileUtils.center_window(self.window, 1000, 700)
        
        self.create_widgets()
        self.update_stats()
    
    def create_widgets(self):
        """创建界面组件"""
        main_frame = ttk.Frame(self.window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(title_frame, 
                 text="📊 数据统计与分析",
                 font=("微软雅黑", 16, "bold")).pack(side=tk.LEFT)
        
        export_frame = ttk.Frame(title_frame)
        export_frame.pack(side=tk.RIGHT)
        
        ttk.Button(export_frame,
                  text="📄 导出Excel",
                  command=self.export_excel,
                  width=12).pack(side=tk.LEFT, padx=2)
        
        ttk.Button(export_frame,
                  text="📝 导出TXT",
                  command=self.export_text,
                  width=12).pack(side=tk.LEFT, padx=2)
        
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        overview_frame = ttk.Frame(notebook)
        notebook.add(overview_frame, text="📈 概览统计")
        self.create_overview_tab(overview_frame)
        
        charts_frame = ttk.Frame(notebook)
        notebook.add(charts_frame, text="📊 图表分析")
        self.create_charts_tab(charts_frame)
        
        details_frame = ttk.Frame(notebook)
        notebook.add(details_frame, text="📋 详细信息")
        self.create_details_tab(details_frame)
        
        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(bottom_frame,
                  text="🔄 刷新统计",
                  command=self.update_stats,
                  width=15).pack(side=tk.LEFT)
        
        ttk.Button(bottom_frame,
                  text="关闭",
                  command=self.window.destroy,
                  width=15).pack(side=tk.RIGHT)
    
    def create_overview_tab(self, parent):
        """创建概览标签页"""
        stats_frame = ttk.LabelFrame(parent, text="统计概览", padding="10")
        stats_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.overview_text = tk.Text(stats_frame, font=("Consolas", 11), wrap=tk.WORD)
        self.overview_text.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(stats_frame, orient=tk.VERTICAL, command=self.overview_text.yview)
        self.overview_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def create_charts_tab(self, parent):
        """创建图表标签页"""
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        type_chart_frame = ttk.Frame(notebook)
        notebook.add(type_chart_frame, text="类型分布")
        self.create_chart_container(type_chart_frame, "type")
        
        size_chart_frame = ttk.Frame(notebook)
        notebook.add(size_chart_frame, text="大小分布")
        self.create_chart_container(size_chart_frame, "size")
        
        time_chart_frame = ttk.Frame(notebook)
        notebook.add(time_chart_frame, text="时间趋势")
        self.create_chart_container(time_chart_frame, "time")
    
    def create_chart_container(self, parent, chart_type):
        """创建图表容器"""
        chart_frame = ttk.Frame(parent)
        chart_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        if chart_type == "type":
            self.visualizer.generate_type_distribution_chart(chart_frame)
        elif chart_type == "size":
            self.visualizer.generate_size_distribution_chart(chart_frame)
        else:
            self.visualizer.generate_time_trend_chart(chart_frame)
    
    def create_details_tab(self, parent):
        """创建详细信息标签页"""
        details_frame = ttk.Frame(parent)
        details_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        columns = ("类型", "文件数", "总大小", "平均大小", "占比")
        self.details_tree = ttk.Treeview(details_frame, columns=columns, show="headings")
        
        for col in columns:
            self.details_tree.heading(col, text=col)
            self.details_tree.column(col, width=100)
        
        self.details_tree.column("总大小", width=120)
        self.details_tree.column("平均大小", width=120)
        
        scrollbar = ttk.Scrollbar(details_frame, orient=tk.VERTICAL, command=self.details_tree.yview)
        self.details_tree.configure(yscrollcommand=scrollbar.set)
        
        self.details_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def update_stats(self):
        """更新统计信息"""
        stats = self.visualizer.get_detailed_stats()
        type_stats = self.scanner.type_stats
        
        if not stats:
            self.overview_text.insert(tk.END, "暂无扫描数据，请先扫描文件夹")
            self.overview_text.config(state=tk.DISABLED)
            return
        
        overview_text = []
        overview_text.append("=" * 60)
        overview_text.append("        文件夹文件整理工具 - 统计报告")
        overview_text.append("=" * 60)
        overview_text.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        overview_text.append("")
        
        overview_text.append("【总体统计】")
        overview_text.append(f"  📁 总文件夹: 1")
        overview_text.append(f"  📄 总文件数: {stats['total_files']}")
        overview_text.append(f"  💾 总大小: {stats['total_size'] / (1024*1024):.2f} MB")
        overview_text.append(f"  🏷️ 文件类型: {stats['type_count']} 种")
        overview_text.append("")
        
        overview_text.append("【按大小分类】")
        size_stats = stats.get('size_stats', {})
        for cat, data in sorted(size_stats.items()):
            avg_size = data['size'] / data['count'] if data['count'] > 0 else 0
            overview_text.append(f"  • {cat}: {data['count']} 个")
            overview_text.append(f"    总大小: {data['size'] / (1024*1024):.2f} MB")
        
        overview_text.append("")
        
        overview_text.append("【按时间分类】")
        time_stats = stats.get('time_stats', {})
        for cat, data in sorted(time_stats.items()):
            avg_size = data['size'] / data['count'] if data['count'] > 0 else 0
            overview_text.append(f"  • {cat}: {data['count']} 个")
            overview_text.append(f"    总大小: {data['size'] / (1024*1024):.2f} MB")
        
        overview_text.append("")
        overview_text.append("=" * 60)
        
        self.overview_text.config(state=tk.NORMAL)
        self.overview_text.delete("1.0", tk.END)
        self.overview_text.insert(tk.END, '\n'.join(overview_text))
        self.overview_text.config(state=tk.DISABLED)
        
        self.update_details_tree()
    
    def update_details_tree(self):
        """更新详细信息表格"""
        for item in self.details_tree.get_children():
            self.details_tree.delete(item)
        
        type_stats = self.scanner.type_stats
        total_files = sum(s["count"] for s in type_stats.values())
        
        for file_type, stat in sorted(type_stats.items(), key=lambda x: x[1]["count"], reverse=True):
            count = stat["count"]
            size = stat["size"]
            avg_size = size / count if count > 0 else 0
            percentage = (count / total_files * 100) if total_files > 0 else 0
            
            self.details_tree.insert("", "end", values=(
                file_type,
                count,
                f"{size / (1024*1024):.2f} MB",
                f"{avg_size / (1024):.2f} KB",
                f"{percentage:.1f}%"
            ))
    
    def export_excel(self):
        """导出Excel报告"""
        filepath = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            initialfile=f"统计报告_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        )
        
        if filepath:
            success, message = self.visualizer.export_stats_to_excel(filepath)
            if success:
                messagebox.showinfo("成功", message)
            else:
                messagebox.showerror("错误", message)
    
    def export_text(self):
        """导出TXT报告"""
        filepath = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            initialfile=f"统计报告_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        )
        
        if filepath:
            success, message = self.visualizer.export_stats_to_text(filepath)
            if success:
                messagebox.showinfo("成功", message)
            else:
                messagebox.showerror("错误", message)