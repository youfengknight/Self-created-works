"""
工具函数模块
提供各种辅助功能
"""

import os
from datetime import datetime

class FileUtils:
    @staticmethod
    def format_size(size_bytes):
        """格式化文件大小"""
        if size_bytes == 0:
            return "0 B"
        
        size_names = ("B", "KB", "MB", "GB", "TB")
        i = 0
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024
            i += 1
        
        return f"{size_bytes:.2f} {size_names[i]}"
    
    @staticmethod
    def get_file_type(file_path, config_manager):
        """根据扩展名获取文件类型"""
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        
        all_types = config_manager.get_all_file_types()
        for file_type, exts in all_types.items():
            if ext in exts:
                return file_type
        return "其他文件"
    
    @staticmethod
    def get_size_category(size_bytes):
        """获取文件大小分类"""
        if size_bytes < 1024 * 1024:  # < 1MB
            return "小文件(<1MB)"
        elif size_bytes < 10 * 1024 * 1024:  # 1-10MB
            return "中文件(1-10MB)"
        else:  # > 10MB
            return "大文件(>10MB)"
    
    @staticmethod
    def get_time_category(mtime):
        """获取文件时间分类"""
        file_time = datetime.fromtimestamp(mtime)
        now = datetime.now()
        time_diff = now - file_time
        
        if time_diff.days == 0:
            return "今天"
        elif time_diff.days <= 7:
            return "本周"
        elif time_diff.days <= 30:
            return "本月"
        else:
            return "更早"
    
    @staticmethod
    def center_window(window, width, height):
        """窗口居中显示"""
        window.update_idletasks()
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        window.geometry(f'{width}x{height}+{x}+{y}')