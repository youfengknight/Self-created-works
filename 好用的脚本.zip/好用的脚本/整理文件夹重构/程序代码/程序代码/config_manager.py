"""
配置管理模块
处理文件类型配置、用户设置的加载和保存
"""

import os
import json
from pathlib import Path

class ConfigManager:
    def __init__(self):
        self.config_file = "file_types_config.json"
        self.default_types = self.get_default_file_types()
        self.custom_types = self.load_custom_types()
    
    def get_default_file_types(self):
        """获取默认文件类型分类"""
        return {
            "图片": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".svg"],
            "文档": [".txt", ".doc", ".docx", ".pdf", ".xls", ".xlsx", ".ppt", ".pptx", ".md", ".rtf"],
            "视频": [".mp4", ".avi", ".mov", ".wmv", ".flv", ".mkv", ".mpeg", ".mpg", ".webm"],
            "音频": [".mp3", ".wav", ".flac", ".aac", ".wma", ".ogg", ".m4a"],
            "压缩包": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz"],
            "程序代码": [".py", ".java", ".cpp", ".c", ".js", ".html", ".css", ".php", ".json", ".xml"],
            "可执行文件": [".exe", ".msi", ".bat", ".cmd", ".sh"],
            "配置文件": [".ini", ".cfg", ".conf", ".yml", ".yaml", ".toml"],
            "字体文件": [".ttf", ".otf", ".woff", ".woff2"],
            "数据文件": [".csv", ".tsv", ".db", ".sqlite", ".jsonl"],
        }
    
    def load_custom_types(self):
        """加载自定义文件类型"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def save_custom_types(self):
        """保存自定义文件类型"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.custom_types, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置失败: {e}")
            return False
    
    def get_all_file_types(self):
        """获取所有文件类型（默认+自定义）"""
        all_types = self.default_types.copy()
        all_types.update(self.custom_types)
        return all_types
    
    def add_custom_type(self, type_name, extensions):
        """添加自定义文件类型"""
        self.custom_types[type_name] = extensions
        return self.save_custom_types()
    
    def delete_custom_type(self, type_name):
        """删除自定义文件类型"""
        if type_name in self.custom_types:
            del self.custom_types[type_name]
            return self.save_custom_types()
        return False