"""
文件重命名模块
负责批量重命名文件
"""

import os
from datetime import datetime
from utils import FileUtils

class FileRenamer:
    def __init__(self, scanner):
        self.scanner = scanner
        self.rename_history = []
    
    def rename_files(self, file_indices, mode, params, preview_mode=True):
        """重命名文件"""
        if not self.scanner.all_files:
            return {"error": "没有可重命名的文件"}
        
        preview = []
        rename_plan = []
        
        for i, idx in enumerate(file_indices):
            if idx >= len(self.scanner.all_files):
                continue
            
            file_info = self.scanner.all_files[idx]
            original_name = file_info["name"]
            
            # 生成新文件名
            new_name = self._generate_new_filename(original_name, mode, params, i)
            
            # 处理重名
            final_name = self._handle_duplicate_rename(
                os.path.dirname(file_info["path"]),
                new_name
            )
            
            if preview_mode:
                preview.append({
                    "original": original_name,
                    "new": final_name,
                    "path": file_info["path"]
                })
            else:
                rename_plan.append({
                    "original_path": file_info["path"],
                    "new_path": os.path.join(os.path.dirname(file_info["path"]), final_name)
                })
        
        if preview_mode:
            return {"preview": preview}
        else:
            return self._execute_rename(rename_plan)
    
    def _generate_new_filename(self, original_name, mode, params, index):
        """生成新的文件名"""
        name, ext = os.path.splitext(original_name)
        
        if mode == "serial":
            start = params.get("start", 1)
            digits = params.get("digits", 3)
            return f"{name}({str(start + index).zfill(digits)}){ext}"
        
        elif mode == "prefix":
            prefix = params.get("prefix", "")
            return f"{prefix}{original_name}"
        
        elif mode == "suffix":
            suffix = params.get("suffix", "")
            return f"{name}{suffix}{ext}"
        
        elif mode == "replace":
            find_text = params.get("find", "")
            replace_text = params.get("replace", "")
            new_name = original_name.replace(find_text, replace_text)
            return new_name
        
        elif mode == "date":
            date_str = datetime.now().strftime("%Y-%m-%d")
            return f"{date_str}_{original_name}"
        
        return original_name
    
    def _handle_duplicate_rename(self, folder_path, filename):
        """处理重命名时的重名问题"""
        name, ext = os.path.splitext(filename)
        new_name = filename
        counter = 1
        
        while os.path.exists(os.path.join(folder_path, new_name)):
            new_name = f"{name}({counter}){ext}"
            counter += 1
        
        return new_name
    
    def _execute_rename(self, rename_plan):
        """执行重命名操作"""
        success_count = 0
        error_count = 0
        renamed_files = []
        
        for rename_item in rename_plan:
            try:
                os.rename(rename_item["original_path"], rename_item["new_path"])
                success_count += 1
                renamed_files.append(rename_item)
            except Exception as e:
                error_count += 1
                print(f"重命名失败: {e}")
        
        # 记录操作历史
        if renamed_files:
            self.rename_history.append({
                "time": datetime.now(),
                "files": renamed_files
            })
        
        return {
            "success_count": success_count,
            "error_count": error_count,
            "renamed_files": len(renamed_files)
        }