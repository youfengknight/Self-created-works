"""
文件扫描模块
负责扫描文件夹、分析文件信息
"""

import os
import threading
from datetime import datetime
from collections import defaultdict
from utils import FileUtils

class FileScanner:
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.current_folder = ""
        self.all_files = []
        self.type_stats = {}
        self.scanning = False
    
    def scan_folder(self, folder_path, callback=None):
        """扫描指定文件夹"""
        if not folder_path or self.scanning:
            return False
        
        self.current_folder = folder_path
        self.scanning = True
        
        # 在新线程中扫描
        scan_thread = threading.Thread(
            target=self._scan_folder_thread,
            args=(folder_path, callback)
        )
        scan_thread.daemon = True
        scan_thread.start()
        
        return True
    
    def _scan_folder_thread(self, folder_path, callback):
        """扫描文件夹的线程函数"""
        try:
            start_time = datetime.now()
            
            all_files = []
            type_stats = defaultdict(lambda: {"count": 0, "size": 0})
            total_size = 0
            
            for root_dir, dirs, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(root_dir, file)
                    
                    try:
                        # 获取文件信息
                        size = os.path.getsize(file_path)
                        total_size += size
                        
                        # 按扩展名分类
                        file_type = FileUtils.get_file_type(file_path, self.config_manager)
                        
                        type_stats[file_type]["count"] += 1
                        type_stats[file_type]["size"] += size
                        
                        # 获取其他信息
                        mtime = os.path.getmtime(file_path)
                        size_category = FileUtils.get_size_category(size)
                        time_category = FileUtils.get_time_category(mtime)
                        
                        all_files.append({
                            "path": file_path,
                            "name": file,
                            "size": size,
                            "type": file_type,
                            "size_category": size_category,
                            "time_category": time_category,
                            "mtime": mtime
                        })
                        
                    except (OSError, PermissionError):
                        continue
            
            # 保存结果
            self.all_files = all_files
            self.type_stats = dict(type_stats)
            
            scan_time = datetime.now() - start_time
            
            # 调用回调函数（在主线程中更新UI）
            if callback:
                callback({
                    "files": all_files,
                    "type_stats": dict(type_stats),
                    "total_size": total_size,
                    "scan_time": scan_time
                })
            
            self.scanning = False
            return True
            
        except Exception as e:
            self.scanning = False
            if callback:
                callback({"error": str(e)})
            return False
    
    def get_file_info(self):
        """获取文件信息摘要"""
        if not self.all_files:
            return {}
        
        total_files = len(self.all_files)
        total_size = sum(f["size"] for f in self.all_files)
        
        return {
            "total_files": total_files,
            "total_size": total_size,
            "type_count": len(self.type_stats)
        }
    
    def get_files_by_type(self, file_type):
        """获取指定类型的文件"""
        return [f for f in self.all_files if f["type"] == file_type]
    
    def get_files_by_extension(self, extension):
        """获取指定扩展名的文件"""
        extension = extension.lower()
        return [f for f in self.all_files if f["name"].lower().endswith(extension)]