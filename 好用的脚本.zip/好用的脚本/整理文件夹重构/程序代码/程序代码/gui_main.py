"""
主界面GUI模块
程序的主要用户界面
"""

import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import threading
from datetime import datetime

# 导入自定义模块
from config_manager import ConfigManager
from file_scanner import FileScanner
from file_organizer import FileOrganizer
from file_renamer import FileRenamer
from backup_manager import BackupManager
from utils import FileUtils

class FileOrganizerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("文件夹文件整理工具 v2.0")
        self.root.geometry("900x700")
        
        # 设置图标
        try:
            self.root.iconbitmap(default='icon.ico')
        except:
            pass
        
        # 初始化管理器
        self.config_manager = ConfigManager()
        self.backup_manager = BackupManager()
        self.file_scanner = FileScanner(self.config_manager)
        self.file_organizer = FileOrganizer(self.file_scanner, self.config_manager, self.backup_manager)
        self.file_renamer = FileRenamer(self.file_scanner)
        self.backup_manager = BackupManager()
        
        # 居中显示
        FileUtils.center_window(self.root, 900, 700)
        
        # 创建界面
        self.create_widgets()
        
        # 初始状态 - 自动扫描当前文件夹
        self.current_folder = os.path.dirname(os.path.abspath(__file__))
        self.folder_label.config(text=self.current_folder)
        self.start_scan()
        
        self.update_status("就绪 - 正在扫描当前文件夹...")
    
    def create_widgets(self):
        """创建界面组件"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题栏
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(title_frame, 
                 text="📁 文件夹文件整理工具 v2.0",
                 font=("微软雅黑", 16, "bold")).pack(side=tk.LEFT)
        
        # 工具按钮
        tool_buttons = ttk.Frame(title_frame)
        tool_buttons.pack(side=tk.RIGHT)
        
        ttk.Button(tool_buttons,
                  text="⚙️ 设置",
                  command=self.open_settings,
                  width=8).pack(side=tk.LEFT, padx=2)
        
        ttk.Button(tool_buttons,
                  text="📊 统计",
                  command=self.open_stats,
                  width=8).pack(side=tk.LEFT, padx=2)
        
        ttk.Button(tool_buttons,
                  text="💾 备份",
                  command=self.open_backup,
                  width=8).pack(side=tk.LEFT, padx=2)
        
        ttk.Button(tool_buttons,
                  text="📝 重命名",
                  command=self.open_rename_tool,
                  width=8).pack(side=tk.LEFT, padx=2)
        
        # 文件夹选择区域
        folder_frame = ttk.LabelFrame(main_frame, text="文件夹选择", padding="10")
        folder_frame.pack(fill=tk.X, pady=(0, 10))
        
        folder_select_frame = ttk.Frame(folder_frame)
        folder_select_frame.pack(fill=tk.X)
        
        ttk.Button(folder_select_frame,
                  text="📂 选择文件夹",
                  command=self.select_folder,
                  width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        self.folder_label = ttk.Label(folder_select_frame, 
                                     text="未选择文件夹",
                                     foreground="gray")
        self.folder_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Button(folder_select_frame,
                  text="🔄 重新扫描",
                  command=self.start_scan,
                  width=10).pack(side=tk.RIGHT)
        
        # 文件统计区域
        stats_frame = ttk.LabelFrame(main_frame, text="文件统计概览", padding="10")
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        stats_grid = ttk.Frame(stats_frame)
        stats_grid.pack(fill=tk.X)
        
        # 第一行统计
        row1 = ttk.Frame(stats_grid)
        row1.pack(fill=tk.X, pady=5)
        
        self.total_files_label = ttk.Label(row1, 
                                          text="文件总数: --",
                                          font=("微软雅黑", 11))
        self.total_files_label.pack(side=tk.LEFT, padx=(0, 30))
        
        self.total_size_label = ttk.Label(row1,
                                         text="总大小: --",
                                         font=("微软雅黑", 11))
        self.total_size_label.pack(side=tk.LEFT, padx=(0, 30))
        
        # 第二行统计
        row2 = ttk.Frame(stats_grid)
        row2.pack(fill=tk.X, pady=5)
        
        self.file_types_label = ttk.Label(row2,
                                         text="文件类型: --",
                                         font=("微软雅黑", 11))
        self.file_types_label.pack(side=tk.LEFT, padx=(0, 30))
        
        self.scan_time_label = ttk.Label(row2,
                                        text="扫描时间: --",
                                        font=("微软雅黑", 11))
        self.scan_time_label.pack(side=tk.LEFT)
        
        # 文件类型分布区域
        types_frame = ttk.LabelFrame(main_frame, text="文件类型分布", padding="10")
        types_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 创建Treeview显示文件类型
        columns = ("类型", "文件数", "总大小", "占比")
        self.tree = ttk.Treeview(types_frame, columns=columns, show="headings", height=10)
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        
        self.tree.column("类型", width=150)
        self.tree.column("占比", width=80)
        
        # 添加滚动条
        tree_scroll = ttk.Scrollbar(types_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_scroll.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 整理选项区域
        organize_frame = ttk.LabelFrame(main_frame, text="整理选项", padding="10")
        organize_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 整理模式选择
        mode_frame = ttk.Frame(organize_frame)
        mode_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(mode_frame, text="整理模式:").pack(side=tk.LEFT)
        
        self.org_mode = tk.StringVar(value="type")
        
        ttk.Radiobutton(mode_frame, 
                       text="按文件类型整理",
                       variable=self.org_mode,
                       value="type").pack(side=tk.LEFT, padx=(20, 10))
        
        ttk.Radiobutton(mode_frame,
                       text="按文件大小整理",
                       variable=self.org_mode,
                       value="size").pack(side=tk.LEFT, padx=10)
        
        ttk.Radiobutton(mode_frame,
                       text="按修改时间整理",
                       variable=self.org_mode,
                       value="time").pack(side=tk.LEFT, padx=10)
        
        # 整理按钮
        button_frame = ttk.Frame(organize_frame)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame,
                  text="👁️ 预览整理效果",
                  command=self.preview_organize,
                  width=20).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame,
                  text="🚀 执行整理",
                  command=self.execute_organize,
                  width=20).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame,
                  text="🔄 撤销上次操作",
                  command=self.undo_operation,
                  width=15).pack(side=tk.LEFT)
        
        # 操作日志区域
        log_frame = ttk.LabelFrame(main_frame, text="操作日志", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(log_frame,
                                                 height=8,
                                                 font=("Consolas", 9),
                                                 wrap=tk.WORD)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.config(state=tk.DISABLED)
        
        # 状态栏
        self.status_bar = ttk.Label(self.root, 
                                   text="就绪",
                                   relief=tk.SUNKEN,
                                   anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def select_folder(self):
        """选择文件夹"""
        folder = filedialog.askdirectory(title="选择要整理的文件夹")
        if folder:
            self.current_folder = folder
            self.folder_label.config(text=folder)
            self.start_scan()
    
    def start_scan(self):
        """开始扫描文件夹"""
        if not self.current_folder:
            messagebox.showwarning("提示", "请先选择文件夹")
            return
        
        self.update_status("正在扫描文件夹...")
        self.log_message(f"开始扫描文件夹: {self.current_folder}")
        
        # 清空现有数据
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # 开始扫描
        self.file_scanner.scan_folder(self.current_folder, self.on_scan_complete)
    
    def on_scan_complete(self, result):
        """扫描完成回调"""
        if "error" in result:
            self.update_status("扫描失败")
            messagebox.showerror("扫描错误", f"扫描文件夹时出错:\n{result['error']}")
            self.log_message(f"扫描错误: {result['error']}")
            return
        
        # 更新统计信息
        files = result["files"]
        type_stats = result["type_stats"]
        total_size = result["total_size"]
        scan_time = result["scan_time"]
        
        self.total_files_label.config(text=f"文件总数: {len(files)}")
        self.total_size_label.config(text=f"总大小: {FileUtils.format_size(total_size)}")
        self.file_types_label.config(text=f"文件类型: {len(type_stats)}种")
        self.scan_time_label.config(text=f"扫描时间: {scan_time.total_seconds():.2f}秒")
        
        # 更新文件类型表格
        total_files = len(files)
        for file_type, stats in sorted(type_stats.items(), key=lambda x: x[1]["count"], reverse=True):
            count = stats["count"]
            size = stats["size"]
            percentage = (count / total_files * 100) if total_files > 0 else 0
            
            self.tree.insert("", "end", values=(
                file_type,
                f"{count}",
                FileUtils.format_size(size),
                f"{percentage:.1f}%"
            ))
        
        # 更新状态
        self.update_status(f"扫描完成，共发现 {len(files)} 个文件")
        self.log_message(f"扫描完成: 发现 {len(files)} 个文件，{len(type_stats)} 种类型")
    
    def preview_organize(self):
        """预览整理效果"""
        mode = self.org_mode.get()
        
        if mode == "type":
            result = self.file_organizer.organize_by_type(preview_mode=True)
        elif mode == "size":
            result = self.file_organizer.organize_by_size(preview_mode=True)
        else:  # time
            result = self.file_organizer.organize_by_time(preview_mode=True)
        
        if "error" in result:
            messagebox.showinfo("提示", result["error"])
            return
        
        # 显示预览窗口
        preview_window = tk.Toplevel(self.root)
        preview_window.title("整理预览")
        preview_window.geometry("600x500")
        FileUtils.center_window(preview_window, 600, 500)
        
        text_widget = scrolledtext.ScrolledText(preview_window, wrap=tk.WORD)
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        preview_text = self._generate_preview_text(result["preview"], mode)
        text_widget.insert(tk.END, preview_text)
        text_widget.config(state=tk.DISABLED)
        
        ttk.Button(preview_window,
                  text="关闭",
                  command=preview_window.destroy).pack(pady=10)
    
    def _generate_preview_text(self, preview, mode):
        """生成预览文本"""
        if mode == "type":
            title = "📁 按文件类型整理预览\n"
        elif mode == "size":
            title = "📁 按文件大小整理预览\n"
        else:
            title = "📁 按修改时间整理预览\n"
        
        preview_text = title + "=" * 50 + "\n\n"
        
        # 按目标文件夹分组
        groups = {}
        for item in preview:
            dest_folder = os.path.dirname(item["to"]).split(os.sep)[-1]
            if dest_folder not in groups:
                groups[dest_folder] = []
            groups[dest_folder].append(item)
        
        for folder, items in groups.items():
            preview_text += f"📂 {folder}/\n"
            preview_text += f"   └── 将移动 {len(items)} 个文件\n\n"
        
        preview_text += "\n📝 操作摘要:\n"
        preview_text += f"• 将创建 {len(groups)} 个分类文件夹\n"
        preview_text += f"• 将整理 {len(preview)} 个文件\n"
        preview_text += "• 原文件夹结构将被打平\n"
        
        return preview_text
    
    def execute_organize(self):
        """执行整理"""
        mode = self.org_mode.get()
        
        if not messagebox.askyesno("确认", "确定要执行整理操作吗？建议先预览效果。"):
            return
        
        # 自动备份
        self.log_message("正在创建备份...")
        backup_result = self.backup_manager.create_backup(self.current_folder, f"organize_{mode}")
        
        if backup_result["success"]:
            self.log_message(backup_result["message"])
        else:
            self.log_message(f"警告: {backup_result.get('error', '备份失败')}")
        
        if mode == "type":
            result = self.file_organizer.organize_by_type(preview_mode=False)
        elif mode == "size":
            result = self.file_organizer.organize_by_size(preview_mode=False)
        else:  # time
            result = self.file_organizer.organize_by_time(preview_mode=False)
        
        if "error" in result:
            messagebox.showerror("错误", result["error"])
            return
        
        success_count = result["success_count"]
        total_files = result["total_files"]
        
        if success_count == total_files:
            messagebox.showinfo("完成", f"整理完成！成功整理 {success_count} 个文件。\n备份已创建，可用于撤销。")
        else:
            messagebox.showwarning("部分完成", 
                                 f"整理完成！成功 {success_count} 个，失败 {total_files - success_count} 个。\n备份已创建。")
        
        self.log_message(f"整理完成: 成功 {success_count}/{total_files} 个文件")
        
        # 重新扫描显示新状态
        self.start_scan()
    
    def undo_operation(self):
        """撤销上次操作"""
        result = self.file_organizer.undo_last_operation()
        
        if "error" in result:
            messagebox.showinfo("提示", result["error"])
            return
        
        success_count = result["success_count"]
        error_count = result["error_count"]
        
        if error_count == 0:
            messagebox.showinfo("完成", f"撤销操作完成！成功还原 {success_count} 个文件。")
        else:
            messagebox.showwarning("部分完成", 
                                 f"撤销完成！成功 {success_count} 个，失败 {error_count} 个。")
        
        self.log_message(f"撤销操作: 成功 {success_count} 个，失败 {error_count} 个")
        
        # 重新扫描
        self.start_scan()
    
    def open_settings(self):
        """打开设置界面"""
        from settings_window import SettingsWindow
        SettingsWindow(self.root, self.config_manager, self.on_settings_changed)
    
    def open_stats(self):
        """打开统计窗口"""
        from stats_visualizer import StatsVisualizer
        from stats_window import StatsWindow
        visualizer = StatsVisualizer(self.file_scanner)
        StatsWindow(self.root, self.file_scanner, visualizer)
    
    def open_backup(self):
        """打开备份管理窗口"""
        from backup_window import BackupWindow
        BackupWindow(self.root, self.backup_manager, self.file_scanner)
    
    def open_rename_tool(self):
        """打开重命名工具"""
        from rename_window import RenameWindow
        RenameWindow(self.root, self.file_scanner, self.file_renamer, self.start_scan)
    
    def on_settings_changed(self):
        """设置变更回调"""
        self.log_message("文件类型设置已更新")
        # 重新扫描以应用新的文件类型分类
        self.start_scan()
    
    def log_message(self, message):
        """记录日志消息"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
    
    def update_status(self, message):
        """更新状态栏"""
        self.status_bar.config(text=f"状态: {message}")