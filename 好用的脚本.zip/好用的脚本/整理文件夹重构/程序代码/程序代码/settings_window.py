"""
设置窗口模块
文件类型管理和程序设置
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from utils import FileUtils

class SettingsWindow:
    def __init__(self, parent, config_manager, callback=None):
        self.parent = parent
        self.config_manager = config_manager
        self.callback = callback
        
        self.window = tk.Toplevel(parent)
        self.window.title("设置 - 文件类型管理")
        self.window.geometry("700x600")
        self.window.transient(parent)
        self.window.grab_set()
        
        FileUtils.center_window(self.window, 700, 600)
        self.create_widgets()
    
    def create_widgets(self):
        """创建设置界面组件"""
        # 创建笔记本（标签页）
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 标签页1：文件类型管理
        type_frame = ttk.Frame(notebook)
        notebook.add(type_frame, text="📁 文件类型管理")
        
        self.create_type_management_tab(type_frame)
        
        # 标签页2：高级设置
        advanced_frame = ttk.Frame(notebook)
        notebook.add(advanced_frame, text="⚙️ 高级设置")
        
        self.create_advanced_settings_tab(advanced_frame)
        
        # 底部按钮
        bottom_frame = ttk.Frame(self.window)
        bottom_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(bottom_frame,
                  text="恢复默认设置",
                  command=self.reset_to_default,
                  width=15).pack(side=tk.LEFT)
        
        ttk.Button(bottom_frame,
                  text="关闭",
                  command=self.window.destroy,
                  width=15).pack(side=tk.RIGHT)
    
    def create_type_management_tab(self, parent):
        """创建文件类型管理标签页"""
        # 现有类型列表
        list_frame = ttk.LabelFrame(parent, text="现有文件类型", padding="10")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建Treeview显示文件类型
        columns = ("类型名称", "扩展名数量", "扩展名列表")
        self.type_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=12)
        
        for col in columns:
            self.type_tree.heading(col, text=col)
            self.type_tree.column(col, width=100)
        
        self.type_tree.column("类型名称", width=120)
        self.type_tree.column("扩展名列表", width=300)
        
        # 滚动条
        tree_scroll = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.type_tree.yview)
        self.type_tree.configure(yscrollcommand=tree_scroll.set)
        
        self.type_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 更新类型列表
        self.update_type_tree()
        
        # 操作按钮
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(button_frame,
                  text="➕ 添加新类型",
                  command=self.add_file_type,
                  width=15).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame,
                  text="✏️ 编辑选中类型",
                  command=self.edit_file_type,
                  width=15).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame,
                  text="🗑️ 删除选中类型",
                  command=self.delete_file_type,
                  width=15).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(button_frame,
                  text="💾 保存设置",
                  command=self.save_settings,
                  width=15).pack(side=tk.RIGHT, padx=5)
    
    def update_type_tree(self):
        """更新文件类型树形列表"""
        for item in self.type_tree.get_children():
            self.type_tree.delete(item)
        
        all_types = self.config_manager.get_all_file_types()
        
        for type_name, extensions in sorted(all_types.items()):
            ext_count = len(extensions)
            ext_list = ", ".join(extensions[:5])  # 只显示前5个
            if len(extensions) > 5:
                ext_list += f" ...等{ext_count}个"
            
            self.type_tree.insert("", "end", values=(type_name, ext_count, ext_list))
    
    def add_file_type(self):
        """添加新文件类型"""
        add_window = tk.Toplevel(self.window)
        add_window.title("添加新文件类型")
        add_window.geometry("400x300")
        add_window.transient(self.window)
        add_window.grab_set()
        FileUtils.center_window(add_window, 400, 300)
        
        ttk.Label(add_window, 
                 text="添加新文件类型",
                 font=("微软雅黑", 12, "bold")).pack(pady=10)
        
        # 类型名称
        name_frame = ttk.Frame(add_window)
        name_frame.pack(fill=tk.X, padx=20, pady=5)
        
        ttk.Label(name_frame, text="类型名称:").pack(side=tk.LEFT)
        type_name_entry = ttk.Entry(name_frame)
        type_name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(10, 0))
        
        # 扩展名输入
        ext_frame = ttk.LabelFrame(add_window, text="扩展名（用逗号分隔）", padding="10")
        ext_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        ext_text = scrolledtext.ScrolledText(ext_frame, height=6)
        ext_text.pack(fill=tk.BOTH, expand=True)
        
        # 示例
        example_frame = ttk.Frame(add_window)
        example_frame.pack(fill=tk.X, padx=20, pady=5)
        
        ttk.Label(example_frame, 
                 text="示例: .psd, .ai, .fig, .sketch",
                 foreground="gray").pack()
        
        def save_new_type():
            type_name = type_name_entry.get().strip()
            extensions_text = ext_text.get("1.0", tk.END).strip()
            
            if not type_name:
                messagebox.showwarning("输入错误", "请输入类型名称")
                return
            
            # 解析扩展名
            extensions = []
            for ext in extensions_text.split(','):
                ext = ext.strip()
                if ext:
                    if not ext.startswith('.'):
                        ext = '.' + ext
                    extensions.append(ext.lower())
            
            if not extensions:
                messagebox.showwarning("输入错误", "请输入至少一个扩展名")
                return
            
            # 保存到自定义类型
            self.config_manager.add_custom_type(type_name, extensions)
            self.update_type_tree()
            
            messagebox.showinfo("成功", f"已添加新文件类型: {type_name}")
            add_window.destroy()
        
        # 按钮
        button_frame = ttk.Frame(add_window)
        button_frame.pack(fill=tk.X, padx=20, pady=(0, 10))
        
        ttk.Button(button_frame,
                  text="取消",
                  command=add_window.destroy).pack(side=tk.LEFT)
        
        ttk.Button(button_frame,
                  text="保存",
                  command=save_new_type).pack(side=tk.RIGHT)
    
    def edit_file_type(self):
        """编辑现有文件类型"""
        selection = self.type_tree.selection()
        if not selection:
            messagebox.showinfo("提示", "请先选择一个文件类型")
            return
        
        item = self.type_tree.item(selection[0])
        type_name = item["values"][0]
        
        all_types = self.config_manager.get_all_file_types()
        if type_name not in all_types:
            messagebox.showwarning("错误", "无法编辑默认文件类型")
            return
        
        edit_window = tk.Toplevel(self.window)
        edit_window.title("编辑文件类型")
        edit_window.geometry("400x350")
        edit_window.transient(self.window)
        edit_window.grab_set()
        FileUtils.center_window(edit_window, 400, 350)
        
        ttk.Label(edit_window, 
                 text=f"编辑文件类型: {type_name}",
                 font=("微软雅黑", 12, "bold")).pack(pady=10)
        
        # 扩展名输入
        ext_frame = ttk.LabelFrame(edit_window, text="扩展名列表", padding="10")
        ext_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        ext_text = scrolledtext.ScrolledText(ext_frame, height=8)
        ext_text.pack(fill=tk.BOTH, expand=True)
        
        # 加载现有扩展名
        current_exts = all_types[type_name]
        ext_text.insert("1.0", ", ".join(current_exts))
        
        # 添加新扩展名区域
        add_frame = ttk.LabelFrame(edit_window, text="添加新扩展名", padding="10")
        add_frame.pack(fill=tk.X, padx=20, pady=10)
        
        new_ext_entry = ttk.Entry(add_frame)
        new_ext_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        new_ext_entry.insert(0, ".ext")
        
        def add_extension():
            new_ext = new_ext_entry.get().strip()
            if new_ext:
                if not new_ext.startswith('.'):
                    new_ext = '.' + new_ext
                
                # 添加到文本区域
                current_text = ext_text.get("1.0", tk.END).strip()
                if current_text:
                    new_text = current_text + ", " + new_ext.lower()
                else:
                    new_text = new_ext.lower()
                
                ext_text.delete("1.0", tk.END)
                ext_text.insert("1.0", new_text)
                new_ext_entry.delete(0, tk.END)
        
        ttk.Button(add_frame,
                  text="添加",
                  command=add_extension,
                  width=8).pack(side=tk.RIGHT)
        
        def save_edits():
            extensions_text = ext_text.get("1.0", tk.END).strip()
            
            # 解析扩展名
            extensions = []
            for ext in extensions_text.split(','):
                ext = ext.strip()
                if ext:
                    if not ext.startswith('.'):
                        ext = '.' + ext
                    extensions.append(ext.lower())
            
            if not extensions:
                messagebox.showwarning("输入错误", "必须至少有一个扩展名")
                return
            
            # 更新配置
            self.config_manager.add_custom_type(type_name, extensions)
            self.update_type_tree()
            
            messagebox.showinfo("成功", f"已更新文件类型: {type_name}")
            edit_window.destroy()
        
        # 按钮
        button_frame = ttk.Frame(edit_window)
        button_frame.pack(fill=tk.X, padx=20, pady=(0, 10))
        
        ttk.Button(button_frame,
                  text="取消",
                  command=edit_window.destroy).pack(side=tk.LEFT)
        
        ttk.Button(button_frame,
                  text="保存",
                  command=save_edits).pack(side=tk.RIGHT)
    
    def delete_file_type(self):
        """删除文件类型"""
        selection = self.type_tree.selection()
        if not selection:
            messagebox.showinfo("提示", "请先选择一个文件类型")
            return
        
        item = self.type_tree.item(selection[0])
        type_name = item["values"][0]
        
        # 检查是否为默认类型
        if type_name in self.config_manager.default_types:
            messagebox.showwarning("错误", "不能删除默认文件类型")
            return
        
        if messagebox.askyesno("确认", f"确定要删除文件类型 '{type_name}' 吗？"):
            if self.config_manager.delete_custom_type(type_name):
                self.update_type_tree()
                messagebox.showinfo("成功", f"已删除文件类型: {type_name}")
            else:
                messagebox.showerror("错误", "删除失败")
    
    def create_advanced_settings_tab(self, parent):
        """创建高级设置标签页"""
        ttk.Label(parent, 
                 text="整理设置",
                 font=("微软雅黑", 12, "bold")).pack(pady=(20, 10))
        
        # 重名处理策略
        rename_frame = ttk.LabelFrame(parent, text="重名文件处理策略", padding="10")
        rename_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.rename_strategy = tk.StringVar(value="auto_rename")
        
        ttk.Radiobutton(rename_frame,
                       text="自动重命名 (文件(1).ext, 文件(2).ext)",
                       variable=self.rename_strategy,
                       value="auto_rename").pack(anchor=tk.W, pady=2)
        
        ttk.Radiobutton(rename_frame,
                       text="跳过重名文件（不移动）",
                       variable=self.rename_strategy,
                       value="skip").pack(anchor=tk.W, pady=2)
        
        ttk.Radiobutton(rename_frame,
                       text="覆盖重名文件（需要确认）",
                       variable=self.rename_strategy,
                       value="overwrite").pack(anchor=tk.W, pady=2)
        
        # 其他设置
        other_frame = ttk.LabelFrame(parent, text="其他设置", padding="10")
        other_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.auto_scan = tk.BooleanVar(value=True)
        self.auto_backup = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(other_frame,
                       text="启动时自动扫描当前文件夹",
                       variable=self.auto_scan).pack(anchor=tk.W, pady=2)
        
        ttk.Checkbutton(other_frame,
                       text="整理前自动创建备份",
                       variable=self.auto_backup).pack(anchor=tk.W, pady=2)
    
    def save_settings(self):
        """保存设置"""
        if self.config_manager.save_custom_types():
            if self.callback:
                self.callback()
            messagebox.showinfo("成功", "设置已保存")
        else:
            messagebox.showerror("错误", "保存设置失败")
    
    def reset_to_default(self):
        """恢复默认设置"""
        if messagebox.askyesno("确认", "确定要恢复默认设置吗？所有自定义设置将被清除。"):
            self.config_manager.custom_types = {}
            self.config_manager.save_custom_types()
            self.update_type_tree()
            messagebox.showinfo("成功", "已恢复默认设置")