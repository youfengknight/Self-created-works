#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
主程序入口
启动文件夹文件整理工具
"""

import tkinter as tk
import tkinter.messagebox as messagebox
import traceback
import sys
import os
from datetime import datetime

def log_error(error_msg):
    """记录错误信息到日志文件"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'error.log')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*50}\n")
            f.write(f"时间: {datetime.now()}\n")
            f.write(f"错误: {error_msg}\n")
            f.write(f"Python版本: {sys.version}\n")
            f.write(f"工作目录: {os.getcwd()}\n")
            f.write(f"{'='*50}\n")
    except:
        pass  # 如果连日志都写不了，那就没办法了

def show_error_dialog(error_msg):
    """显示错误对话框"""
    try:
        error_root = tk.Tk()
        error_root.withdraw()
        messagebox.showerror("程序启动失败", f"错误详情:\n{error_msg}\n\n请查看 error.log 文件获取更多信息。")
        error_root.destroy()
    except:
        pass

def main():
    """主函数"""
    try:
        # 清空旧日志
        log_file = os.path.join(os.path.dirname(__file__), 'error.log')
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write('')

        # 确保当前目录在模块搜索路径中
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        
        print(f"当前工作目录: {current_dir}")
        print(f"Python版本: {sys.version}")
        
        # 导入模块
        try:
            print("正在导入模块...")
            from gui_main import FileOrganizerGUI
            from utils import FileUtils
            print("模块导入成功")
        except ImportError as e:
            error_msg = f"模块导入失败: {str(e)}\n{traceback.format_exc()}"
            log_error(error_msg)
            show_error_dialog(error_msg)
            return
        
        # 创建主窗口
        print("正在创建主窗口...")
        root = tk.Tk()
        app = FileOrganizerGUI(root)
        root.mainloop()
        
    except Exception as e:
        error_msg = f"程序运行错误: {str(e)}\n{traceback.format_exc()}"
        log_error(error_msg)
        show_error_dialog(error_msg)

if __name__ == "__main__":
    main()