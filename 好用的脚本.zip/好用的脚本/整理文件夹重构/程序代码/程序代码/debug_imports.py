#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""详细调试导入问题"""

import sys
import os
import traceback

def debug_import(module_name):
    """详细调试单个模块导入"""
    print(f"\n=== 调试 {module_name} ===")
    try:
        # 清除模块缓存（如果存在）
        if module_name in sys.modules:
            del sys.modules[module_name]
            print(f"已清除 {module_name} 的模块缓存")
        
        # 尝试导入
        module = __import__(module_name)
        print(f"✓ {module_name} 导入成功")
        return True
        
    except ImportError as e:
        print(f"✗ {module_name} 导入失败: {e}")
        print("详细错误信息:")
        traceback.print_exc()
        return False
    except Exception as e:
        print(f"✗ {module_name} 其他错误: {e}")
        print("详细错误信息:")
        traceback.print_exc()
        return False

def main():
    """主调试函数"""
    print("=== Python 导入调试 ===")
    print(f"Python版本: {sys.version}")
    print(f"工作目录: {os.getcwd()}")
    print(f"当前文件目录: {os.path.dirname(os.path.abspath(__file__))}")
    print(f"模块搜索路径:")
    for i, path in enumerate(sys.path):
        print(f"  {i}: {path}")
    
    # 确保当前目录在搜索路径中
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
        print(f"\n已添加当前目录到搜索路径: {current_dir}")
    
    # 测试各个模块
    modules = [
        'config_manager',
        'utils',
        'file_scanner', 
        'file_organizer',
        'file_renamer',
        'settings_window',
        'rename_window',
        'gui_main'
    ]
    
    success_count = 0
    for module_name in modules:
        if debug_import(module_name):
            success_count += 1
    
    print(f"\n=== 调试结果 ===")
    print(f"成功导入: {success_count}/{len(modules)} 个模块")
    
    if success_count == len(modules):
        print("所有模块导入成功！")
    else:
        print("仍有模块导入失败，请检查错误信息")
    
    print("\n按回车键退出...")
    input()

if __name__ == "__main__":
    main()