"""
备份管理模块
提供安全备份和操作历史持久化功能
"""

import os
import shutil
import json
from datetime import datetime
from pathlib import Path

class BackupManager:
    def __init__(self):
        self.backup_dir = "backups"
        self.history_file = "operation_history.json"
        self.operations_history = self.load_history()
        
        os.makedirs(self.backup_dir, exist_ok=True)
    
    def create_backup(self, folder_path, operation_type="manual"):
        """
        创建文件夹备份
        
        Args:
            folder_path: 要备份的文件夹路径
            operation_type: 操作类型标识
            
        Returns:
            dict: 备份信息
        """
        if not os.path.exists(folder_path):
            return {"success": False, "error": "文件夹不存在"}
        
        folder_name = os.path.basename(folder_path)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{folder_name}_backup_{timestamp}"
        backup_path = os.path.join(self.backup_dir, backup_name)
        
        try:
            shutil.copytree(folder_path, backup_path)
            
            backup_info = {
                "id": f"BK_{timestamp}",
                "time": datetime.now().isoformat(),
                "source": folder_path,
                "backup_path": backup_path,
                "operation_type": operation_type,
                "status": "completed"
            }
            
            self._save_backup_info(backup_info)
            
            return {
                "success": True,
                "backup_path": backup_path,
                "backup_id": backup_info["id"],
                "message": f"备份创建成功: {backup_name}"
            }
            
        except Exception as e:
            return {"success": False, "error": f"备份失败: {str(e)}"}
    
    def restore_backup(self, backup_id):
        """
        恢复备份
        
        Args:
            backup_id: 备份ID
            
        Returns:
            dict: 恢复结果
        """
        backup_info = self._get_backup_info(backup_id)
        if not backup_info:
            return {"success": False, "error": "备份不存在或已被删除"}
        
        backup_path = backup_info["backup_path"]
        source_path = backup_info["source"]
        
        if not os.path.exists(backup_path):
            return {"success": False, "error": "备份文件夹已丢失"}
        
        try:
            if os.path.exists(source_path):
                shutil.rmtree(source_path)
            
            shutil.copytree(backup_path, source_path)
            
            backup_info["status"] = "restored"
            backup_info["restore_time"] = datetime.now().isoformat()
            self._save_backup_info(backup_info)
            
            return {
                "success": True,
                "message": f"已从备份恢复: {os.path.basename(source_path)}"
            }
            
        except Exception as e:
            return {"success": False, "error": f"恢复失败: {str(e)}"}
    
    def get_backup_list(self):
        """获取备份列表"""
        backups = []
        history_file = os.path.join(self.backup_dir, "backup_history.json")
        
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    all_backups = json.load(f)
                    for backup in all_backups:
                        if os.path.exists(backup.get("backup_path", "")):
                            backups.append(backup)
            except:
                pass
        
        return sorted(backups, key=lambda x: x.get("time", ""), reverse=True)
    
    def delete_backup(self, backup_id):
        """删除备份"""
        backup_info = self._get_backup_info(backup_id)
        if not backup_info:
            return {"success": False, "error": "备份不存在"}
        
        backup_path = backup_info["backup_path"]
        
        try:
            if os.path.exists(backup_path):
                shutil.rmtree(backup_path)
            
            self._remove_backup_from_history(backup_id)
            
            return {"success": True, "message": "备份已删除"}
            
        except Exception as e:
            return {"success": False, "error": f"删除失败: {str(e)}"}
    
    def record_operation(self, operation_data):
        """
        记录操作历史（持久化）
        
        Args:
            operation_data: 操作数据字典
        """
        operation_record = {
            "id": f"OP_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
            "time": datetime.now().isoformat(),
            "type": operation_data.get("type", "unknown"),
            "folder": operation_data.get("folder", ""),
            "details": operation_data.get("details", {}),
            "files_moved": operation_data.get("files_moved", [])
        }
        
        self.operations_history.append(operation_record)
        self._save_history()
        
        return operation_record["id"]
    
    def get_operation_history(self, limit=50):
        """获取操作历史"""
        return self.operations_history[-limit:]
    
    def undo_operation(self, operation_id):
        """
        撤销指定操作（持久化版本）
        
        Args:
            operation_id: 操作ID
            
        Returns:
            dict: 撤销结果
        """
        for i, op in enumerate(self.operations_history):
            if op["id"] == operation_id:
                files_moved = op.get("files_moved", [])
                success_count = 0
                error_count = 0
                
                for file_move in reversed(files_moved):
                    try:
                        if os.path.exists(file_move.get("new", "")):
                            shutil.move(file_move["new"], file_move["original"])
                            dest_folder = os.path.dirname(file_move.get("new", ""))
                            if os.path.exists(dest_folder) and not os.listdir(dest_folder):
                                os.rmdir(dest_folder)
                            success_count += 1
                    except Exception as e:
                        error_count += 1
                
                op["undone"] = True
                op["undo_time"] = datetime.now().isoformat()
                self._save_history()
                
                return {
                    "success": True,
                    "success_count": success_count,
                    "error_count": error_count
                }
        
        return {"success": False, "error": "操作不存在或已被撤销"}
    
    def load_history(self):
        """加载历史记录"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return []
    
    def _save_history(self):
        """保存历史记录"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.operations_history, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存历史记录失败: {e}")
    
    def _save_backup_info(self, backup_info):
        """保存备份信息"""
        history_file = os.path.join(self.backup_dir, "backup_history.json")
        
        all_backups = []
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    all_backups = json.load(f)
            except:
                pass
        
        all_backups.append(backup_info)
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(all_backups, f, ensure_ascii=False, indent=2)
    
    def _get_backup_info(self, backup_id):
        """获取备份信息"""
        history_file = os.path.join(self.backup_dir, "backup_history.json")
        
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    all_backups = json.load(f)
                    for backup in all_backups:
                        if backup.get("id") == backup_id:
                            return backup
            except:
                pass
        return None
    
    def _remove_backup_from_history(self, backup_id):
        """从历史记录中移除备份"""
        history_file = os.path.join(self.backup_dir, "backup_history.json")
        
        if os.path.exists(history_file):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    all_backups = json.load(f)
                
                all_backups = [b for b in all_backups if b.get("id") != backup_id]
                
                with open(history_file, 'w', encoding='utf-8') as f:
                    json.dump(all_backups, f, ensure_ascii=False, indent=2)
            except:
                pass
    
    def detect_sensitive_files(self, folder_path):
        """
        检测敏感文件
        
        Args:
            folder_path: 文件夹路径
            
        Returns:
            list: 敏感文件列表
        """
        sensitive_patterns = [
            (r'.*\\.env$', '环境配置文件'),
            (r'.*\\.key$', '密钥文件'),
            (r'.*\\.pem$', '证书文件'),
            (r'.*\\.pfx$', '证书文件'),
            (r'.*password.*', '可能包含密码的文件'),
            (r'.*secret.*', '可能包含密钥的文件'),
            (r'.*credential.*', '可能包含凭证的文件'),
            (r'.*api[_-]?key.*', 'API密钥文件'),
        ]
        
        import re
        sensitive_files = []
        
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                file_name = os.path.basename(file_path)
                
                for pattern, description in sensitive_patterns:
                    if re.match(pattern, file_path, re.IGNORECASE):
                        sensitive_files.append({
                            "path": file_path,
                            "name": file_name,
                            "type": description,
                            "size": os.path.getsize(file_path)
                        })
                        break
        
        return sensitive_files
    
    def cleanup_empty_folders(self, folder_path):
        """
        清理空文件夹
        
        Args:
            folder_path: 根文件夹路径
            
        Returns:
            dict: 清理结果
        """
        empty_folders = []
        
        for root, dirs, files in os.walk(folder_path, topdown=False):
            if not dirs and not files:
                try:
                    os.rmdir(root)
                    empty_folders.append(root)
                except OSError:
                    pass
        
        return {
            "success": True,
            "cleaned_count": len(empty_folders),
            "empty_folders": empty_folders
        }
    
    def get_storage_info(self):
        """获取存储信息"""
        total_backup_size = 0
        backup_count = 0
        
        for item in os.listdir(self.backup_dir):
            item_path = os.path.join(self.backup_dir, item)
            if os.path.isdir(item_path):
                backup_count += 1
                for root, dirs, files in os.walk(item_path):
                    for file in files:
                        total_backup_size += os.path.getsize(os.path.join(root, file))
        
        return {
            "backup_count": backup_count,
            "total_size": total_backup_size,
            "history_count": len(self.operations_history)
        }