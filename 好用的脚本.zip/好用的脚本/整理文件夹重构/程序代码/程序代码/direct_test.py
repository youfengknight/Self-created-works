#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""直接测试主程序运行"""

import os
import sys
import subprocess

# 方法1: 直接运行 main.py
def test_main_py():
    """测试运行 main.py"""
    print("=== 方法1: 直接运行 main.py ===")
    try:
        # 保存当前目录
        original_dir = os.getcwd()
        script_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(script_dir)
        
        # 运行 main.py
        result = subprocess.run([sys.executable, 'main.py'], 
                              capture_output=True, text=True, timeout=10)
        
        print(f"返回码: {result.returncode}")
        if result.stdout:
            print(f"标准输出:\n{result.stdout}")
        if result.stderr:
            print(f"标准错误:\n{result.stderr}")
            
        os.chdir(original_dir)
        return result.returncode == 0
        
    except subprocess.TimeoutExpired:
        print("程序运行超时（这可能是正常的，因为GUI程序会持续运行）")
        return True
    except Exception as e:
        print(f"运行失败: {e}")
        return False

# 方法2: 测试模块导入
def test_import_in_subprocess():
    """在子进程中测试模块导入"""
    print("\n=== 方法2: 子进程测试导入 ===")
    test_code = """
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

try:
    from gui_main import FileOrganizerGUI
    from utils import FileUtils
    print("所有模块导入成功！")
except Exception as e:
    print(f"导入失败: {e}")
    import traceback
    traceback.print_exc()
"""
    
    try:
        result = subprocess.run([sys.executable, '-c', test_code], 
                              capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        print(f"返回码: {result.returncode}")
        if result.stdout:
            print(f"输出:\n{result.stdout}")
        if result.stderr:
            print(f"错误:\n{result.stderr}")
            
        return result.returncode == 0 and "成功" in result.stdout
    except Exception as e:
        print(f"测试失败: {e}")
        return False

def main():
    """主测试函数"""
    print("=== 主程序运行测试 ===")
    print(f"Python可执行文件: {sys.executable}")
    print(f"工作目录: {os.getcwd()}")
    
    # 测试1
    success1 = test_import_in_subprocess()
    
    if success1:
        print("\n✓ 模块导入测试通过！")
        print("\n现在可以尝试双击 main.py 运行程序了。")
    else:
        print("\n✗ 模块导入测试失败")
        print("请检查 error.log 文件获取详细信息")
    
    print("\n按回车键退出...")
    input()

if __name__ == "__main__":
    main()