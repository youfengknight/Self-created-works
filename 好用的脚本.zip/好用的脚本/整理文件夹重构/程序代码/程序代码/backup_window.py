"""
备份管理窗口模块
提供备份管理和安全设置的图形界面
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import os

class BackupWindow:
    def __init__(self, parent, backup_manager, scanner):
        self.parent = parent
        self.backup_manager = backup_manager
        self.scanner = scanner
        
        self.window = tk.Toplevel(parent)
        self.window.title("备份管理与安全设置")
        self.window.geometry("900x650")
        self.window.transient(parent)
        self.window.grab_set()
        
        from utils import FileUtils
        FileUtils.center_window(self.window, 900, 650)
        
        self.create_widgets()
        self.update_backup_list()
        self.update_operation_history()
    
    def create_widgets(self):
        """创建界面组件"""
        main_frame = ttk.Frame(self.window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(title_frame, 
                 text="💾 备份管理与安全设置",
                 font=("微软雅黑", 16, "bold")).pack(side=tk.LEFT)
        
        notebook = ttk.Notebook(self.window)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        backup_frame = ttk.Frame(notebook)
        notebook.add(backup_frame, text="📀 备份管理")
        self.create_backup_tab(backup_frame)
        
        security_frame = ttk.Frame(notebook)
        notebook.add(security_frame, text="🔒 安全设置")
        self.create_security_tab(security_frame)
        
        history_frame = ttk.Frame(notebook)
        notebook.add(history_frame, text="📜 操作历史")
        self.create_history_tab(history_frame)
        
        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(fill=tk.X, pady=(10, 0))
        
        storage_info = self.backup_manager.get_storage_info()
        ttk.Label(bottom_frame, 
                 text=f"存储信息: {storage_info['backup_count']} 个备份, "
                      f"总计 {storage_info['total_size'] / (1024*1024):.2f} MB, "
                      f"操作历史 {storage_info['history_count']} 条",
                 foreground="gray").pack(side=tk.LEFT)
        
        ttk.Button(bottom_frame,
                  text="关闭",
                  command=self.window.destroy,
                  width=15).pack(side=tk.RIGHT)
    
    def create_backup_tab(self, parent):
        """创建备份管理标签页"""
        operation_frame = ttk.LabelFrame(parent, text="备份操作", padding="10")
        operation_frame.pack(fill=tk.X, padx=10, pady=10)
        
        folder_frame = ttk.Frame(operation_frame)
        folder_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(folder_frame, text="选择文件夹:").pack(side=tk.LEFT)
        
        self.folder_entry = ttk.Entry(folder_frame)
        self.folder_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(10, 10))
        
        ttk.Button(folder_frame,
                  text="浏览",
                  command=self.select_folder,
                  width=8).pack(side=tk.RIGHT)
        
        button_frame = ttk.Frame(operation_frame)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame,
                  text="🆕 创建备份",
                  command=self.create_backup,
                  width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame,
                  text="🔍 检测敏感文件",
                  command=self.detect_sensitive,
                  width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame,
                  text="🧹 清理空文件夹",
                  command=self.cleanup_empty,
                  width=15).pack(side=tk.LEFT)
        
        list_frame = ttk.LabelFrame(parent, text="备份列表", padding="10")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        columns = ("备份ID", "时间", "源文件夹", "状态")
        self.backup_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        for col in columns:
            self.backup_tree.heading(col, text=col)
            self.backup_tree.column(col, width=150)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.backup_tree.yview)
        self.backup_tree.configure(yscrollcommand=scrollbar.set)
        
        self.backup_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        action_frame = ttk.Frame(parent)
        action_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(action_frame,
                  text="♻️ 恢复备份",
                  command=self.restore_backup,
                  width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(action_frame,
                  text="🗑️ 删除备份",
                  command=self.delete_backup,
                  width=15).pack(side=tk.LEFT)
    
    def create_security_tab(self, parent):
        """创建安全设置标签页"""
        settings_frame = ttk.LabelFrame(parent, text="安全设置", padding="10")
        settings_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.auto_backup = tk.BooleanVar(value=True)
        self.confirm_dangerous = tk.BooleanVar(value=True)
        self.skip_sensitive = tk.BooleanVar(value=False)
        
        ttk.Checkbutton(settings_frame,
                       text="整理前自动创建备份",
                       variable=self.auto_backup).pack(anchor=tk.W, pady=5)
        
        ttk.Checkbutton(settings_frame,
                       text="危险操作二次确认（如删除、覆盖）",
                       variable=self.confirm_dangerous).pack(anchor=tk.W, pady=5)
        
        ttk.Checkbutton(settings_frame,
                       text="跳过敏感文件（环境变量、密钥等）",
                       variable=self.skip_sensitive).pack(anchor=tk.W, pady=5)
        
        sensitive_frame = ttk.LabelFrame(parent, text="敏感文件检测结果", padding="10")
        sensitive_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        columns = ("文件路径", "类型")
        self.sensitive_tree = ttk.Treeview(sensitive_frame, columns=columns, show="headings")
        
        self.sensitive_tree.heading("文件路径", text="文件路径")
        self.sensitive_tree.heading("类型", text="类型")
        self.sensitive_tree.column("文件路径", width=500)
        self.sensitive_tree.column("类型", width=150)
        
        scrollbar = ttk.Scrollbar(sensitive_frame, orient=tk.VERTICAL, command=self.sensitive_tree.yview)
        self.sensitive_tree.configure(yscrollcommand=scrollbar.set)
        
        self.sensitive_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.sensitive_files = []
    
    def create_history_tab(self, parent):
        """创建操作历史标签页"""
        list_frame = ttk.LabelFrame(parent, text="操作历史", padding="10")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        columns = ("时间", "类型", "文件夹", "状态")
        self.history_tree = ttk.Treeview(list_frame, columns=columns, show="headings")
        
        for col in columns:
            self.history_tree.heading(col, text=col)
            self.history_tree.column(col, width=180)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.history_tree.yview)
        self.history_tree.configure(yscrollcommand=scrollbar.set)
        
        self.history_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        action_frame = ttk.Frame(parent)
        action_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(action_frame,
                  text="🔄 撤销选中操作",
                  command=self.undo_operation,
                  width=15).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(action_frame,
                  text="🗑️ 清除历史",
                  command=self.clear_history,
                  width=15).pack(side=tk.LEFT)
    
    def select_folder(self):
        """选择文件夹"""
        folder = filedialog.askdirectory(title="选择要备份的文件夹")
        if folder:
            self.folder_entry.delete(0, tk.END)
            self.folder_entry.insert(0, folder)
    
    def create_backup(self):
        """创建备份"""
        folder = self.folder_entry.get().strip()
        if not folder:
            messagebox.showwarning("提示", "请先选择文件夹")
            return
        
        if not os.path.exists(folder):
            messagebox.showerror("错误", "文件夹不存在")
            return
        
        result = self.backup_manager.create_backup(folder, "manual")
        
        if result["success"]:
            messagebox.showinfo("成功", result["message"])
            self.update_backup_list()
        else:
            messagebox.showerror("错误", result["error"])
    
    def detect_sensitive(self):
        """检测敏感文件"""
        folder = self.folder_entry.get().strip()
        if not folder:
            messagebox.showwarning("提示", "请先选择文件夹")
            return
        
        self.sensitive_files = self.backup_manager.detect_sensitive_files(folder)
        
        for item in self.sensitive_tree.get_children():
            self.sensitive_tree.delete(item)
        
        if self.sensitive_files:
            for sf in self.sensitive_files:
                self.sensitive_tree.insert("", "end", values=(
                    sf["path"],
                    sf["type"]
                ))
            messagebox.showwarning("警告", f"检测到 {len(self.sensitive_files)} 个敏感文件，请谨慎操作！")
        else:
            messagebox.showinfo("完成", "未检测到敏感文件")
    
    def cleanup_empty(self):
        """清理空文件夹"""
        folder = self.folder_entry.get().strip()
        if not folder:
            messagebox.showwarning("提示", "请先选择文件夹")
            return
        
        result = self.backup_manager.cleanup_empty_folders(folder)
        
        if result["success"]:
            messagebox.showinfo("完成", f"已清理 {result['cleaned_count']} 个空文件夹")
        else:
            messagebox.showerror("错误", "清理失败")
    
    def update_backup_list(self):
        """更新备份列表"""
        for item in self.backup_tree.get_children():
            self.backup_tree.delete(item)
        
        backups = self.backup_manager.get_backup_list()
        
        for backup in backups:
            time_str = backup.get("time", "")[:19].replace("T", " ")
            self.backup_tree.insert("", "end", values=(
                backup.get("id", ""),
                time_str,
                os.path.basename(backup.get("source", "")),
                backup.get("status", "")
            ))
    
    def restore_backup(self):
        """恢复备份"""
        selection = self.backup_tree.selection()
        if not selection:
            messagebox.showinfo("提示", "请先选择一个备份")
            return
        
        item = self.backup_tree.item(selection[0])
        backup_id = item["values"][0]
        
        if not messagebox.askyesno("确认", "确定要恢复备份吗？当前文件夹内容将被覆盖。"):
            return
        
        result = self.backup_manager.restore_backup(backup_id)
        
        if result["success"]:
            messagebox.showinfo("成功", result["message"])
            self.update_backup_list()
        else:
            messagebox.showerror("错误", result["error"])
    
    def delete_backup(self):
        """删除备份"""
        selection = self.backup_tree.selection()
        if not selection:
            messagebox.showinfo("提示", "请先选择一个备份")
            return
        
        item = self.backup_tree.item(selection[0])
        backup_id = item["values"][0]
        
        if not messagebox.askyesno("确认", "确定要删除该备份吗？"):
            return
        
        result = self.backup_manager.delete_backup(backup_id)
        
        if result["success"]:
            messagebox.showinfo("成功", result["message"])
            self.update_backup_list()
        else:
            messagebox.showerror("错误", result["error"])
    
    def update_operation_history(self):
        """更新操作历史"""
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
        
        history = self.backup_manager.get_operation_history()
        
        for op in reversed(history):
            time_str = op.get("time", "")[:19].replace("T", " ")
            status = "已撤销" if op.get("undone") else "已完成"
            self.history_tree.insert("", "end", values=(
                time_str,
                op.get("type", "unknown"),
                os.path.basename(op.get("folder", "")),
                status
            ))
    
    def undo_operation(self):
        """撤销操作"""
        selection = self.history_tree.selection()
        if not selection:
            messagebox.showinfo("提示", "请先选择一个操作")
            return
        
        item = self.history_tree.item(selection[0])
        op_id = None
        
        history = self.backup_manager.get_operation_history()
        time_str = item["values"][0]
        for op in history:
            if op.get("time", "").startswith(time_str.replace(" ", "T")):
                op_id = op["id"]
                break
        
        if not op_id:
            messagebox.showerror("错误", "找不到操作记录")
            return
        
        if not messagebox.askyesno("确认", "确定要撤销该操作吗？"):
            return
        
        result = self.backup_manager.undo_operation(op_id)
        
        if result["success"]:
            messagebox.showinfo("成功", f"已撤销操作，成功还原 {result['success_count']} 个文件")
            self.update_operation_history()
        else:
            messagebox.showerror("错误", result["error"])
    
    def clear_history(self):
        """清除历史"""
        if not messagebox.askyesno("确认", "确定要清除所有操作历史吗？此操作不可撤销。"):
            return
        
        self.backup_manager.operations_history = []
        self.backup_manager._save_history()
        self.update_operation_history()
        messagebox.showinfo("完成", "操作历史已清除")