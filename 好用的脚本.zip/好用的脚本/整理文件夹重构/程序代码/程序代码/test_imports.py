#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""测试所有模块的导入"""

import sys
import os

def test_imports():
    """测试所有模块导入"""
    print("=== 测试模块导入 ===")
    print(f"Python版本: {sys.version}")
    print(f"工作目录: {os.getcwd()}")
    print()
    
    # 测试基础模块
    try:
        import tkinter
        print("✓ tkinter 导入成功")
    except ImportError as e:
        print(f"✗ tkinter 导入失败: {e}")
    
    # 测试自定义模块
    modules = [
        'config_manager',
        'file_scanner', 
        'file_organizer',
        'file_renamer',
        'utils',
        'gui_main',
        'settings_window',
        'rename_window'
    ]
    
    for module_name in modules:
        try:
            __import__(module_name)
            print(f"✓ {module_name} 导入成功")
        except ImportError as e:
            print(f"✗ {module_name} 导入失败: {e}")
    
    print("\n=== 测试类实例化 ===")
    
    # 测试主要类的实例化
    try:
        from config_manager import ConfigManager
        config = ConfigManager()
        print("✓ ConfigManager 实例化成功")
    except Exception as e:
        print(f"✗ ConfigManager 实例化失败: {e}")
    
    try:
        from utils import FileUtils
        print("✓ FileUtils 可用")
    except Exception as e:
        print(f"✗ FileUtils 错误: {e}")
    
    print("\n按回车键退出...")
    input()

if __name__ == "__main__":
    test_imports()