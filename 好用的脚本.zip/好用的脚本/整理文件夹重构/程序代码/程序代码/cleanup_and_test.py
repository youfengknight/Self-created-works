#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""清理Python缓存并测试程序"""

import os
import sys
import shutil
import subprocess

def cleanup_cache():
    """清理Python缓存文件"""
    print("=== 清理缓存文件 ===")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 清理 __pycache__ 目录
    for root, dirs, files in os.walk(script_dir):
        for dir_name in dirs:
            if dir_name == '__pycache__':
                cache_path = os.path.join(root, dir_name)
                try:
                    shutil.rmtree(cache_path)
                    print(f"已删除: {cache_path}")
                except Exception as e:
                    print(f"删除失败 {cache_path}: {e}")
    
    # 清理 .pyc 文件
    for root, dirs, files in os.walk(script_dir):
        for file in files:
            if file.endswith('.pyc') or file.endswith('.pyo'):
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    print(f"已删除: {file_path}")
                except Exception as e:
                    print(f"删除失败 {file_path}: {e}")

def test_program():
    """测试程序运行"""
    print("\n=== 测试程序运行 ===")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 清空错误日志
    error_log = os.path.join(script_dir, 'error.log')
    if os.path.exists(error_log):
        try:
            with open(error_log, 'w') as f:
                f.write('')  # 清空文件
            print("已清空 error.log")
        except:
            pass
    
    # 测试导入
    test_script = """
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

print("正在测试模块导入...")
try:
    from gui_main import FileOrganizerGUI
    from utils import FileUtils
    print("✓ 所有模块导入成功！")
    
    # 测试创建GUI（不显示）
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    app = FileOrganizerGUI(root)
    root.destroy()
    print("✓ GUI实例化成功！")
    
except Exception as e:
    print(f"✗ 测试失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
"""
    
    try:
        result = subprocess.run([sys.executable, '-c', test_script], 
                              capture_output=True, text=True, cwd=script_dir, timeout=15)
        
        print(f"返回码: {result.returncode}")
        if result.stdout:
            print(f"输出:\n{result.stdout}")
        if result.stderr:
            print(f"错误:\n{result.stderr}")
        
        if result.returncode == 0:
            print("\n✓ 测试通过！程序应该可以正常运行了。")
            return True
        else:
            print("\n✗ 测试失败")
            return False
            
    except subprocess.TimeoutExpired:
        print("测试超时，但GUI可能正常启动了")
        return True
    except Exception as e:
        print(f"测试过程出错: {e}")
        return False

def main():
    """主函数"""
    print("=== 文件整理工具 - 清理和测试 ===")
    
    # 清理缓存
    cleanup_cache()
    
    # 测试程序
    success = test_program()
    
    if success:
        print("\n🎉 清理和测试完成！")
        print("现在可以尝试以下方式运行程序：")
        print("1. 双击 main.py")
        print("2. 双击 run_main.bat")
        print("3. 在命令行运行: python main.py")
    else:
        print("\n❌ 测试失败，请检查 error.log 文件")
    
    print("\n按回车键退出...")
    input()

if __name__ == "__main__":
    main()