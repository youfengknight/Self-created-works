"""
统计可视化模块
提供数据统计和图表可视化功能
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from collections import defaultdict

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

try:
    import openpyxl
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

def setup_chinese_font():
    """设置matplotlib中文字体"""
    if not MATPLOTLIB_AVAILABLE:
        return
    
    font_list = [
        'SimHei', 'Microsoft YaHei', 'Microsoft JhengHei', 'WenQuanYi Micro Hei',
        'Noto Sans CJK SC', 'AR PL UMing CN', 'Arial Unicode MS',
        'DejaVu Sans', 'Liberation Sans'
    ]
    
    available_fonts = [f.name for f in matplotlib.font_manager.fontManager.ttflist]
    
    selected_font = None
    for font in font_list:
        if font in available_fonts:
            selected_font = font
            break
    
    if selected_font:
        plt.rcParams['font.sans-serif'] = [selected_font]
        plt.rcParams['axes.unicode_minus'] = False
    else:
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False

setup_chinese_font()

class StatsVisualizer:
    def __init__(self, scanner):
        self.scanner = scanner
    
    def generate_type_distribution_chart(self, parent_frame):
        """生成文件类型分布饼图"""
        if not MATPLOTLIB_AVAILABLE:
            return self._create_text_chart(parent_frame, "Please install matplotlib library")
        
        type_stats = self.scanner.type_stats
        if not type_stats:
            return self._create_text_chart(parent_frame, "No scan data available")
        
        labels = list(type_stats.keys())
        sizes = [stats["count"] for stats in type_stats.values()]
        colors = plt.cm.Set3(range(len(labels)))
        
        fig, ax = plt.subplots(figsize=(6, 4), dpi=100)
        fig.patch.set_facecolor('#f0f0f0')
        
        wedges, texts, autotexts = ax.pie(sizes, autopct='%1.1f%%',
                                           colors=colors, startangle=90)
        ax.set_title('File Type Distribution', fontsize=12, fontweight='bold')
        ax.legend(wedges, labels, title="Types", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
        
        canvas = FigureCanvasTkAgg(fig, master=parent_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        return canvas
    
    def generate_size_distribution_chart(self, parent_frame):
        """生成文件大小分布直方图"""
        if not MATPLOTLIB_AVAILABLE:
            return self._create_text_chart(parent_frame, "Please install matplotlib library")
        
        files = self.scanner.all_files
        if not files:
            return self._create_text_chart(parent_frame, "No scan data available")
        
        sizes_mb = [f["size"] / (1024 * 1024) for f in files]
        
        fig, ax = plt.subplots(figsize=(6, 4), dpi=100)
        fig.patch.set_facecolor('#f0f0f0')
        
        ax.hist(sizes_mb, bins=20, color='steelblue', edgecolor='white', alpha=0.7)
        ax.set_xlabel('File Size (MB)', fontsize=10)
        ax.set_ylabel('File Count', fontsize=10)
        ax.set_title('File Size Distribution', fontsize=12, fontweight='bold')
        ax.grid(axis='y', alpha=0.3)
        
        canvas = FigureCanvasTkAgg(fig, master=parent_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        return canvas
    
    def generate_time_trend_chart(self, parent_frame):
        """生成文件时间趋势图"""
        if not MATPLOTLIB_AVAILABLE:
            return self._create_text_chart(parent_frame, "Please install matplotlib library")
        
        files = self.scanner.all_files
        if not files:
            return self._create_text_chart(parent_frame, "No scan data available")
        
        time_stats = defaultdict(int)
        for f in files:
            date = datetime.fromtimestamp(f["mtime"]).strftime('%Y-%m')
            time_stats[date] += 1
        
        sorted_dates = sorted(time_stats.keys())
        counts = [time_stats[date] for date in sorted_dates]
        
        fig, ax = plt.subplots(figsize=(8, 4), dpi=100)
        fig.patch.set_facecolor('#f0f0f0')
        
        ax.bar(range(len(sorted_dates)), counts, color='coral', alpha=0.7)
        ax.set_xticks(range(len(sorted_dates)))
        ax.set_xticklabels(sorted_dates, rotation=45, fontsize=8)
        ax.set_xlabel('Month', fontsize=10)
        ax.set_ylabel('File Count', fontsize=10)
        ax.set_title('File Creation Time Trend', fontsize=12, fontweight='bold')
        ax.grid(axis='y', alpha=0.3)
        
        canvas = FigureCanvasTkAgg(fig, master=parent_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        return canvas
    
    def _create_text_chart(self, parent_frame, message="Please install matplotlib library"):
        """创建文本占位图"""
        label = ttk.Label(parent_frame, text=message, font=("微软雅黑", 10))
        label.pack(pady=20)
        return label
    
    def get_detailed_stats(self):
        """获取详细统计信息"""
        files = self.scanner.all_files
        type_stats = self.scanner.type_stats
        
        if not files:
            return {}
        
        total_size = sum(f["size"] for f in files)
        size_stats = defaultdict(lambda: {"count": 0, "size": 0})
        time_stats = defaultdict(lambda: {"count": 0, "size": 0})
        
        for f in files:
            size_cat = f["size_category"]
            time_cat = f["time_category"]
            
            size_stats[size_cat]["count"] += 1
            size_stats[size_cat]["size"] += f["size"]
            
            time_stats[time_cat]["count"] += 1
            time_stats[time_cat]["size"] += f["size"]
        
        return {
            "total_files": len(files),
            "total_size": total_size,
            "type_count": len(type_stats),
            "size_stats": dict(size_stats),
            "time_stats": dict(time_stats)
        }
    
    def export_stats_to_excel(self, filepath):
        """导出统计报告到Excel"""
        if not OPENPYXL_AVAILABLE:
            return False, "Please install openpyxl library"
        
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, Alignment
            
            wb = Workbook()
            ws = wb.active
            ws.title = "File Statistics Report"
            
            ws['A1'] = "File Organizer Tool - Statistics Report"
            ws['A1'].font = Font(bold=True, size=14)
            ws.merge_cells('A1:D1')
            
            ws['A2'] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            
            ws['A4'] = "Overview"
            ws['A4'].font = Font(bold=True)
            
            stats = self.get_detailed_stats()
            row = 5
            ws[f'A{row}'] = "Total Files"
            ws[f'B{row}'] = stats.get("total_files", 0)
            row += 1
            ws[f'A{row}'] = "Total Size"
            ws[f'B{row}'] = f"{stats.get('total_size', 0) / (1024*1024):.2f} MB"
            row += 1
            ws[f'A{row}'] = "File Types"
            ws[f'B{row}'] = stats.get("type_count", 0)
            
            row += 2
            ws[f'A{row}'] = "File Type Details"
            ws[f'A{row}'].font = Font(bold=True)
            row += 1
            ws[f'A{row}'] = "Type"
            ws[f'B{row}'] = "Count"
            ws[f'C{row}'] = "Total Size"
            ws[f'D{row}'] = "Percentage"
            for font_cell in [ws[f'A{row}'], ws[f'B{row}'], ws[f'C{row}'], ws[f'D{row}']]:
                font_cell.font = Font(bold=True)
            
            type_stats = self.scanner.type_stats
            total_files = sum(s["count"] for s in type_stats.values())
            for file_type, stat in sorted(type_stats.items()):
                row += 1
                ws[f'A{row}'] = file_type
                ws[f'B{row}'] = stat["count"]
                ws[f'C{row}'] = f"{stat['size'] / (1024*1024):.2f} MB"
                percentage = (stat["count"] / total_files * 100) if total_files > 0 else 0
                ws[f'D{row}'] = f"{percentage:.1f}%"
            
            wb.save(filepath)
            return True, f"Report exported to: {filepath}"
            
        except Exception as e:
            return False, f"Export failed: {str(e)}"
    
    def export_stats_to_text(self, filepath):
        """导出统计报告到文本文件"""
        try:
            stats = self.get_detailed_stats()
            type_stats = self.scanner.type_stats
            
            lines = []
            lines.append("=" * 60)
            lines.append("        File Organizer Tool - Statistics Report")
            lines.append("=" * 60)
            lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            lines.append("")
            
            lines.append("[Overview]")
            lines.append(f"  Total Files: {stats.get('total_files', 0)}")
            lines.append(f"  Total Size: {stats.get('total_size', 0) / (1024*1024):.2f} MB")
            lines.append(f"  File Types: {stats.get('type_count', 0)}")
            lines.append("")
            
            lines.append("[File Type Details]")
            total_files = sum(s["count"] for s in type_stats.values())
            for file_type, stat in sorted(type_stats.items(), key=lambda x: x[1]["count"], reverse=True):
                percentage = (stat["count"] / total_files * 100) if total_files > 0 else 0
                lines.append(f"  {file_type}: {stat['count']} files ({percentage:.1f}%)")
                lines.append(f"    Size: {stat['size'] / (1024*1024):.2f} MB")
            
            lines.append("")
            lines.append("=" * 60)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write('\n'.join(lines))
            
            return True, f"Report exported to: {filepath}"
            
        except Exception as e:
            return False, f"Export failed: {str(e)}"